import { View, Pressable, ScrollView } from "react-native";
import { Text } from "@/src/components/AppText";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Ionicons from "@react-native-vector-icons/ionicons";
import { useRouter } from "expo-router";

import { useTheme, spacing, radius, shadow, type } from "@/src/theme";

type Row = { icon: string; label: string; sub?: string; route?: string; danger?: boolean };

const groups: { title: string; rows: Row[] }[] = [
  {
    title: "My Account",
    rows: [
      { icon: "star", label: "DashPoints & Rewards", sub: "2,410 pts • Redeem now", route: "/rewards" },
      { icon: "pricetag", label: "My Vouchers", sub: "4 active • Ready to use", route: "/vouchers" },
      { icon: "heart", label: "Favourites", sub: "Your saved restaurants", route: "/favourites" },
    ],
  },
  {
    title: "Addresses & Payments",
    rows: [
      { icon: "location", label: "Saved Addresses", sub: "Home, Office, Mom's place", route: "/delivery/address" },
      { icon: "card", label: "Payments & Refunds", sub: "Cards, e-wallets, FPX banks", route: "/delivery/payment?mode=select" },
    ],
  },
  {
    title: "Partner with Dash",
    rows: [
      { icon: "bicycle", label: "Sign in as Rider", sub: "Deliver food, earn RM 20+/hr", route: "/rider" },
      { icon: "storefront", label: "Merchant Portal", sub: "For restaurant partners", route: "/merchant" },
    ],
  },
  {
    title: "More",
    rows: [
      { icon: "notifications", label: "Notifications", sub: "Push, Email, SMS" },
      { icon: "language", label: "Language", sub: "English (MY)" },
      { icon: "help-circle", label: "Help & Support" },
      { icon: "shield-checkmark", label: "Privacy & Terms" },
    ],
  },
];

export default function AccountScreen() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();

  return (
    <View style={{ flex: 1, backgroundColor: colors.surfaceSecondary }}>
      <ScrollView contentContainerStyle={{ paddingBottom: insets.bottom + 24 }}>
        {/* Profile header */}
        <View style={{ paddingTop: insets.top + spacing.md, paddingHorizontal: spacing.lg, paddingBottom: spacing.lg, backgroundColor: colors.surface }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: spacing.md }}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: type.subhead.fontSize, fontWeight: "900", color: colors.onSurface, letterSpacing: -0.3 }}>AISYAH RAHMAN</Text>
              <Text style={{ fontSize: 13, color: colors.muted, marginTop: 4 }}>+60 12 345 6789 • aisyah@dash.my</Text>
              <Pressable testID="edit-profile" style={{ marginTop: 6 }}>
                <Text style={{ fontSize: 13, fontWeight: "900", color: colors.brandPrimary }}>EDIT PROFILE ›</Text>
              </Pressable>
            </View>
            <Image source={{ uri: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80" }} style={{ width: 64, height: 64, borderRadius: 32 }} />
          </View>

          {/* Membership card */}
          <Pressable
            testID="rewards-banner"
            onPress={() => router.push("/rewards")}
            style={{ marginTop: spacing.lg, borderRadius: radius.lg, padding: spacing.md, backgroundColor: colors.onSurface, flexDirection: "row", alignItems: "center", gap: spacing.md }}
          >
            <View style={{ width: 44, height: 44, borderRadius: 12, backgroundColor: colors.brandPrimary, alignItems: "center", justifyContent: "center" }}>
              <Text style={{ color: "#FFFFFF", fontSize: 13, fontWeight: "900" }}>ONE</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 14, fontWeight: "900", color: "#FFFFFF" }}>Dash Gold Member</Text>
              <Text style={{ fontSize: 12, color: "rgba(255,255,255,0.7)", marginTop: 2 }}>Free delivery above RM25 • 2,410 pts</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color="rgba(255,255,255,0.7)" />
          </Pressable>

          <View style={{ flexDirection: "row", gap: spacing.sm, marginTop: spacing.md }}>
            <Stat value="147" label="Orders" />
            <Stat value="12" label="Bookings" />
            <Stat value="RM 2.4k" label="Saved" />
          </View>
        </View>

        {groups.map((g) => (
          <View key={g.title} style={{ marginTop: spacing.md, backgroundColor: colors.surface, paddingHorizontal: spacing.lg }}>
            <Text style={{ fontSize: 12, fontWeight: "900", color: colors.muted, letterSpacing: 0.6, paddingTop: spacing.lg, paddingBottom: spacing.xs }}>{g.title.toUpperCase()}</Text>
            {g.rows.map((s, i) => (
              <Pressable
                key={s.label}
                testID={`setting-${s.label.toLowerCase().replace(/[^a-z]+/g, "-")}`}
                onPress={() => s.route && router.push(s.route as any)}
                style={{ flexDirection: "row", alignItems: "center", gap: spacing.md, paddingVertical: spacing.md, borderBottomWidth: i === g.rows.length - 1 ? 0 : 1, borderBottomColor: colors.divider }}
              >
                <Ionicons name={`${s.icon}-outline` as any} size={20} color={colors.onSurfaceSecondary} />
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 15, fontWeight: "700", color: colors.onSurface }}>{s.label}</Text>
                  {s.sub ? <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>{s.sub}</Text> : null}
                </View>
                <Ionicons name="chevron-forward" size={18} color={colors.muted} />
              </Pressable>
            ))}
          </View>
        ))}

        <Pressable testID="setting-sign-out" style={{ marginTop: spacing.md, backgroundColor: colors.surface, paddingHorizontal: spacing.lg, paddingVertical: spacing.lg, flexDirection: "row", alignItems: "center", gap: spacing.md }}>
          <Ionicons name="log-out-outline" size={20} color={colors.error} />
          <Text style={{ fontSize: 15, fontWeight: "800", color: colors.error }}>Log out</Text>
        </Pressable>

        <Text style={{ textAlign: "center", fontSize: 11, color: colors.muted, marginTop: spacing.xl }}>Dash v1.0.0 • Made in Malaysia 🇲🇾</Text>
      </ScrollView>
    </View>
  );
}

function Stat({ value, label }: { value: string; label: string }) {
  const { colors } = useTheme();
  return (
    <View style={{ flex: 1, backgroundColor: colors.surfaceSecondary, padding: spacing.md, borderRadius: radius.md, ...shadow.card, shadowOpacity: 0 }}>
      <Text style={{ fontSize: 17, fontWeight: "900", color: colors.onSurface }}>{value}</Text>
      <Text style={{ fontSize: 11, color: colors.muted, marginTop: 2 }}>{label}</Text>
    </View>
  );
}
