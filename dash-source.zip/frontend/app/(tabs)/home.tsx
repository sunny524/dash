import { View, Pressable, ScrollView, Keyboard, useWindowDimensions, NativeScrollEvent, NativeSyntheticEvent } from "react-native";
import { Text, TextInput } from "@/src/components/AppText";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Ionicons from "@react-native-vector-icons/ionicons";
import { useMemo, useState } from "react";

import { useTheme, spacing, radius, shadow } from "@/src/theme";
import { RestaurantCard } from "@/src/components/RestaurantCard";
import { restaurants, promos } from "@/src/data/mock";

const services = [
  { id: "delivery", title: "DELIVERY", sub: "FROM RM3.90", icon: "bicycle", route: "/delivery/restaurants", badge: "20% OFF" },
  { id: "dine-in", title: "DINE-IN", sub: "SCAN QR", icon: "qr-code", route: "/dine-in/scanner" },
  { id: "pickup", title: "PICKUP", sub: "NO QUEUE", icon: "bag-handle", route: "/pickup/restaurants" },
  { id: "booking", title: "BOOK TABLE", sub: "RESERVE", icon: "calendar", route: "/booking/restaurants" },
] as const;

const categories = [
  { id: "malay", label: "Nasi Lemak", image: "https://images.unsplash.com/photo-1677921755291-c39158477b8e?w=300&q=80" },
  { id: "bbq", label: "Satay", image: "https://images.unsplash.com/photo-1696385793104-745d4dd65c5a?w=300&q=80" },
  { id: "noodles", label: "Noodles", image: "https://images.unsplash.com/photo-1552611052-33e04de081de?w=300&q=80" },
  { id: "dim sum", label: "Dim Sum", image: "https://images.unsplash.com/photo-1767298113547-11e95951608b?w=300&q=80" },
  { id: "mamak", label: "Roti", image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=300&q=80" },
  { id: "soup", label: "Laksa", image: "https://images.unsplash.com/photo-1569058242253-92a9c755a0ec?w=300&q=80" },
  { id: "chinese", label: "Chinese", image: "https://images.unsplash.com/photo-1585032226651-759b368d7246?w=300&q=80" },
  { id: "halal", label: "Teh Tarik", image: "https://images.unsplash.com/photo-1571934811356-5cc061b6821f?w=300&q=80" },
];

type FilterKey = "fast" | "rating" | "offers" | "halal" | "pickup";
const filters: { key: FilterKey; label: string }[] = [
  { key: "fast", label: "Fast Delivery" },
  { key: "rating", label: "Ratings 4.7+" },
  { key: "offers", label: "Offers" },
  { key: "halal", label: "Pure Halal" },
  { key: "pickup", label: "Pickup" },
];
type SortKey = "relevance" | "rating" | "time" | "distance";
const sorts: { key: SortKey; label: string }[] = [
  { key: "relevance", label: "Relevance" },
  { key: "rating", label: "Rating" },
  { key: "time", label: "Delivery Time" },
  { key: "distance", label: "Distance" },
];

export default function Home() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { width } = useWindowDimensions();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<string | null>(null);
  const [active, setActive] = useState<FilterKey[]>([]);
  const [sort, setSort] = useState<SortKey>("relevance");
  const [banner, setBanner] = useState(0);
  const searching = query.trim().length > 0;
  const bannerW = width - spacing.lg * 2;

  const toggle = (k: FilterKey) => setActive((a) => (a.includes(k) ? a.filter((x) => x !== k) : [...a, k]));
  const cycleSort = () => setSort((s) => sorts[(sorts.findIndex((x) => x.key === s) + 1) % sorts.length].key);

  const list = useMemo(() => {
    let l = restaurants.filter((r) => {
      if (category && !r.cuisines.some((c) => c.toLowerCase().includes(category))) return false;
      if (active.includes("fast") && r.etaMin > 25) return false;
      if (active.includes("rating") && r.rating < 4.7) return false;
      if (active.includes("offers") && !r.promo) return false;
      if (active.includes("halal") && !r.cuisines.includes("Halal")) return false;
      if (active.includes("pickup") && !r.pickupAvailable) return false;
      if (query.trim()) {
        const q = query.toLowerCase();
        return r.name.toLowerCase().includes(q) || r.cuisines.join(" ").toLowerCase().includes(q);
      }
      return true;
    });
    if (sort === "rating") l = [...l].sort((a, b) => b.rating - a.rating);
    if (sort === "time") l = [...l].sort((a, b) => a.etaMin - b.etaMin);
    if (sort === "distance") l = [...l].sort((a, b) => a.distanceKm - b.distanceKm);
    return l;
  }, [category, active, sort, query]);

  const onBannerScroll = (e: NativeSyntheticEvent<NativeScrollEvent>) =>
    setBanner(Math.round(e.nativeEvent.contentOffset.x / (bannerW + spacing.md)));

  return (
    <View style={{ flex: 1, backgroundColor: colors.surface }}>
      {/* Location header */}
      <View style={{ paddingTop: insets.top, backgroundColor: colors.surface }}>
        <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: spacing.lg, paddingVertical: spacing.sm, gap: spacing.md }}>
          <Pressable style={{ flex: 1 }} testID="location-header" onPress={() => router.push("/location")}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
              <Ionicons name="navigate" size={18} color={colors.brandPrimary} />
              <Text style={{ fontSize: 18, fontWeight: "900", color: colors.onSurface }}>Home</Text>
              <Ionicons name="chevron-down" size={16} color={colors.onSurface} />
            </View>
            <Text style={{ fontSize: 12, color: colors.muted, marginTop: 1 }} numberOfLines={1}>12A, Jalan Bukit Bintang, 55100 Kuala Lumpur</Text>
          </Pressable>
          <Pressable testID="home-rewards" onPress={() => router.push("/rewards")} style={{ paddingHorizontal: 10, height: 34, borderRadius: radius.pill, backgroundColor: colors.brandTertiary, flexDirection: "row", alignItems: "center", gap: 4 }}>
            <Ionicons name="gift" size={14} color={colors.brandPrimary} />
            <Text style={{ fontSize: 12, fontWeight: "800", color: colors.brandPrimary }}>2,410</Text>
          </Pressable>
          <Pressable testID="home-avatar" onPress={() => router.push("/(tabs)/account")}>
            <Image source={{ uri: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80" }} style={{ width: 36, height: 36, borderRadius: 18 }} />
          </Pressable>
        </View>
      </View>

        {/* Pinned search (stays visible while the feed scrolls) */}
        <View style={{ paddingHorizontal: spacing.lg, paddingBottom: spacing.sm, backgroundColor: colors.surface }}>
          <View style={{
            flexDirection: "row", alignItems: "center", gap: spacing.sm, height: 48,
            backgroundColor: colors.surface, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border,
            paddingHorizontal: spacing.md, ...shadow.card,
          }}>
            <Ionicons name="search" size={18} color={colors.onSurface} />
            <TextInput
              testID="search-input"
              value={query}
              onChangeText={setQuery}
              placeholder="Search for 'Nasi Lemak'"
              placeholderTextColor={colors.muted}
              returnKeyType="search"
              style={{ flex: 1, fontSize: 14, color: colors.onSurface, padding: 0 }}
            />
            {searching ? (
              <Pressable testID="clear-search" hitSlop={8} onPress={() => { setQuery(""); Keyboard.dismiss(); }}>
                <Ionicons name="close-circle" size={18} color={colors.muted} />
              </Pressable>
            ) : (
              <>
                <View style={{ width: 1, height: 20, backgroundColor: colors.border }} />
                <Ionicons name="mic" size={18} color={colors.brandPrimary} />
              </>
            )}
          </View>
        </View>

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 24 }}
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="on-drag"
        stickyHeaderIndices={[1]}
      >
        {/* 0: Discovery blocks */}
        <View>
          {!searching && (
            <>
              {/* Service switcher */}
              <View style={{ flexDirection: "row", paddingHorizontal: spacing.lg, gap: spacing.sm, marginTop: spacing.sm }}>
                {services.map((s) => (
                  <Pressable
                    key={s.id}
                    testID={`tile-${s.id}`}
                    onPress={() => router.push(s.route)}
                    style={{ flex: 1, backgroundColor: colors.surface, borderRadius: radius.md, paddingVertical: spacing.sm, paddingHorizontal: 4, alignItems: "center", borderWidth: 1, borderColor: colors.border, ...shadow.card }}
                  >
                    {"badge" in s && (
                      <View style={{ position: "absolute", top: -8, backgroundColor: colors.brandPrimary, paddingHorizontal: 6, paddingVertical: 1, borderRadius: radius.sm }}>
                        <Text style={{ fontSize: 9, fontWeight: "900", color: "#FFFFFF" }}>{s.badge}</Text>
                      </View>
                    )}
                    <View style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: colors.brandTertiary, alignItems: "center", justifyContent: "center" }}>
                      <Ionicons name={s.icon as any} size={22} color={colors.brandPrimary} />
                    </View>
                    <Text style={{ fontSize: 10, fontWeight: "900", color: colors.onSurface, marginTop: 8, textAlign: "center" }} numberOfLines={1}>{s.title}</Text>
                    <Text style={{ fontSize: 9, fontWeight: "700", color: colors.muted, marginTop: 2, textAlign: "center" }} numberOfLines={1}>{s.sub}</Text>
                  </Pressable>
                ))}
              </View>

              {/* Offer carousel */}
              <ScrollView
                horizontal
                snapToInterval={bannerW + spacing.md}
                decelerationRate="fast"
                showsHorizontalScrollIndicator={false}
                onMomentumScrollEnd={onBannerScroll}
                onScroll={onBannerScroll}
                scrollEventThrottle={64}
                contentContainerStyle={{ paddingHorizontal: spacing.lg, gap: spacing.md, marginTop: spacing.lg }}
              >
                {promos.map((p) => (
                  <Pressable key={p.id} testID={`promo-${p.id}`} onPress={() => router.push("/vouchers")} style={{ width: bannerW, height: 124, borderRadius: radius.lg, overflow: "hidden", backgroundColor: p.color }}>
                    <Image source={{ uri: p.image }} style={{ position: "absolute", right: 0, top: 0, bottom: 0, width: "55%" }} contentFit="cover" />
                    <LinearGradient colors={[p.color, p.color, "transparent"]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ position: "absolute", inset: 0 }} />
                    <View style={{ padding: spacing.lg, flex: 1, justifyContent: "center", maxWidth: "62%" }}>
                      <Text style={{ color: "rgba(255,255,255,0.85)", fontSize: 11, fontWeight: "800", letterSpacing: 0.6 }}>LIMITED TIME</Text>
                      <Text style={{ color: "#FFFFFF", fontSize: 20, fontWeight: "900", marginTop: 2, letterSpacing: -0.4 }}>{p.title}</Text>
                      <Text style={{ color: "rgba(255,255,255,0.9)", fontSize: 12, marginTop: 2 }}>{p.subtitle}</Text>
                      <View style={{ marginTop: spacing.sm, alignSelf: "flex-start", backgroundColor: "#FFFFFF", paddingHorizontal: 12, paddingVertical: 5, borderRadius: radius.pill }}>
                        <Text style={{ fontSize: 11, fontWeight: "900", color: p.color }}>ORDER NOW</Text>
                      </View>
                    </View>
                  </Pressable>
                ))}
              </ScrollView>
              <View style={{ flexDirection: "row", justifyContent: "center", gap: 5, marginTop: spacing.sm }}>
                {promos.map((p, i) => (
                  <View key={p.id} style={{ width: i === banner ? 18 : 6, height: 6, borderRadius: 3, backgroundColor: i === banner ? colors.brandPrimary : colors.borderStrong }} />
                ))}
              </View>

              {/* What's on your mind */}
              <SectionTitle title="Aisyah, what's on your mind?" />
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: spacing.lg, gap: spacing.lg }}>
                {categories.map((c) => {
                  const on = category === c.id;
                  return (
                    <Pressable key={c.id} testID={`category-${c.label}`} onPress={() => setCategory(on ? null : c.id)} style={{ alignItems: "center", width: 64 }}>
                      <Image source={{ uri: c.image }} style={{ width: 60, height: 60, borderRadius: 30, borderWidth: on ? 3 : 0, borderColor: colors.brandPrimary }} contentFit="cover" />
                      <Text style={{ fontSize: 12, fontWeight: on ? "900" : "600", color: on ? colors.brandPrimary : colors.onSurfaceSecondary, marginTop: 6 }} numberOfLines={1}>{c.label}</Text>
                    </Pressable>
                  );
                })}
              </ScrollView>

              {/* Top picks */}
              <SectionTitle title="Top restaurant picks near you" />
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: spacing.lg, gap: spacing.md }}>
                {[...restaurants].sort((a, b) => b.rating - a.rating).slice(0, 5).map((r) => (
                  <Pressable key={r.id} testID={`top-pick-${r.id}`} onPress={() => router.push(`/delivery/restaurant/${r.id}`)} style={{ width: 120 }}>
                    <View style={{ height: 116, borderRadius: radius.md, overflow: "hidden" }}>
                      <Image source={{ uri: r.image }} style={{ width: "100%", height: "100%" }} contentFit="cover" />
                      <LinearGradient colors={["transparent", "rgba(0,0,0,0.85)"]} style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 60 }} />
                      {!!r.promo && <Text style={{ position: "absolute", left: 8, bottom: 6, color: "#FFFFFF", fontSize: 13, fontWeight: "900" }}>{r.promo.toUpperCase()}</Text>}
                    </View>
                    <Text style={{ fontSize: 14, fontWeight: "800", color: colors.onSurface, marginTop: 6 }} numberOfLines={1}>{r.name}</Text>
                    <Text style={{ fontSize: 12, fontWeight: "700", color: colors.onSurfaceSecondary, marginTop: 1 }}>★ {r.rating.toFixed(1)} • {r.etaMin}-{r.etaMin + 5} mins</Text>
                  </Pressable>
                ))}
              </ScrollView>
            </>
          )}

          <SectionTitle title={searching ? `Results for "${query}"` : `${list.length} restaurant${list.length === 1 ? "" : "s"} to explore`} />
        </View>

        {/* 2: Sticky filter row */}
        <View style={{ backgroundColor: colors.surface, paddingVertical: spacing.sm, borderBottomWidth: 1, borderBottomColor: colors.divider }}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: spacing.lg, gap: spacing.sm }}>
            <Chip testID="filter-sort" label={`Sort: ${sorts.find((s) => s.key === sort)!.label}`} icon="swap-vertical" on={sort !== "relevance"} onPress={cycleSort} />
            {filters.map((f) => (
              <Chip key={f.key} testID={`filter-${f.key}`} label={f.label} on={active.includes(f.key)} onPress={() => toggle(f.key)} />
            ))}
          </ScrollView>
        </View>

        {/* 3: Feed */}
        <View style={{ paddingHorizontal: spacing.lg, paddingTop: spacing.lg }}>
          {list.length === 0 ? (
            <View testID="home-empty" style={{ paddingVertical: 40, alignItems: "center" }}>
              <View style={{ width: 64, height: 64, borderRadius: 32, backgroundColor: colors.surfaceSecondary, alignItems: "center", justifyContent: "center" }}>
                <Ionicons name="restaurant" size={26} color={colors.warning} />
              </View>
              <Text style={{ fontSize: 15, fontWeight: "800", color: colors.onSurface, marginTop: spacing.md }}>No restaurants match</Text>
              <Text style={{ fontSize: 13, color: colors.muted, marginTop: 4, textAlign: "center" }}>Try removing a filter or searching another dish</Text>
              <Pressable testID="clear-filters" onPress={() => { setActive([]); setCategory(null); setQuery(""); }} style={{ marginTop: spacing.md, paddingHorizontal: spacing.lg, height: 40, borderRadius: radius.pill, borderWidth: 1.5, borderColor: colors.brandPrimary, justifyContent: "center" }}>
                <Text style={{ fontSize: 13, fontWeight: "800", color: colors.brandPrimary }}>Clear filters</Text>
              </Pressable>
            </View>
          ) : (
            list.map((r) => <RestaurantCard key={r.id} r={r} onPress={() => router.push(`/delivery/restaurant/${r.id}`)} />)
          )}
        </View>
      </ScrollView>
    </View>
  );
}

function SectionTitle({ title }: { title: string }) {
  const { colors } = useTheme();
  return (
    <Text style={{ fontSize: 16, fontWeight: "900", color: colors.onSurface, marginTop: spacing.lg, marginBottom: spacing.sm, paddingHorizontal: spacing.lg, letterSpacing: -0.3 }}>
      {title}
    </Text>
  );
}

function Chip({ label, on, onPress, icon, testID }: { label: string; on: boolean; onPress: () => void; icon?: string; testID: string }) {
  const { colors } = useTheme();
  return (
    <Pressable
      testID={testID}
      onPress={onPress}
      style={{
        flexDirection: "row", alignItems: "center", gap: 4, height: 36, paddingHorizontal: 12, borderRadius: radius.pill,
        borderWidth: 1, borderColor: on ? colors.brandPrimary : colors.border,
        backgroundColor: on ? colors.brandTertiary : colors.surface,
      }}
    >
      {icon && <Ionicons name={icon as any} size={14} color={on ? colors.brandPrimary : colors.onSurface} />}
      <Text style={{ fontSize: 13, fontWeight: "700", color: on ? colors.brandPrimary : colors.onSurface }}>{label}</Text>
      {on && !icon && <Ionicons name="close" size={13} color={colors.brandPrimary} />}
    </Pressable>
  );
}
