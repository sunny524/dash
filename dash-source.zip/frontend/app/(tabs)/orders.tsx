import { View, Pressable, ScrollView } from "react-native";
import { Text } from "@/src/components/AppText";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Ionicons from "@react-native-vector-icons/ionicons";
import { useRouter } from "expo-router";
import { useState } from "react";

import { useTheme, spacing, radius, shadow, type } from "@/src/theme";
import { orders } from "@/src/data/mock";

const TABS = ["All", "Delivery", "Dine-in", "Pickup"] as const;
const itemsText: Record<string, string> = {
  o1: "Nasi Lemak Ayam Rendang x 1, Roti Canai x 2",
  o2: "Chicken Satay (10 sticks) x 2",
  o3: "Char Kway Teow x 2, Teh Tarik x 2",
  o4: "Har Gow x 2, Siew Mai x 2, Chinese Tea x 2",
};
const isLive = (s: string) => s.includes("delivery") || s.includes("Ready");

export default function OrdersScreen() {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [tab, setTab] = useState<(typeof TABS)[number]>("All");
  const filtered = tab === "All" ? orders : orders.filter((o) => o.type === tab);

  return (
    <View style={{ flex: 1, backgroundColor: colors.surfaceSecondary }}>
      <View style={{ paddingTop: insets.top, backgroundColor: colors.surface }}>
        <View style={{ paddingHorizontal: spacing.lg, paddingVertical: spacing.md }}>
          <Text style={{ fontSize: type.subhead.fontSize, fontWeight: "900", color: colors.onSurface, letterSpacing: -0.3 }}>My Orders</Text>
        </View>
        <View style={{ flexDirection: "row", paddingHorizontal: spacing.lg, gap: spacing.lg, borderBottomWidth: 1, borderBottomColor: colors.border }}>
          {TABS.map((t) => {
            const active = t === tab;
            return (
              <Pressable key={t} testID={`orders-tab-${t}`} onPress={() => setTab(t)} style={{ paddingVertical: spacing.md, borderBottomWidth: 3, borderBottomColor: active ? colors.brandPrimary : "transparent" }}>
                <Text style={{ fontSize: 14, fontWeight: active ? "900" : "600", color: active ? colors.brandPrimary : colors.onSurfaceSecondary }}>{t}</Text>
              </Pressable>
            );
          })}
        </View>
      </View>

      <ScrollView contentContainerStyle={{ padding: spacing.lg, gap: spacing.md, paddingBottom: insets.bottom + 24 }}>
        {filtered.length === 0 && (
          <View testID="orders-empty" style={{ alignItems: "center", paddingVertical: 48 }}>
            <Ionicons name="fast-food" size={40} color={colors.warning} />
            <Text style={{ fontSize: 15, fontWeight: "800", color: colors.onSurface, marginTop: spacing.md }}>No {tab.toLowerCase()} orders yet</Text>
            <Pressable testID="orders-browse" onPress={() => router.push("/(tabs)/home")} style={{ marginTop: spacing.md, paddingHorizontal: spacing.lg, height: 40, borderRadius: radius.pill, backgroundColor: colors.brandPrimary, justifyContent: "center" }}>
              <Text style={{ color: "#FFFFFF", fontWeight: "800" }}>Browse restaurants</Text>
            </Pressable>
          </View>
        )}
        {filtered.map((o) => {
          const live = isLive(o.status);
          const open = () => router.push(o.type === "Pickup" ? "/pickup/status" : o.type === "Dine-in" ? "/dine-in/bill" : "/delivery/tracking");
          return (
            <View key={o.id} testID={`order-card-${o.id}`} style={{ backgroundColor: colors.surface, borderRadius: radius.lg, ...shadow.card, overflow: "hidden" }}>
              {live && (
                <Pressable testID={`order-live-${o.id}`} onPress={open} style={{ flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: colors.brandTertiary, paddingHorizontal: spacing.md, paddingVertical: 10 }}>
                  <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: colors.brandPrimary }} />
                  <Text style={{ flex: 1, fontSize: 13, fontWeight: "800", color: colors.brandPrimary }}>
                    {o.type === "Pickup" ? "Ready for pickup — show code at counter" : "Out for delivery • Arriving in 11 min"}
                  </Text>
                  <Text style={{ fontSize: 12, fontWeight: "900", color: colors.brandPrimary }}>{o.type === "Pickup" ? "VIEW" : "TRACK"} ›</Text>
                </Pressable>
              )}
              <Pressable onPress={open} style={{ flexDirection: "row", gap: spacing.md, padding: spacing.md }}>
                <Image source={{ uri: o.image }} style={{ width: 56, height: 56, borderRadius: radius.md }} />
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 16, fontWeight: "800", color: colors.onSurface }}>{o.restaurant}</Text>
                  <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>{o.type} • RM {o.total.toFixed(2)}</Text>
                </View>
                {!live && (
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 4, alignSelf: "flex-start" }}>
                    <Text style={{ fontSize: 12, fontWeight: "700", color: colors.onSurfaceSecondary }}>{o.status}</Text>
                    <Ionicons name="checkmark-circle" size={15} color={colors.brandPrimary} />
                  </View>
                )}
              </Pressable>
              <View style={{ marginHorizontal: spacing.md, borderTopWidth: 1, borderTopColor: colors.divider, borderStyle: "dashed", paddingVertical: spacing.md }}>
                <Text style={{ fontSize: 13, color: colors.onSurfaceSecondary }} numberOfLines={1}>{itemsText[o.id] ?? `${o.items} items`}</Text>
                <Text style={{ fontSize: 12, color: colors.muted, marginTop: 4 }}>{o.date}</Text>
              </View>
              <View style={{ flexDirection: "row", gap: spacing.sm, paddingHorizontal: spacing.md, paddingBottom: spacing.md }}>
                <Pressable testID={`reorder-${o.id}`} onPress={() => router.push(o.type === "Pickup" ? "/pickup/restaurants" : o.type === "Dine-in" ? "/dine-in/scanner" : "/delivery/cart")} style={{ flex: 1, height: 42, borderRadius: radius.md, borderWidth: 1.5, borderColor: colors.brandPrimary, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 6 }}>
                  <Ionicons name="refresh" size={15} color={colors.brandPrimary} />
                  <Text style={{ fontSize: 13, fontWeight: "900", color: colors.brandPrimary }}>REORDER</Text>
                </Pressable>
                {!live && (
                  <Pressable testID={`rate-${o.id}`} onPress={() => router.push("/delivery/rate")} style={{ flex: 1, height: 42, borderRadius: radius.md, borderWidth: 1.5, borderColor: colors.border, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 6 }}>
                    <Ionicons name="star-outline" size={15} color={colors.onSurface} />
                    <Text style={{ fontSize: 13, fontWeight: "900", color: colors.onSurface }}>RATE ORDER</Text>
                  </Pressable>
                )}
              </View>
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
}
