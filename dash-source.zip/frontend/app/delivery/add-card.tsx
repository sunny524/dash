import { View, Pressable, Switch } from "react-native";
import { Text, TextInput } from "@/src/components/AppText";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { KeyboardAwareScrollView, KeyboardStickyView } from "react-native-keyboard-controller";
import Ionicons from "@react-native-vector-icons/ionicons";
import { useState } from "react";

import { useTheme, spacing, radius, shadow } from "@/src/theme";
import { ScreenHeader } from "@/src/components/ScreenHeader";
import { cardBrand, usePayment } from "@/src/data/payment-mock";

const formatNumber = (v: string) => v.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();
const formatExpiry = (v: string) => {
  const d = v.replace(/\D/g, "").slice(0, 4);
  return d.length > 2 ? `${d.slice(0, 2)}/${d.slice(2)}` : d;
};

// Mock "today" = June 2026
const NOW = { month: 6, year: 26 };

export default function AddCard() {
  const { colors } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const addCard = usePayment((s) => s.addCard);

  const [number, setNumber] = useState("");
  const [name, setName] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [save, setSave] = useState(true);
  const [touched, setTouched] = useState(false);

  const digits = number.replace(/\s/g, "");
  const brand = cardBrand(digits);
  const [mm, yy] = expiry.split("/").map(Number);

  const errors = {
    number: digits.length < 15 ? "Enter a valid card number" : "",
    name: name.trim().length < 2 ? "Enter the name on the card" : "",
    expiry: !(mm >= 1 && mm <= 12 && yy >= 0) || expiry.length < 5
      ? "Use MM/YY"
      : yy < NOW.year || (yy === NOW.year && mm < NOW.month) ? "This card has expired" : "",
    cvv: cvv.length < 3 ? "3 or 4 digits" : "",
  };
  const valid = !Object.values(errors).some(Boolean);

  const onSave = () => {
    setTouched(true);
    if (!valid) return;
    addCard({ digits, expiry });
    router.back();
  };

  const field = (key: keyof typeof errors) => (touched && errors[key] ? errors[key] : "");

  return (
    <View style={{ flex: 1, backgroundColor: colors.surfaceSecondary }}>
      <ScreenHeader title="Add new card" onBack={() => router.back()} />
      <KeyboardAwareScrollView
        contentContainerStyle={{ padding: spacing.lg, paddingBottom: 120 + insets.bottom, gap: spacing.md }}
        bottomOffset={100}
        keyboardShouldPersistTaps="handled"
      >
        {/* Live card preview */}
        <View testID="card-preview" style={{ backgroundColor: brand.tint, borderRadius: radius.lg, padding: spacing.lg, height: 190, justifyContent: "space-between", ...shadow.card }}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
            <View style={{ width: 40, height: 30, borderRadius: 6, backgroundColor: "rgba(255,255,255,0.35)" }} />
            <Text style={{ color: "#FFFFFF", fontSize: 16, fontWeight: "900", letterSpacing: 1 }}>{brand.badge}</Text>
          </View>
          <Text style={{ color: "#FFFFFF", fontSize: 20, fontWeight: "700", letterSpacing: 2 }}>
            {(number || "•••• •••• •••• ••••").padEnd(19, "•")}
          </Text>
          <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 10, fontWeight: "700" }}>CARD HOLDER</Text>
              <Text style={{ color: "#FFFFFF", fontSize: 13, fontWeight: "700", marginTop: 2 }} numberOfLines={1}>{name.toUpperCase() || "YOUR NAME"}</Text>
            </View>
            <View>
              <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 10, fontWeight: "700" }}>EXPIRES</Text>
              <Text style={{ color: "#FFFFFF", fontSize: 13, fontWeight: "700", marginTop: 2 }}>{expiry || "MM/YY"}</Text>
            </View>
          </View>
        </View>

        <View style={{ backgroundColor: colors.surface, borderRadius: radius.lg, padding: spacing.md, gap: spacing.md, ...shadow.card }}>
          <Field label="Card number" error={field("number")}>
            <TextInput
              testID="card-number"
              value={number}
              onChangeText={(v) => setNumber(formatNumber(v))}
              placeholder="1234 5678 9012 3456"
              placeholderTextColor={colors.muted}
              keyboardType="number-pad"
              style={inputStyle(colors, !!field("number"))}
            />
          </Field>
          <Field label="Name on card" error={field("name")}>
            <TextInput
              testID="card-name"
              value={name}
              onChangeText={setName}
              placeholder="Sunny Tan"
              placeholderTextColor={colors.muted}
              autoCapitalize="words"
              style={inputStyle(colors, !!field("name"))}
            />
          </Field>
          <View style={{ flexDirection: "row", gap: spacing.md }}>
            <View style={{ flex: 1 }}>
              <Field label="Expiry" error={field("expiry")}>
                <TextInput
                  testID="card-expiry"
                  value={expiry}
                  onChangeText={(v) => setExpiry(formatExpiry(v))}
                  placeholder="MM/YY"
                  placeholderTextColor={colors.muted}
                  keyboardType="number-pad"
                  style={inputStyle(colors, !!field("expiry"))}
                />
              </Field>
            </View>
            <View style={{ flex: 1 }}>
              <Field label="CVV" error={field("cvv")}>
                <TextInput
                  testID="card-cvv"
                  value={cvv}
                  onChangeText={(v) => setCvv(v.replace(/\D/g, "").slice(0, 4))}
                  placeholder="123"
                  placeholderTextColor={colors.muted}
                  keyboardType="number-pad"
                  secureTextEntry
                  style={inputStyle(colors, !!field("cvv"))}
                />
              </Field>
            </View>
          </View>
          <View style={{ flexDirection: "row", alignItems: "center", gap: spacing.md, paddingTop: 4 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 14, fontWeight: "700", color: colors.onSurface }}>Save card for next time</Text>
              <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>CVV is never stored</Text>
            </View>
            <Switch
              testID="card-save"
              value={save}
              onValueChange={setSave}
              trackColor={{ true: colors.brandPrimary, false: colors.borderStrong }}
              thumbColor="#FFFFFF"
              {...({ activeThumbColor: "#FFFFFF" } as object)}
            />
          </View>
        </View>

        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6 }}>
          <Ionicons name="lock-closed" size={13} color={colors.muted} />
          <Text style={{ fontSize: 11, color: colors.muted }}>Card details are encrypted and secure</Text>
        </View>
      </KeyboardAwareScrollView>

      <KeyboardStickyView offset={{ closed: 0, opened: -insets.bottom + 8 }}>
        <View style={{
          paddingHorizontal: spacing.lg, paddingTop: spacing.md, paddingBottom: insets.bottom + spacing.md,
          backgroundColor: colors.surface, borderTopWidth: 1, borderTopColor: colors.border,
        }}>
          <Pressable
            testID="save-card"
            onPress={onSave}
            style={{ backgroundColor: colors.brandPrimary, opacity: valid ? 1 : 0.6, paddingVertical: 15, borderRadius: radius.pill, alignItems: "center" }}
          >
            <Text style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "800" }}>{save ? "Save & use this card" : "Use this card"}</Text>
          </Pressable>
        </View>
      </KeyboardStickyView>
    </View>
  );
}

function Field({ label, error, children }: { label: string; error: string; children: React.ReactNode }) {
  const { colors } = useTheme();
  return (
    <View>
      <Text style={{ fontSize: 12, fontWeight: "700", color: colors.onSurfaceSecondary, marginBottom: 6 }}>{label}</Text>
      {children}
      {!!error && <Text style={{ fontSize: 11, color: colors.error, marginTop: 4 }}>{error}</Text>}
    </View>
  );
}

const inputStyle = (colors: ReturnType<typeof useTheme>["colors"], hasError: boolean) => ({
  height: 48, borderRadius: radius.md, borderWidth: 1.5,
  borderColor: hasError ? colors.error : colors.border,
  paddingHorizontal: spacing.md, fontSize: 15, color: colors.onSurface, backgroundColor: colors.surfaceSecondary,
});
