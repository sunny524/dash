import { View, Pressable, ScrollView } from "react-native";
import { Text } from "@/src/components/AppText";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Ionicons from "@react-native-vector-icons/ionicons";
import { useState } from "react";

import { useTheme, spacing, radius, shadow } from "@/src/theme";
import { ScreenHeader } from "@/src/components/ScreenHeader";
import { savedAddresses, type DeliveryAddress } from "@/src/data/delivery-mock";

export default function DeliveryAddress() {
  const { colors } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [selected, setSelected] = useState<string>(savedAddresses[0].id);

  return (
    <View style={{ flex: 1, backgroundColor: colors.surfaceSecondary }}>
      <ScreenHeader title="Delivery address" onBack={() => router.back()} />

      <ScrollView
        contentContainerStyle={{ padding: spacing.lg, paddingBottom: 120 + insets.bottom, gap: spacing.md }}
        showsVerticalScrollIndicator={false}
      >
        {/* Use current location */}
        <Pressable
          testID="use-current-location"
          onPress={() => setSelected("current")}
          style={{
            backgroundColor: colors.surface,
            borderRadius: radius.lg,
            padding: spacing.md,
            flexDirection: "row",
            alignItems: "center",
            gap: spacing.md,
            borderWidth: 1.5,
            borderColor: selected === "current" ? colors.brandPrimary : colors.border,
            ...shadow.card,
          }}
        >
          <View style={{
            width: 44, height: 44, borderRadius: 12,
            backgroundColor: colors.brandTertiary,
            alignItems: "center", justifyContent: "center",
          }}>
            <Ionicons name="locate" size={22} color={colors.brandPrimary} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 15, fontWeight: "800", color: colors.onSurface }}>Use current location</Text>
            <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>Automatically detect where you are</Text>
          </View>
          <Ionicons name="chevron-forward" size={18} color={colors.muted} />
        </Pressable>

        {/* Saved addresses */}
        <View style={{ marginTop: spacing.sm }}>
          <Text style={{ fontSize: 12, fontWeight: "800", color: colors.muted, letterSpacing: 0.4, marginBottom: spacing.sm }}>
            SAVED ADDRESSES
          </Text>
          <View style={{ gap: spacing.md }}>
            {savedAddresses.map((a) => (
              <AddressCard
                key={a.id}
                address={a}
                selected={selected === a.id}
                onSelect={() => setSelected(a.id)}
              />
            ))}
          </View>
        </View>

        {/* Add new */}
        <Pressable
          testID="add-new-address"
          style={{
            marginTop: spacing.sm,
            backgroundColor: colors.surface,
            borderRadius: radius.lg,
            padding: spacing.md,
            flexDirection: "row",
            alignItems: "center",
            gap: spacing.md,
            borderWidth: 1,
            borderStyle: "dashed",
            borderColor: colors.brandPrimary,
          }}
        >
          <View style={{
            width: 36, height: 36, borderRadius: 10,
            backgroundColor: colors.brandTertiary,
            alignItems: "center", justifyContent: "center",
          }}>
            <Ionicons name="add" size={20} color={colors.brandPrimary} />
          </View>
          <Text style={{ flex: 1, fontSize: 14, fontWeight: "800", color: colors.brandPrimary }}>
            Add a new address
          </Text>
        </Pressable>
      </ScrollView>

      {/* Sticky Continue */}
      <View style={{
        position: "absolute", bottom: 0, left: 0, right: 0,
        paddingHorizontal: spacing.lg, paddingTop: spacing.md,
        paddingBottom: insets.bottom + spacing.md,
        backgroundColor: colors.surface,
        borderTopWidth: 1, borderTopColor: colors.border,
      }}>
        <Pressable
          testID="address-continue"
          onPress={() => router.push("/delivery/quotes")}
          style={{
            backgroundColor: colors.brandPrimary,
            paddingVertical: 15, borderRadius: radius.pill,
            flexDirection: "row", alignItems: "center", justifyContent: "center",
            gap: 8,
          }}
        >
          <Text style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "800" }}>Continue</Text>
          <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
        </Pressable>
      </View>
    </View>
  );
}

function AddressCard({
  address,
  selected,
  onSelect,
}: {
  address: DeliveryAddress;
  selected: boolean;
  onSelect: () => void;
}) {
  const { colors } = useTheme();
  const tagIcon = address.tag === "Home" ? "home" : address.tag === "Office" ? "briefcase" : "location";

  return (
    <Pressable
      testID={`address-${address.id}`}
      onPress={onSelect}
      style={{
        backgroundColor: selected ? colors.brandTertiary : colors.surface,
        borderRadius: radius.lg,
        padding: spacing.md,
        flexDirection: "row",
        gap: spacing.md,
        borderWidth: 1.5,
        borderColor: selected ? colors.brandPrimary : colors.border,
        ...shadow.card,
      }}
    >
      <View style={{
        width: 44, height: 44, borderRadius: 12,
        backgroundColor: selected ? "#FFFFFF" : colors.brandTertiary,
        alignItems: "center", justifyContent: "center",
      }}>
        <Ionicons name={tagIcon as any} size={20} color={colors.brandPrimary} />
      </View>
      <View style={{ flex: 1 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
          <Text style={{ fontSize: 15, fontWeight: "800", color: colors.onSurface }}>{address.label}</Text>
          <View style={{
            paddingHorizontal: 8, paddingVertical: 2,
            borderRadius: radius.pill,
            backgroundColor: colors.surface,
            borderWidth: 1, borderColor: colors.border,
          }}>
            <Text style={{ fontSize: 10, fontWeight: "800", color: colors.muted }}>{address.distanceKm} km</Text>
          </View>
        </View>
        <Text style={{ fontSize: 13, color: colors.onSurfaceSecondary, marginTop: 4 }}>{address.line1}</Text>
        <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>{address.line2}</Text>
        {address.instructions && (
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 6 }}>
            <Ionicons name="information-circle" size={12} color={colors.muted} />
            <Text style={{ fontSize: 11, color: colors.muted, flex: 1 }} numberOfLines={1}>
              {address.instructions}
            </Text>
          </View>
        )}
      </View>
      <View style={{
        width: 22, height: 22, borderRadius: 11,
        borderWidth: 2, borderColor: selected ? colors.brandPrimary : colors.borderStrong,
        alignItems: "center", justifyContent: "center",
        backgroundColor: selected ? colors.brandPrimary : "transparent",
      }}>
        {selected && <Ionicons name="checkmark" size={14} color="#FFFFFF" />}
      </View>
    </Pressable>
  );
}
