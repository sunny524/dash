import { View, Pressable, ActivityIndicator } from "react-native";
import { Text, TextInput } from "@/src/components/AppText";
import { useRouter, useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { KeyboardAwareScrollView, KeyboardStickyView } from "react-native-keyboard-controller";
import Ionicons from "@react-native-vector-icons/ionicons";
import { useState } from "react";

import { useTheme, spacing, radius, shadow } from "@/src/theme";
import { courierQuotes, orderTotals } from "@/src/data/delivery-mock";
import { usePayment, getPaymentMethod, rewards } from "@/src/data/payment-mock";

type Step = "username" | "password" | "approve";

// Mock bank sign-in (FPX). Any username/password works.
export default function BankLogin() {
  const { colors } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { quoteId } = useLocalSearchParams<{ quoteId?: string }>();
  const { methodId, useRewards } = usePayment();
  const bank = getPaymentMethod(methodId);
  const quote = courierQuotes.find((q) => q.id === quoteId);
  const { total } = orderTotals(quote?.fee ?? 0, useRewards ? rewards.value : 0);

  const [step, setStep] = useState<Step>("username");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [phraseOk, setPhraseOk] = useState(false);
  const [loading, setLoading] = useState(false);

  const wait = (next: () => void) => {
    setLoading(true);
    setTimeout(() => { setLoading(false); next(); }, 900);
  };

  const onNext = () => {
    if (step === "username") return wait(() => setStep("password"));
    if (step === "password") return wait(() => setStep("approve"));
    wait(() => router.replace({ pathname: "/delivery/confirmation", params: { quoteId: quote?.id } }));
  };

  const canNext =
    step === "username" ? username.trim().length >= 3
    : step === "password" ? password.length >= 4 && phraseOk
    : true;

  const ctaLabel = step === "username" ? "Next" : step === "password" ? "Log in" : `Approve RM ${total.toFixed(2)}`;
  const stepIdx = ["username", "password", "approve"].indexOf(step);

  return (
    <View style={{ flex: 1, backgroundColor: colors.surfaceSecondary }}>
      {/* Bank-branded header */}
      <View style={{ backgroundColor: bank.tint, paddingTop: insets.top + spacing.sm, paddingBottom: spacing.lg, paddingHorizontal: spacing.lg }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: spacing.md }}>
          <Pressable testID="bank-cancel" onPress={() => router.back()} hitSlop={8} style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: "rgba(255,255,255,0.2)", alignItems: "center", justifyContent: "center" }}>
            <Ionicons name="close" size={22} color="#FFFFFF" />
          </Pressable>
          <View style={{ flex: 1 }}>
            <Text style={{ color: "#FFFFFF", fontSize: 18, fontWeight: "900" }}>{bank.label}</Text>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 2 }}>
              <Ionicons name="lock-closed" size={11} color="rgba(255,255,255,0.85)" />
              <Text style={{ color: "rgba(255,255,255,0.85)", fontSize: 11, fontWeight: "700" }}>Secure FPX online banking</Text>
            </View>
          </View>
          <View style={{ backgroundColor: "#FFFFFF", paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 }}>
            <Text style={{ color: bank.tint, fontSize: 12, fontWeight: "900" }}>{bank.badge}</Text>
          </View>
        </View>
      </View>

      <KeyboardAwareScrollView
        contentContainerStyle={{ padding: spacing.lg, paddingBottom: 120 + insets.bottom, gap: spacing.md }}
        bottomOffset={100}
        keyboardShouldPersistTaps="handled"
      >
        {/* Payment details */}
        <View style={{ backgroundColor: colors.surface, borderRadius: radius.lg, padding: spacing.md, gap: 8, ...shadow.card }}>
          <Row label="Pay to" value="Dash Sdn Bhd" />
          <Row label="Reference" value="DASH-24-A1247" />
          <View style={{ height: 1, backgroundColor: colors.divider }} />
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
            <Text style={{ fontSize: 13, color: colors.onSurfaceSecondary }}>Amount</Text>
            <Text testID="bank-amount" style={{ fontSize: 20, fontWeight: "800", color: colors.onSurface }}>RM {total.toFixed(2)}</Text>
          </View>
        </View>

        {/* Steps */}
        <View style={{ flexDirection: "row", gap: 6 }}>
          {["Username", "Password", "Approve"].map((s, i) => (
            <View key={s} style={{ flex: 1 }}>
              <View style={{ height: 4, borderRadius: 2, backgroundColor: i <= stepIdx ? bank.tint : colors.border }} />
              <Text style={{ fontSize: 11, fontWeight: "700", marginTop: 4, color: i <= stepIdx ? colors.onSurface : colors.muted }}>{s}</Text>
            </View>
          ))}
        </View>

        <View style={{ backgroundColor: colors.surface, borderRadius: radius.lg, padding: spacing.md, gap: spacing.md, ...shadow.card }}>
          {step === "username" && (
            <>
              <Text style={{ fontSize: 16, fontWeight: "800", color: colors.onSurface }}>Log in to your bank</Text>
              <TextInput
                testID="bank-username"
                value={username}
                onChangeText={setUsername}
                placeholder="Username"
                placeholderTextColor={colors.muted}
                autoCapitalize="none"
                style={input(colors)}
              />
              <Text style={{ fontSize: 11, color: colors.muted }}>Demo only — any username works.</Text>
            </>
          )}

          {step === "password" && (
            <>
              <Text style={{ fontSize: 16, fontWeight: "800", color: colors.onSurface }}>Hi {username}</Text>
              <Pressable
                testID="bank-phrase"
                onPress={() => setPhraseOk((v) => !v)}
                style={{ flexDirection: "row", alignItems: "center", gap: spacing.md, padding: spacing.md, borderRadius: radius.md, backgroundColor: colors.surfaceSecondary }}
              >
                <View style={{ width: 44, height: 44, borderRadius: 10, backgroundColor: colors.brandTertiary, alignItems: "center", justifyContent: "center" }}>
                  <Ionicons name="flower" size={22} color={colors.brandPrimary} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 11, fontWeight: "700", color: colors.muted }}>YOUR SECURITY PHRASE</Text>
                  <Text style={{ fontSize: 14, fontWeight: "800", color: colors.onSurface, marginTop: 2 }}>&quot;Hibiscus by the sea&quot;</Text>
                  <Text style={{ fontSize: 11, color: colors.muted, marginTop: 2 }}>Tap to confirm this is yours</Text>
                </View>
                <Ionicons name={phraseOk ? "checkbox" : "square-outline"} size={22} color={phraseOk ? colors.brandPrimary : colors.borderStrong} />
              </Pressable>
              <TextInput
                testID="bank-password"
                value={password}
                onChangeText={setPassword}
                placeholder="Password"
                placeholderTextColor={colors.muted}
                secureTextEntry
                style={input(colors)}
              />
            </>
          )}

          {step === "approve" && (
            <>
              <View style={{ alignItems: "center", gap: 6, paddingVertical: spacing.sm }}>
                <View style={{ width: 56, height: 56, borderRadius: 28, backgroundColor: colors.brandTertiary, alignItems: "center", justifyContent: "center" }}>
                  <Ionicons name="shield-checkmark" size={28} color={colors.brandPrimary} />
                </View>
                <Text style={{ fontSize: 16, fontWeight: "800", color: colors.onSurface }}>Approve this payment</Text>
                <Text style={{ fontSize: 12, color: colors.muted, textAlign: "center" }}>
                  From Savings Account ••••7821 · Balance RM 3,482.15
                </Text>
              </View>
            </>
          )}
        </View>
      </KeyboardAwareScrollView>

      <KeyboardStickyView offset={{ closed: 0, opened: -insets.bottom + 8 }}>
        <View style={{
          paddingHorizontal: spacing.lg, paddingTop: spacing.md, paddingBottom: insets.bottom + spacing.md,
          backgroundColor: colors.surface, borderTopWidth: 1, borderTopColor: colors.border,
        }}>
          <Pressable
            testID="bank-next"
            onPress={onNext}
            disabled={!canNext || loading}
            style={{ backgroundColor: bank.tint, opacity: canNext ? 1 : 0.5, paddingVertical: 15, borderRadius: radius.pill, alignItems: "center" }}
          >
            {loading ? <ActivityIndicator color="#FFFFFF" /> : (
              <Text style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "800" }}>{ctaLabel}</Text>
            )}
          </Pressable>
        </View>
      </KeyboardStickyView>
    </View>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  const { colors } = useTheme();
  return (
    <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
      <Text style={{ fontSize: 13, color: colors.onSurfaceSecondary }}>{label}</Text>
      <Text style={{ fontSize: 13, fontWeight: "700", color: colors.onSurface }}>{value}</Text>
    </View>
  );
}

const input = (colors: ReturnType<typeof useTheme>["colors"]) => ({
  height: 48, borderRadius: radius.md, borderWidth: 1.5, borderColor: colors.border,
  paddingHorizontal: spacing.md, fontSize: 15, color: colors.onSurface, backgroundColor: colors.surfaceSecondary,
});
