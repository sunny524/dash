import { View, Pressable } from "react-native";
import { Text, TextInput } from "@/src/components/AppText";
import { Image } from "expo-image";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { KeyboardAwareScrollView, KeyboardStickyView } from "react-native-keyboard-controller";
import Ionicons from "@react-native-vector-icons/ionicons";

import { useTheme, spacing, radius, shadow } from "@/src/theme";
import { ScreenHeader } from "@/src/components/ScreenHeader";
import { courierQuotes, orderTotals, promo } from "@/src/data/delivery-mock";
import { useCart, pointsFor, cartRestaurant } from "@/src/data/cart-store";
import { usePayment, getPaymentMethod, rewards } from "@/src/data/payment-mock";
import { useSchedule, slotLabel } from "@/src/data/schedule-mock";
import { ScheduleSheet } from "@/src/components/ScheduleSheet";
import { useState } from "react";

const cheapestFee = Math.min(...courierQuotes.map((q) => q.fee));

export default function Cart() {
  const { colors } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { lines: items, add, remove } = useCart();

  const { methodId, useRewards } = usePayment();
  const slot = useSchedule((s) => s.slot);
  const [showSchedule, setShowSchedule] = useState(false);
  const payMethod = getPaymentMethod(methodId);
  const { subtotal, discount, rewardsOff, total } = orderTotals(0, useRewards ? rewards.value : 0);

  if (items.length === 0) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.surface }}>
        <ScreenHeader title="Checkout" onBack={() => router.back()} />
        <View testID="cart-empty" style={{ flex: 1, alignItems: "center", justifyContent: "center", padding: spacing.xl }}>
          <View style={{ width: 96, height: 96, borderRadius: 48, backgroundColor: colors.surfaceSecondary, alignItems: "center", justifyContent: "center" }}>
            <Ionicons name="fast-food" size={42} color={colors.warning} />
          </View>
          <Text style={{ fontSize: 18, fontWeight: "900", color: colors.onSurface, marginTop: spacing.lg }}>Your cart is empty</Text>
          <Text style={{ fontSize: 13, color: colors.muted, marginTop: 4, textAlign: "center" }}>Add dishes from a restaurant menu to see them here</Text>
          <Pressable testID="cart-browse" onPress={() => router.push("/delivery/restaurant/r1")} style={{ marginTop: spacing.lg, backgroundColor: colors.brandPrimary, paddingHorizontal: spacing.xl, height: 48, borderRadius: radius.pill, justifyContent: "center" }}>
            <Text style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "800" }}>Browse the menu</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.surfaceSecondary }}>
      <ScreenHeader title="Checkout" onBack={() => router.back()} />
      <KeyboardAwareScrollView
        contentContainerStyle={{ padding: spacing.lg, paddingBottom: 140 + insets.bottom, gap: spacing.md }}
        bottomOffset={100}
        keyboardShouldPersistTaps="handled"
      >
        {/* Savings banner */}
        {discount + rewardsOff > 0 ? (
        <View testID="savings-banner" style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, backgroundColor: colors.brandTertiary, borderRadius: radius.md, paddingVertical: 10, borderWidth: 1, borderColor: colors.brandSecondary }}>
          <Text style={{ fontSize: 14 }}>🎉</Text>
          <Text style={{ fontSize: 13, fontWeight: "800", color: colors.brandPrimary }}>
            You saved RM {(discount + rewardsOff).toFixed(2)} on this order
          </Text>
        </View>
        ) : (
          <View testID="promo-nudge" style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, backgroundColor: colors.surface, borderRadius: radius.md, paddingVertical: 10, borderWidth: 1, borderColor: colors.border, borderStyle: "dashed" }}>
            <Ionicons name="pricetag" size={14} color={colors.warning} />
            <Text style={{ fontSize: 13, fontWeight: "700", color: colors.onSurface }}>
              Add RM {(promo.minSpend - subtotal).toFixed(2)} more to save RM {promo.amount.toFixed(2)} with {promo.code}
            </Text>
          </View>
        )}

        {/* Delivery address */}
        <Card>
          <SectionRow icon="location" title="Deliver to" edit="Change" onEdit={() => router.push("/delivery/address")}>
            <Text style={{ fontSize: 14, fontWeight: "700", color: colors.onSurface }}>Home</Text>
            <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>12A, Jalan Bukit Bintang, 55100 Kuala Lumpur</Text>
          </SectionRow>
        </Card>

        {/* Delivery time */}
        <Card>
          <SectionRow icon="time" title="Delivery time" edit={slot ? "Change" : "Schedule"} onEdit={() => setShowSchedule(true)}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
              <View style={{ paddingHorizontal: 8, paddingVertical: 2, borderRadius: radius.pill, backgroundColor: colors.brandTertiary }}>
                <Text style={{ fontSize: 10, fontWeight: "800", color: colors.brandPrimary }}>{slot ? "SCHEDULED" : "ASAP"}</Text>
              </View>
              <Text testID="cart-delivery-time" style={{ fontSize: 14, fontWeight: "700", color: colors.onSurface, flexShrink: 1 }}>
                {slot ? slotLabel(slot) : "Arriving in 20-30 min"}
              </Text>
            </View>
          </SectionRow>
        </Card>

        {/* Items */}
        <Card>
          <View style={{ padding: spacing.md }}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: spacing.md }}>
              <Text style={{ fontSize: 15, fontWeight: "800", color: colors.onSurface }}>{cartRestaurant().name}</Text>
              <Pressable testID="cart-add-items" onPress={() => router.push(`/delivery/restaurant/${cartRestaurant().id}`)}><Text style={{ fontSize: 13, fontWeight: "700", color: colors.brandPrimary }}>+ Add items</Text></Pressable>
            </View>
            {items.map((it, i) => (
              <View key={it.id} testID={`cart-line-${it.id}`} style={{
                flexDirection: "row", alignItems: "center", gap: spacing.md,
                paddingVertical: spacing.md,
                borderTopWidth: i === 0 ? 0 : 1, borderTopColor: colors.divider,
              }}>
                <Image source={{ uri: it.image }} style={{ width: 56, height: 56, borderRadius: radius.md }} />
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 14, fontWeight: "700", color: colors.onSurface }}>{it.name}</Text>
                  <Text style={{ fontSize: 11, color: colors.muted, marginTop: 2 }} numberOfLines={1}>{it.addons}</Text>
                  <Text style={{ fontSize: 14, fontWeight: "800", color: colors.onSurface, marginTop: 4 }}>RM {(it.price * it.qty).toFixed(2)}</Text>
                </View>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: colors.surfaceSecondary, borderRadius: radius.pill, paddingHorizontal: 6, height: 32 }}>
                  <Pressable testID={`cart-minus-${it.id}`} onPress={() => remove(it.id)} hitSlop={8} style={{ width: 24, height: 24, borderRadius: 12, alignItems: "center", justifyContent: "center" }}>
                    <Ionicons name={it.qty === 1 ? "trash-outline" : "remove"} size={14} color={colors.onSurface} />
                  </Pressable>
                  <Text testID={`cart-qty-${it.id}`} style={{ fontSize: 13, fontWeight: "800", color: colors.onSurface, minWidth: 14, textAlign: "center" }}>{it.qty}</Text>
                  <Pressable testID={`cart-plus-${it.id}`} onPress={() => add(it.id)} hitSlop={8} style={{ width: 24, height: 24, borderRadius: 12, backgroundColor: colors.brandPrimary, alignItems: "center", justifyContent: "center" }}>
                    <Ionicons name="add" size={14} color="#FFFFFF" />
                  </Pressable>
                </View>
              </View>
            ))}
          </View>
        </Card>

        {/* Promo code */}
        <Card>
          <View style={{ flexDirection: "row", alignItems: "center", gap: spacing.md, padding: spacing.md }}>
            <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: colors.brandTertiary, alignItems: "center", justifyContent: "center" }}>
              <Ionicons name="pricetag" size={18} color={colors.brandPrimary} />
            </View>
            <TextInput
              placeholder="Enter promo code"
              placeholderTextColor={colors.muted}
              style={{ flex: 1, fontSize: 14, color: colors.onSurface }}
              defaultValue={promo.code}
            />
            <View style={{ backgroundColor: colors.brandTertiary, paddingHorizontal: 10, paddingVertical: 5, borderRadius: radius.pill }}>
              <Text style={{ fontSize: 11, fontWeight: "800", color: colors.brandPrimary }}>{discount > 0 ? "APPLIED" : `MIN RM${promo.minSpend}`}</Text>
            </View>
          </View>
        </Card>

        {/* Payment */}
        <Card>
          <SectionRow icon="card" title="Payment method" edit="Change" onEdit={() => router.push({ pathname: "/delivery/payment", params: { mode: "select" } })}>
            <Text testID="cart-payment-label" style={{ fontSize: 14, fontWeight: "700", color: colors.onSurface }}>{payMethod.label}</Text>
            {payMethod.sub && <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>{payMethod.sub}</Text>}
          </SectionRow>
        </Card>

        {/* Summary */}
        <Card>
          <View style={{ padding: spacing.md, gap: 8 }}>
            <Text style={{ fontSize: 15, fontWeight: "900", color: colors.onSurface, marginBottom: 2 }}>Bill Details</Text>
            <SumRow label="Item total" value={`RM ${subtotal.toFixed(2)}`} />
            {discount > 0 && <SumRow label={`Promo ${promo.code}`} value={`− RM ${discount.toFixed(2)}`} accent />}
            {rewardsOff > 0 && <SumRow label="Dash reward points" value={`− RM ${rewardsOff.toFixed(2)}`} accent />}
            <SumRow label="Delivery fee" value={`From RM ${cheapestFee.toFixed(2)}`} />
            <Text style={{ fontSize: 11, color: colors.muted }}>You&apos;ll pick a courier on the next step.</Text>
            <View style={{ height: 1, backgroundColor: colors.divider, marginVertical: 6 }} />
            <SumRow label="Total before delivery" value={`RM ${total.toFixed(2)}`} bold />
            <View testID="cart-points" style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 4, backgroundColor: colors.brandTertiary, borderRadius: radius.sm, paddingHorizontal: 8, paddingVertical: 6 }}>
              <Ionicons name="gift" size={13} color={colors.brandPrimary} />
              <Text style={{ fontSize: 12, fontWeight: "700", color: colors.onSurface }}>
                You&apos;ll earn <Text style={{ fontWeight: "900", color: colors.brandPrimary }}>{pointsFor(total)} DashPoints</Text> on this order
              </Text>
            </View>
          </View>
        </Card>
      </KeyboardAwareScrollView>

      <KeyboardStickyView offset={{ closed: 0, opened: -insets.bottom + 8 }}>
        <View style={{
          paddingHorizontal: spacing.lg, paddingTop: spacing.md,
          paddingBottom: insets.bottom + spacing.md,
          backgroundColor: colors.surface,
          borderTopWidth: 1, borderTopColor: colors.border,
        }}>
          <Pressable
            testID="place-order-cta"
            onPress={() => router.push("/delivery/address")}
            style={{
              backgroundColor: colors.brandPrimary,
              paddingVertical: 14, borderRadius: radius.pill,
              flexDirection: "row", alignItems: "center", paddingHorizontal: spacing.lg,
            }}
          >
            <Text style={{ flex: 1, color: "#FFFFFF", fontSize: 15, fontWeight: "800" }}>Checkout</Text>
            <Text style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "800" }}>RM {total.toFixed(2)}</Text>
            <Ionicons name="arrow-forward" size={18} color="#FFFFFF" style={{ marginLeft: 8 }} />
          </Pressable>
        </View>
      </KeyboardStickyView>
      {showSchedule && <ScheduleSheet visible onClose={() => setShowSchedule(false)} />}
    </View>
  );
}

function Card({ children }: { children: React.ReactNode }) {
  const { colors } = useTheme();
  return <View style={{ backgroundColor: colors.surface, borderRadius: radius.lg, ...shadow.card }}>{children}</View>;
}
function SectionRow({ icon, title, edit, onEdit, children }: { icon: string; title: string; edit?: string; onEdit?: () => void; children: React.ReactNode }) {
  const { colors } = useTheme();
  return (
    <View style={{ flexDirection: "row", alignItems: "flex-start", gap: spacing.md, padding: spacing.md }}>
      <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: colors.brandTertiary, alignItems: "center", justifyContent: "center" }}>
        <Ionicons name={icon as any} size={18} color={colors.brandPrimary} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 11, color: colors.muted, fontWeight: "700", marginBottom: 2 }}>{title.toUpperCase()}</Text>
        {children}
      </View>
      {edit && <Pressable testID={`edit-${title.toLowerCase().replace(/ /g, "-")}`} onPress={onEdit} hitSlop={8}><Text style={{ fontSize: 13, fontWeight: "700", color: colors.brandPrimary }}>{edit}</Text></Pressable>}
    </View>
  );
}
function SumRow({ label, value, bold, accent }: { label: string; value: string; bold?: boolean; accent?: boolean }) {
  const { colors } = useTheme();
  return (
    <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
      <Text style={{ fontSize: bold ? 15 : 13, fontWeight: bold ? "800" : "500", color: bold ? colors.onSurface : colors.onSurfaceSecondary }}>{label}</Text>
      <Text style={{ fontSize: bold ? 17 : 13, fontWeight: bold ? "800" : "600", color: accent ? colors.brandPrimary : colors.onSurface }}>{value}</Text>
    </View>
  );
}
