import { View, Pressable, ScrollView } from "react-native";
import { Text } from "@/src/components/AppText";
import { useRouter, useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Ionicons from "@react-native-vector-icons/ionicons";

import { useTheme, spacing, radius, shadow, type } from "@/src/theme";
import { courierQuotes, savedAddresses, orderTotals, promo, cartItemCount } from "@/src/data/delivery-mock";
import { usePayment, getPaymentMethod, rewards } from "@/src/data/payment-mock";
import { pointsFor, cartRestaurant } from "@/src/data/cart-store";
import { useSchedule, slotLabel } from "@/src/data/schedule-mock";

export default function DeliveryConfirmation() {
  const { colors } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { quoteId } = useLocalSearchParams<{ quoteId?: string }>();

  const quote = courierQuotes.find((q) => q.id === quoteId) ?? courierQuotes[0];
  const address = savedAddresses[0];

  const orderNumber = "DASH-24-A1247";
  const { methodId, useRewards } = usePayment();
  const payMethod = getPaymentMethod(methodId);
  const isCod = payMethod.group === "cod";
  const slot = useSchedule((s) => s.slot);
  const { subtotal, discount, rewardsOff, total } = orderTotals(quote.fee, useRewards ? rewards.value : 0);

  return (
    <View style={{ flex: 1, backgroundColor: colors.surfaceSecondary }}>
      {/* Hero */}
      <View style={{
        paddingTop: insets.top + spacing.md,
        paddingBottom: spacing.xl,
        paddingHorizontal: spacing.lg,
        alignItems: "center",
        backgroundColor: colors.brandPrimary,
        borderBottomLeftRadius: 28,
        borderBottomRightRadius: 28,
      }}>
        <View style={{
          width: 88, height: 88, borderRadius: 44,
          backgroundColor: "rgba(255,255,255,0.18)",
          alignItems: "center", justifyContent: "center",
          borderWidth: 4, borderColor: "rgba(255,255,255,0.3)",
          marginTop: spacing.md,
        }}>
          <Ionicons name="checkmark" size={46} color="#FFFFFF" />
        </View>
        <Text style={{ ...type.headline, fontWeight: "800", color: "#FFFFFF", marginTop: spacing.md }}>
          Order confirmed!
        </Text>
        <Text style={{ fontSize: 13, color: "rgba(255,255,255,0.9)", marginTop: 4 }}>
          {slot ? "We'll deliver at your chosen time 📅" : "Your food is on the way 🎉"}
        </Text>
        <View style={{
          marginTop: spacing.md,
          paddingHorizontal: 12, paddingVertical: 6,
          borderRadius: radius.pill,
          backgroundColor: "rgba(255,255,255,0.2)",
        }}>
          <Text style={{ fontSize: 12, fontWeight: "800", color: "#FFFFFF", letterSpacing: 0.5 }}>
            Order #{orderNumber}
          </Text>
        </View>
      </View>

      <ScrollView
        contentContainerStyle={{ padding: spacing.lg, paddingBottom: 140 + insets.bottom, gap: spacing.md }}
        showsVerticalScrollIndicator={false}
      >
        {/* ETA card */}
        <View style={{
          backgroundColor: colors.surface,
          borderRadius: radius.lg,
          padding: spacing.md,
          flexDirection: "row",
          alignItems: "center",
          gap: spacing.md,
          ...shadow.card,
        }}>
          <View style={{
            width: 48, height: 48, borderRadius: 14,
            backgroundColor: colors.brandTertiary,
            alignItems: "center", justifyContent: "center",
          }}>
            <Ionicons name={slot ? "calendar" : "time"} size={22} color={colors.brandPrimary} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 11, fontWeight: "800", color: colors.muted, letterSpacing: 0.4 }}>
              {slot ? "SCHEDULED DELIVERY" : "ESTIMATED ARRIVAL"}
            </Text>
            <Text testID="confirmation-eta" style={{ fontSize: 16, fontWeight: "800", color: colors.onSurface, marginTop: 2 }}>
              {slot ? slotLabel(slot) : quote.etaLabel}
            </Text>
          </View>
          <View style={{
            paddingHorizontal: 10, paddingVertical: 5,
            borderRadius: radius.pill,
            backgroundColor: colors.brandTertiary,
          }}>
            <Text style={{ fontSize: 11, fontWeight: "800", color: colors.brandPrimary }}>
              {quote.logoChar} · {quote.name.split(" ")[0]}
            </Text>
          </View>
        </View>

        {/* Delivery address */}
        <View style={{
          backgroundColor: colors.surface,
          borderRadius: radius.lg,
          padding: spacing.md,
          ...shadow.card,
        }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginBottom: spacing.sm }}>
            <Ionicons name="location" size={16} color={colors.brandPrimary} />
            <Text style={{ fontSize: 14, fontWeight: "800", color: colors.onSurface }}>
              Delivering to {address.label}
            </Text>
          </View>
          <Text style={{ fontSize: 13, color: colors.onSurfaceSecondary, marginLeft: 24 }}>
            {address.line1}
          </Text>
          <Text style={{ fontSize: 12, color: colors.muted, marginLeft: 24, marginTop: 2 }}>
            {address.line2}
          </Text>
        </View>

        {/* Order summary */}
        <View style={{
          backgroundColor: colors.surface,
          borderRadius: radius.lg,
          padding: spacing.md,
          gap: 8,
          ...shadow.card,
        }}>
          <Text style={{ fontSize: 14, fontWeight: "800", color: colors.onSurface, marginBottom: 4 }}>
            Order summary
          </Text>
          <SumRow label={cartRestaurant().name} value={`${cartItemCount()} items`} sub />
          <View style={{ height: 1, backgroundColor: colors.divider, marginVertical: 4 }} />
          <SumRow label="Subtotal" value={`RM ${subtotal.toFixed(2)}`} />
          {discount > 0 && <SumRow label={`Promo ${promo.code}`} value={`− RM ${discount.toFixed(2)}`} />}
          {rewardsOff > 0 && <SumRow label="Dash reward points" value={`− RM ${rewardsOff.toFixed(2)}`} />}
          <SumRow label={`Delivery · ${quote.name}`} value={`RM ${quote.fee.toFixed(2)}`} />
          <View style={{ height: 1, backgroundColor: colors.divider, marginVertical: 4 }} />
          <SumRow label={isCod ? "To pay on delivery" : "Total paid"} value={`RM ${total.toFixed(2)}`} bold />
          <View testID="confirmation-points" style={{ flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: colors.brandTertiary, borderRadius: radius.sm, paddingHorizontal: 8, paddingVertical: 6 }}>
            <Ionicons name="gift" size={13} color={colors.brandPrimary} />
            <Text style={{ fontSize: 12, fontWeight: "800", color: colors.brandPrimary }}>+{pointsFor(total)} DashPoints {isCod ? "after delivery" : "earned"}</Text>
          </View>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 4 }}>
            <Ionicons name={isCod ? "cash-outline" : "checkmark-circle"} size={14} color={colors.brandPrimary} />
            <Text testID="confirmation-paid-with" style={{ fontSize: 12, color: colors.muted }}>
              {isCod ? "Pay the rider in cash when your food arrives" : `Paid with ${payMethod.label}`}
            </Text>
          </View>
        </View>
      </ScrollView>

      {/* Sticky CTAs */}
      <View style={{
        position: "absolute", bottom: 0, left: 0, right: 0,
        paddingHorizontal: spacing.lg, paddingTop: spacing.md,
        paddingBottom: insets.bottom + spacing.md,
        backgroundColor: colors.surface,
        borderTopWidth: 1, borderTopColor: colors.border,
        gap: 8,
      }}>
        <Pressable
          testID="track-delivery"
          onPress={() => router.replace({ pathname: "/delivery/tracking", params: { quoteId: quote.id } })}
          style={{
            backgroundColor: colors.brandPrimary,
            paddingVertical: 15, borderRadius: radius.pill,
            flexDirection: "row", alignItems: "center", justifyContent: "center",
            gap: 8,
          }}
        >
          <Ionicons name="navigate-circle" size={18} color="#FFFFFF" />
          <Text style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "800" }}>Track your delivery</Text>
        </Pressable>
        <Pressable
          testID="back-home"
          onPress={() => router.replace("/(tabs)/home")}
          style={{
            paddingVertical: 12, borderRadius: radius.pill,
            alignItems: "center", justifyContent: "center",
          }}
        >
          <Text style={{ color: colors.onSurfaceSecondary, fontSize: 13, fontWeight: "700" }}>
            Continue shopping
          </Text>
        </Pressable>
      </View>
    </View>
  );
}

function SumRow({ label, value, bold, sub }: { label: string; value: string; bold?: boolean; sub?: boolean }) {
  const { colors } = useTheme();
  return (
    <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
      <Text style={{
        fontSize: bold ? 15 : 13,
        fontWeight: bold ? "800" : sub ? "700" : "500",
        color: sub ? colors.onSurface : (bold ? colors.onSurface : colors.onSurfaceSecondary),
      }} numberOfLines={1}>
        {label}
      </Text>
      <Text style={{ fontSize: bold ? 17 : 13, fontWeight: bold ? "800" : sub ? "600" : "600", color: sub ? colors.muted : colors.onSurface }}>
        {value}
      </Text>
    </View>
  );
}
