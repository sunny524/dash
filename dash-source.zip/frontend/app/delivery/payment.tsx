import { View, Pressable, ScrollView, Switch, ActivityIndicator } from "react-native";
import { Text } from "@/src/components/AppText";
import { useRouter, useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Ionicons from "@react-native-vector-icons/ionicons";
import { useState } from "react";

import { useTheme, spacing, radius, shadow } from "@/src/theme";
import { ScreenHeader } from "@/src/components/ScreenHeader";
import { courierQuotes, orderTotals, cartItemCount, savedAddresses } from "@/src/data/delivery-mock";
import { paymentGroups, rewards, usePayment, getPaymentMethod, type PaymentMethod } from "@/src/data/payment-mock";

export default function Payment() {
  const { colors } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { quoteId, mode } = useLocalSearchParams<{ quoteId?: string; mode?: string }>();
  const selecting = mode === "select";

  const { methodId, setMethod, useRewards, setUseRewards, methods } = usePayment();
  const [processing, setProcessing] = useState(false);

  const quote = courierQuotes.find((q) => q.id === quoteId);
  const { total } = orderTotals(quote?.fee ?? 0, useRewards ? rewards.value : 0);
  const method = getPaymentMethod(methodId);
  const address = savedAddresses[0];

  const onPay = () => {
    if (selecting) return router.back();
    if (method.group === "fpx") {
      return router.push({ pathname: "/delivery/bank-login", params: { quoteId: quote?.id } });
    }
    setProcessing(true);
    setTimeout(() => {
      setProcessing(false);
      router.push({ pathname: "/delivery/confirmation", params: { quoteId: quote?.id } });
    }, 1400);
  };

  const ctaLabel = selecting
    ? `Use ${method.label}`
    : method.group === "cod"
      ? `Place order · RM ${total.toFixed(2)}`
      : method.group === "fpx"
        ? `Continue to ${method.label}`
        : `Pay RM ${total.toFixed(2)}`;

  return (
    <View style={{ flex: 1, backgroundColor: colors.surfaceSecondary }}>
      <ScreenHeader title="Payment options" onBack={() => router.back()} />

      <ScrollView
        contentContainerStyle={{ padding: spacing.lg, paddingBottom: 130 + insets.bottom, gap: spacing.md }}
        showsVerticalScrollIndicator={false}
      >
        {/* Order strip */}
        <View testID="payment-summary" style={{ backgroundColor: colors.surface, borderRadius: radius.lg, padding: spacing.md, ...shadow.card }}>
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 11, fontWeight: "800", color: colors.muted, letterSpacing: 0.4 }}>
                {selecting ? "TOTAL BEFORE DELIVERY" : "TO PAY"}
              </Text>
              <Text style={{ fontSize: 22, fontWeight: "800", color: colors.onSurface, marginTop: 2 }}>RM {total.toFixed(2)}</Text>
            </View>
            <View style={{ alignItems: "flex-end" }}>
              <Text style={{ fontSize: 12, fontWeight: "700", color: colors.onSurface }}>Nasi Lemak Village</Text>
              <Text style={{ fontSize: 11, color: colors.muted, marginTop: 2 }}>{cartItemCount()} items{quote ? ` · ETA ${quote.etaLabel}` : ""}</Text>
            </View>
          </View>
          <View style={{ height: 1, backgroundColor: colors.divider, marginVertical: spacing.md }} />
          <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
            <Ionicons name="location" size={14} color={colors.brandPrimary} />
            <Text style={{ fontSize: 12, color: colors.onSurfaceSecondary, flex: 1 }} numberOfLines={1}>
              Deliver to {address.label} · {address.line1}
            </Text>
          </View>
        </View>

        {paymentGroups.map((g) => (
          <View key={g.key} style={{ gap: spacing.sm }}>
            <Text style={{ fontSize: 12, fontWeight: "800", color: colors.muted, letterSpacing: 0.5, marginTop: spacing.sm }}>
              {g.title.toUpperCase()}
            </Text>
            <View style={{ backgroundColor: colors.surface, borderRadius: radius.lg, overflow: "hidden", ...shadow.card }}>
              {g.key === "fpx" ? (
                <BankGrid methods={methods.filter((m) => m.group === "fpx")} selectedId={methodId} onSelect={setMethod} />
              ) : (
                methods.filter((m) => m.group === g.key).map((m, i) => (
                  <MethodRow key={m.id} method={m} first={i === 0} selected={methodId === m.id} onPress={() => setMethod(m.id)} />
                ))
              )}

              {g.key === "dash" && (
                <View style={{ flexDirection: "row", alignItems: "center", gap: spacing.md, padding: spacing.md }}>
                  <View style={{ width: 40, height: 40, borderRadius: 12, backgroundColor: colors.brandTertiary, alignItems: "center", justifyContent: "center" }}>
                    <Ionicons name="gift" size={18} color={colors.brandPrimary} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 14, fontWeight: "700", color: colors.onSurface }}>Use {rewards.redeemPoints} reward points</Text>
                    <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>
                      Save RM {rewards.value.toFixed(2)} · You have {rewards.points.toLocaleString()} pts
                    </Text>
                  </View>
                  <Switch
                    testID="use-rewards"
                    value={useRewards}
                    onValueChange={setUseRewards}
                    trackColor={{ true: colors.brandPrimary, false: colors.borderStrong }}
                    thumbColor="#FFFFFF"
                    {...({ activeThumbColor: "#FFFFFF" } as object)}
                  />
                </View>
              )}

              {g.key === "card" && (
                <Pressable testID="add-card" onPress={() => router.push("/delivery/add-card")} style={{ flexDirection: "row", alignItems: "center", gap: spacing.md, padding: spacing.md, borderTopWidth: 1, borderTopColor: colors.divider }}>
                  <View style={{ width: 40, height: 40, borderRadius: 12, borderWidth: 1.5, borderStyle: "dashed", borderColor: colors.brandPrimary, alignItems: "center", justifyContent: "center" }}>
                    <Ionicons name="add" size={20} color={colors.brandPrimary} />
                  </View>
                  <Text style={{ flex: 1, fontSize: 14, fontWeight: "800", color: colors.brandPrimary }}>Add new card</Text>
                  <Ionicons name="chevron-forward" size={18} color={colors.muted} />
                </Pressable>
              )}
            </View>
          </View>
        ))}

        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, marginTop: spacing.sm }}>
          <Ionicons name="shield-checkmark" size={14} color={colors.muted} />
          <Text style={{ fontSize: 11, color: colors.muted }}>100% secure payments</Text>
        </View>
      </ScrollView>

      {/* Sticky pay bar */}
      <View style={{
        position: "absolute", bottom: 0, left: 0, right: 0,
        paddingHorizontal: spacing.lg, paddingTop: spacing.md,
        paddingBottom: insets.bottom + spacing.md,
        backgroundColor: colors.surface, borderTopWidth: 1, borderTopColor: colors.border,
        flexDirection: "row", alignItems: "center", gap: spacing.md,
      }}>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 11, fontWeight: "700", color: colors.muted }}>{selecting ? "SELECTED" : "PAY USING"}</Text>
          <Text style={{ fontSize: 13, fontWeight: "800", color: colors.onSurface, marginTop: 2 }} numberOfLines={1}>{method.label}</Text>
        </View>
        <Pressable
          testID="pay-button"
          onPress={onPay}
          disabled={processing}
          style={{
            flex: 1.6, backgroundColor: colors.brandPrimary, paddingVertical: 15, borderRadius: radius.pill,
            alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 8,
          }}
        >
          {processing ? <ActivityIndicator color="#FFFFFF" /> : (
            <Text style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "800" }} numberOfLines={1}>{ctaLabel}</Text>
          )}
        </Pressable>
      </View>
    </View>
  );
}

function LogoTile({ m, size = 40 }: { m: PaymentMethod; size?: number }) {
  return (
    <View style={{ width: size, height: size, borderRadius: 12, backgroundColor: m.tint, alignItems: "center", justifyContent: "center" }}>
      <Text style={{ color: "#FFFFFF", fontSize: m.badge.length > 2 ? 10 : 14, fontWeight: "900" }}>{m.badge}</Text>
    </View>
  );
}

function Radio({ on }: { on: boolean }) {
  const { colors } = useTheme();
  return (
    <View style={{
      width: 22, height: 22, borderRadius: 11, borderWidth: 2,
      borderColor: on ? colors.brandPrimary : colors.borderStrong,
      backgroundColor: on ? colors.brandPrimary : "transparent",
      alignItems: "center", justifyContent: "center",
    }}>
      {on && <Ionicons name="checkmark" size={13} color="#FFFFFF" />}
    </View>
  );
}

function MethodRow({ method, selected, first, onPress }: { method: PaymentMethod; selected: boolean; first: boolean; onPress: () => void }) {
  const { colors } = useTheme();
  return (
    <Pressable
      testID={`pay-${method.id}`}
      onPress={onPress}
      style={{
        flexDirection: "row", alignItems: "center", gap: spacing.md, padding: spacing.md,
        borderTopWidth: first ? 0 : 1, borderTopColor: colors.divider,
        backgroundColor: selected ? colors.brandTertiary : colors.surface,
      }}
    >
      <LogoTile m={method} />
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 14, fontWeight: "700", color: colors.onSurface }}>{method.label}</Text>
        {method.sub && <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>{method.sub}</Text>}
        {method.offer && (
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 4 }}>
            <Ionicons name="pricetag" size={11} color={colors.brandPrimary} />
            <Text style={{ fontSize: 11, fontWeight: "800", color: colors.brandPrimary }}>{method.offer}</Text>
          </View>
        )}
      </View>
      <Radio on={selected} />
    </Pressable>
  );
}

function BankGrid({ methods, selectedId, onSelect }: { methods: PaymentMethod[]; selectedId: string; onSelect: (id: string) => void }) {
  const { colors } = useTheme();
  return (
    <View style={{ padding: spacing.md }}>
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.sm }}>
        {methods.map((m) => {
          const on = selectedId === m.id;
          return (
            <Pressable
              key={m.id}
              testID={`pay-${m.id}`}
              onPress={() => onSelect(m.id)}
              style={{
                width: "31.5%", alignItems: "center", paddingVertical: spacing.md, gap: 6,
                borderRadius: radius.md, borderWidth: 1.5,
                borderColor: on ? colors.brandPrimary : colors.border,
                backgroundColor: on ? colors.brandTertiary : colors.surface,
              }}
            >
              <LogoTile m={m} size={36} />
              <Text style={{ fontSize: 11, fontWeight: "700", color: colors.onSurface, textAlign: "center" }} numberOfLines={1}>
                {m.label}
              </Text>
            </Pressable>
          );
        })}
      </View>
      <Pressable testID="more-banks" style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 4, marginTop: spacing.md, minHeight: 36 }}>
        <Text style={{ fontSize: 13, fontWeight: "800", color: colors.brandPrimary }}>View all banks</Text>
        <Ionicons name="chevron-down" size={14} color={colors.brandPrimary} />
      </Pressable>
    </View>
  );
}
