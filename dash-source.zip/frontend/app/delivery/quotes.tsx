import { View, Pressable, ScrollView } from "react-native";
import { Text } from "@/src/components/AppText";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Ionicons from "@react-native-vector-icons/ionicons";
import { useMemo, useState } from "react";

import { useTheme, spacing, radius, shadow } from "@/src/theme";
import { ScreenHeader } from "@/src/components/ScreenHeader";
import { courierQuotes, savedAddresses, orderTotals, promo } from "@/src/data/delivery-mock";
import { usePayment, rewards } from "@/src/data/payment-mock";
import { useSchedule, slotLabel } from "@/src/data/schedule-mock";
import { pointsFor } from "@/src/data/cart-store";

type SortKey = "recommended" | "cheapest" | "fastest";
const sortOptions: { key: SortKey; label: string; icon: string }[] = [
  { key: "recommended", label: "Recommended", icon: "thumbs-up-outline" },
  { key: "cheapest", label: "Cheapest", icon: "pricetag-outline" },
  { key: "fastest", label: "Fastest", icon: "flash-outline" },
];

export default function DeliveryQuotes() {
  const { colors } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const [selected, setSelected] = useState<string>(courierQuotes[0].id);
  const [sortBy, setSortBy] = useState<SortKey>("recommended");

  const chosen = useMemo(
    () => courierQuotes.find((q) => q.id === selected) ?? courierQuotes[0],
    [selected]
  );

  const sortedQuotes = useMemo(() => {
    const list = [...courierQuotes];
    if (sortBy === "cheapest") return list.sort((a, b) => a.fee - b.fee);
    if (sortBy === "fastest") return list.sort((a, b) => a.etaMinutes - b.etaMinutes);
    return list.sort((a, b) => Number(b.tag === "Recommended") - Number(a.tag === "Recommended"));
  }, [sortBy]);

  const { useRewards } = usePayment();
  const slot = useSchedule((s) => s.slot);
  const { subtotal, discount, rewardsOff, total } = orderTotals(chosen.fee, useRewards ? rewards.value : 0);
  const address = savedAddresses[0];

  return (
    <View style={{ flex: 1, backgroundColor: colors.surfaceSecondary }}>
      <ScreenHeader title="Delivery options" onBack={() => router.back()} />

      <ScrollView
        contentContainerStyle={{ padding: spacing.lg, paddingBottom: 170 + insets.bottom, gap: spacing.md }}
        showsVerticalScrollIndicator={false}
      >
        {/* Delivery address summary */}
        <View style={{
          backgroundColor: colors.surface,
          borderRadius: radius.lg,
          padding: spacing.md,
          flexDirection: "row", alignItems: "center", gap: spacing.md,
          ...shadow.card,
        }}>
          <View style={{
            width: 44, height: 44, borderRadius: 12,
            backgroundColor: colors.brandTertiary,
            alignItems: "center", justifyContent: "center",
          }}>
            <Ionicons name="location" size={22} color={colors.brandPrimary} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 11, fontWeight: "800", color: colors.muted, letterSpacing: 0.4 }}>
              DELIVER TO · {address.label.toUpperCase()}
            </Text>
            <Text style={{ fontSize: 14, fontWeight: "700", color: colors.onSurface, marginTop: 2 }} numberOfLines={1}>
              {address.line1}
            </Text>
            <Text style={{ fontSize: 12, color: colors.muted, marginTop: 1 }} numberOfLines={1}>{address.line2}</Text>
          </View>
          <Pressable testID="edit-address" onPress={() => router.back()}>
            <Text style={{ fontSize: 13, fontWeight: "700", color: colors.brandPrimary }}>Change</Text>
          </Pressable>
        </View>

        {/* Section title */}
        <View style={{ marginTop: spacing.sm }}>
          <Text style={{ fontSize: 18, fontWeight: "800", color: colors.onSurface }}>Choose a courier</Text>
          <Text style={{ fontSize: 13, color: colors.muted, marginTop: 2 }}>
            Fees & ETA quoted live from Delyva partners.
          </Text>
        </View>

        {slot && (
          <View testID="quotes-scheduled-banner" style={{
            flexDirection: "row", alignItems: "center", gap: spacing.md, padding: spacing.md,
            borderRadius: radius.lg, backgroundColor: colors.brandTertiary, borderWidth: 1, borderColor: colors.brandSecondary,
          }}>
            <Ionicons name="calendar" size={20} color={colors.brandPrimary} />
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 13, fontWeight: "800", color: colors.onSurface }}>Scheduled · {slotLabel(slot)}</Text>
              <Text style={{ fontSize: 12, color: colors.onSurfaceSecondary, marginTop: 2 }}>
                We&apos;ll book your courier about 30 min before the slot.
              </Text>
            </View>
          </View>
        )}

        {/* Sort chips */}
        <View style={{ flexDirection: "row", gap: spacing.sm }}>
          {sortOptions.map((o) => {
            const on = sortBy === o.key;
            return (
              <Pressable
                key={o.key}
                testID={`sort-${o.key}`}
                onPress={() => setSortBy(o.key)}
                style={{
                  flexDirection: "row", alignItems: "center", gap: 4,
                  paddingHorizontal: 12, minHeight: 36, borderRadius: radius.pill,
                  backgroundColor: on ? colors.brandPrimary : colors.surface,
                  borderWidth: 1, borderColor: on ? colors.brandPrimary : colors.border,
                }}
              >
                <Ionicons name={o.icon as any} size={14} color={on ? "#FFFFFF" : colors.onSurface} />
                <Text style={{ fontSize: 12, fontWeight: "800", color: on ? "#FFFFFF" : colors.onSurface }}>{o.label}</Text>
              </Pressable>
            );
          })}
        </View>

        {/* Courier quote list */}
        <View style={{ gap: spacing.md }}>
          {sortedQuotes.map((q) => {
            const active = selected === q.id;
            return (
              <Pressable
                key={q.id}
                testID={`quote-${q.id}`}
                onPress={() => setSelected(q.id)}
                style={{
                  backgroundColor: active ? colors.brandTertiary : colors.surface,
                  borderRadius: radius.lg,
                  padding: spacing.md,
                  borderWidth: 1.5,
                  borderColor: active ? colors.brandPrimary : colors.border,
                  ...shadow.card,
                }}
              >
                <View style={{ flexDirection: "row", gap: spacing.md, alignItems: "flex-start" }}>
                  {/* Logo badge */}
                  <View style={{
                    width: 48, height: 48, borderRadius: 14,
                    backgroundColor: q.logoColor,
                    alignItems: "center", justifyContent: "center",
                  }}>
                    <Text style={{ color: "#FFFFFF", fontSize: 22, fontWeight: "800" }}>{q.logoChar}</Text>
                  </View>

                  {/* Details */}
                  <View style={{ flex: 1 }}>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
                      <Text style={{ fontSize: 15, fontWeight: "800", color: colors.onSurface }}>{q.name}</Text>
                      {q.tag && (
                        <View style={{
                          paddingHorizontal: 8, paddingVertical: 2,
                          borderRadius: radius.pill,
                          backgroundColor: colors.brandPrimary,
                        }}>
                          <Text style={{ fontSize: 10, fontWeight: "800", color: "#FFFFFF", letterSpacing: 0.3 }}>
                            {q.tag.toUpperCase()}
                          </Text>
                        </View>
                      )}
                    </View>
                    <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 4 }}>
                      <Ionicons name="time-outline" size={13} color={colors.muted} />
                      <Text style={{ fontSize: 12, color: colors.muted }}>{q.etaLabel}</Text>
                      <Text style={{ fontSize: 12, color: colors.muted }}>·</Text>
                      <Ionicons name={q.type === "bike" ? "bicycle-outline" : "car-outline"} size={13} color={colors.muted} />
                      <Text style={{ fontSize: 12, color: colors.muted }}>{q.type === "bike" ? "Motorcycle" : "Car"}</Text>
                    </View>
                    <Text style={{ fontSize: 12, color: colors.onSurfaceSecondary, marginTop: 6 }}>
                      {q.description}
                    </Text>
                  </View>

                  {/* Price + radio */}
                  <View style={{ alignItems: "flex-end", gap: 8 }}>
                    <Text style={{ fontSize: 16, fontWeight: "800", color: colors.onSurface }}>
                      RM {q.fee.toFixed(2)}
                    </Text>
                    <View style={{
                      width: 22, height: 22, borderRadius: 11,
                      borderWidth: 2, borderColor: active ? colors.brandPrimary : colors.borderStrong,
                      alignItems: "center", justifyContent: "center",
                      backgroundColor: active ? colors.brandPrimary : "transparent",
                    }}>
                      {active && <Ionicons name="checkmark" size={13} color="#FFFFFF" />}
                    </View>
                  </View>
                </View>
              </Pressable>
            );
          })}
        </View>

        {/* Delivery instructions */}
        <Pressable
          testID="add-delivery-instructions"
          style={{
            marginTop: spacing.sm,
            backgroundColor: colors.surface,
            borderRadius: radius.lg,
            padding: spacing.md,
            flexDirection: "row", alignItems: "center", gap: spacing.md,
            ...shadow.card,
          }}
        >
          <View style={{
            width: 36, height: 36, borderRadius: 10,
            backgroundColor: colors.brandTertiary,
            alignItems: "center", justifyContent: "center",
          }}>
            <Ionicons name="chatbubble-ellipses" size={18} color={colors.brandPrimary} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 14, fontWeight: "800", color: colors.onSurface }}>
              Add delivery instructions
            </Text>
            <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>
              e.g. Leave at doorstep, ring bell twice
            </Text>
          </View>
          <Ionicons name="chevron-forward" size={18} color={colors.muted} />
        </Pressable>

        {/* Bill summary */}
        <View style={{
          marginTop: spacing.sm,
          backgroundColor: colors.surface,
          borderRadius: radius.lg,
          padding: spacing.md,
          gap: 8,
          ...shadow.card,
        }}>
          <Text style={{ fontSize: 14, fontWeight: "800", color: colors.onSurface, marginBottom: 4 }}>
            Bill summary
          </Text>
          <SumRow label="Subtotal" value={`RM ${subtotal.toFixed(2)}`} />
          {discount > 0 && <SumRow label={`Promo ${promo.code}`} value={`− RM ${discount.toFixed(2)}`} />}
          {rewardsOff > 0 && <SumRow label="Dash reward points" value={`− RM ${rewardsOff.toFixed(2)}`} />}
          <SumRow label={`Delivery · ${chosen.name}`} value={`RM ${chosen.fee.toFixed(2)}`} />
          <View style={{ height: 1, backgroundColor: colors.divider, marginVertical: 6 }} />
          <SumRow label="Total" value={`RM ${total.toFixed(2)}`} bold />
          <Text testID="quotes-points" style={{ fontSize: 12, fontWeight: "800", color: colors.brandPrimary, marginTop: 2 }}>🎁 Earn {pointsFor(total)} DashPoints with this order</Text>
        </View>
      </ScrollView>

      {/* Sticky CTA */}
      <View style={{
        position: "absolute", bottom: 0, left: 0, right: 0,
        paddingHorizontal: spacing.lg, paddingTop: spacing.md,
        paddingBottom: insets.bottom + spacing.md,
        backgroundColor: colors.surface,
        borderTopWidth: 1, borderTopColor: colors.border,
      }}>
        <View style={{ flexDirection: "row", alignItems: "center", marginBottom: spacing.sm }}>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 11, fontWeight: "700", color: colors.muted, letterSpacing: 0.4 }}>TOTAL</Text>
            <Text style={{ fontSize: 20, fontWeight: "800", color: colors.onSurface }}>RM {total.toFixed(2)}</Text>
          </View>
          <View style={{
            paddingHorizontal: 10, paddingVertical: 5,
            borderRadius: radius.pill,
            backgroundColor: colors.brandTertiary,
          }}>
            <Text style={{ fontSize: 11, fontWeight: "800", color: colors.brandPrimary }}>
              {slot ? slot.time : `ETA ${chosen.etaLabel}`}
            </Text>
          </View>
        </View>
        <Pressable
          testID="place-order-button"
          onPress={() => router.push({ pathname: "/delivery/payment", params: { quoteId: chosen.id } })}
          style={{
            backgroundColor: colors.brandPrimary,
            paddingVertical: 15, borderRadius: radius.pill,
            flexDirection: "row", alignItems: "center", justifyContent: "center",
            gap: 8,
          }}
        >
          <Text style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "800" }}>Proceed to pay</Text>
          <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
        </Pressable>
      </View>
    </View>
  );
}

function SumRow({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  const { colors } = useTheme();
  return (
    <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
      <Text style={{ fontSize: bold ? 15 : 13, fontWeight: bold ? "800" : "500", color: bold ? colors.onSurface : colors.onSurfaceSecondary }} numberOfLines={1}>
        {label}
      </Text>
      <Text style={{ fontSize: bold ? 17 : 13, fontWeight: bold ? "800" : "700", color: colors.onSurface }}>
        {value}
      </Text>
    </View>
  );
}
