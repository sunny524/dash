import { View, Pressable } from "react-native";
import { Text, TextInput } from "@/src/components/AppText";
import { Image } from "expo-image";
import { useRouter, useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { KeyboardAwareScrollView, KeyboardStickyView } from "react-native-keyboard-controller";
import Ionicons from "@react-native-vector-icons/ionicons";
import { useState } from "react";

import { useTheme, spacing, radius, shadow, type } from "@/src/theme";
import { ScreenHeader } from "@/src/components/ScreenHeader";
import { courierQuotes, mockCourier, cartItemCount, orderTotals } from "@/src/data/delivery-mock";
import { cartLines } from "@/src/data/cart-store";
import { usePayment, getPaymentMethod } from "@/src/data/payment-mock";

const ratingLabels = ["", "Very poor", "Not great", "Okay", "Good", "Excellent!"];
const goodTags = ["Friendly", "On time", "Food was hot", "Careful handling", "Followed instructions"];
const badTags = ["Late", "Food spilled", "Rude", "Wrong drop-off", "Didn't follow instructions"];
const tipOptions = [0, 2, 5, 10];

export default function RateDelivery() {
  const { colors } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { quoteId } = useLocalSearchParams<{ quoteId?: string }>();
  const quote = courierQuotes.find((q) => q.id === quoteId) ?? courierQuotes[0];
  const firstName = mockCourier.name.split(" ")[0];

  const payMethod = getPaymentMethod(usePayment((s) => s.methodId));
  const isCod = payMethod.group === "cod";

  const [rating, setRating] = useState(0);
  const [tags, setTags] = useState<string[]>([]);
  const [tip, setTip] = useState(2);
  const [submitted, setSubmitted] = useState(false);

  const tagList = rating >= 4 ? goodTags : badTags;
  const toggleTag = (t: string) => setTags((cur) => (cur.includes(t) ? cur.filter((x) => x !== t) : [...cur, t]));
  const pickRating = (r: number) => {
    if ((r >= 4) !== (rating >= 4)) setTags([]);
    setRating(r);
  };

  if (submitted) {
    return (
      <View testID="rating-thanks" style={{ flex: 1, backgroundColor: colors.surface, alignItems: "center", justifyContent: "center", padding: spacing.xl, paddingBottom: insets.bottom + spacing.xl }}>
        <View style={{ width: 96, height: 96, borderRadius: 48, backgroundColor: colors.brandTertiary, alignItems: "center", justifyContent: "center" }}>
          <Ionicons name="heart" size={46} color={colors.brandPrimary} />
        </View>
        <Text style={{ ...type.headline, fontWeight: "800", color: colors.onSurface, marginTop: spacing.lg, textAlign: "center" }}>Thanks for your feedback!</Text>
        <Text style={{ fontSize: 14, color: colors.muted, marginTop: 6, textAlign: "center" }}>
          {tip > 0 ? `${firstName} received your RM ${tip.toFixed(2)} tip. ` : ""}Your rating helps keep deliveries great.
        </Text>
        <View style={{
          marginTop: spacing.xl, alignSelf: "stretch", borderRadius: radius.lg, padding: spacing.md,
          backgroundColor: colors.surfaceSecondary, flexDirection: "row", alignItems: "center", gap: spacing.md,
        }}>
          <Image source={{ uri: cartLines()[0]?.image }} style={{ width: 52, height: 52, borderRadius: radius.md }} />
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 14, fontWeight: "800", color: colors.onSurface }}>Loved it? Order again</Text>
            <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }} numberOfLines={1}>
              Nasi Lemak Village · {cartItemCount()} items · RM {orderTotals(0).total.toFixed(2)} + delivery
            </Text>
          </View>
        </View>
        <Pressable
          testID="reorder-button"
          onPress={() => router.dismissTo("/delivery/cart")}
          style={{
            marginTop: spacing.md, alignSelf: "stretch", backgroundColor: colors.brandPrimary, paddingVertical: 15,
            borderRadius: radius.pill, alignItems: "center", flexDirection: "row", justifyContent: "center", gap: 8,
          }}
        >
          <Ionicons name="refresh" size={18} color="#FFFFFF" />
          <Text style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "800" }}>Reorder in one tap</Text>
        </Pressable>
        <Pressable
          testID="rating-done"
          onPress={() => router.replace("/(tabs)/home")}
          style={{ marginTop: spacing.sm, alignSelf: "stretch", paddingVertical: 13, borderRadius: radius.pill, alignItems: "center" }}
        >
          <Text style={{ color: colors.onSurfaceSecondary, fontSize: 14, fontWeight: "700" }}>Back to home</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.surfaceSecondary }}>
      <ScreenHeader title="Rate your delivery" onBack={() => router.back()} />
      <KeyboardAwareScrollView
        contentContainerStyle={{ padding: spacing.lg, paddingBottom: 120 + insets.bottom, gap: spacing.md }}
        bottomOffset={100}
        keyboardShouldPersistTaps="handled"
      >
        {/* Rider + stars */}
        <View style={{ backgroundColor: colors.surface, borderRadius: radius.lg, padding: spacing.lg, alignItems: "center", ...shadow.card }}>
          <Image source={{ uri: mockCourier.photo }} style={{ width: 76, height: 76, borderRadius: 38 }} />
          <Text style={{ fontSize: 17, fontWeight: "800", color: colors.onSurface, marginTop: spacing.md }}>{mockCourier.name}</Text>
          <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>Delivered at 12:42 PM · {quote.name}</Text>
          <Text style={{ fontSize: 15, fontWeight: "700", color: colors.onSurface, marginTop: spacing.lg }}>How was your delivery?</Text>
          <View style={{ flexDirection: "row", gap: 6, marginTop: spacing.sm }}>
            {[1, 2, 3, 4, 5].map((s) => (
              <Pressable key={s} testID={`star-${s}`} onPress={() => pickRating(s)} hitSlop={4} style={{ padding: 4 }}>
                <Ionicons name={s <= rating ? "star" : "star-outline"} size={36} color={s <= rating ? colors.brandPrimary : colors.borderStrong} />
              </Pressable>
            ))}
          </View>
          <Text style={{ fontSize: 13, fontWeight: "800", color: colors.brandPrimary, marginTop: 4, minHeight: 18 }}>{ratingLabels[rating]}</Text>
        </View>

        {/* Quick tags + comment */}
        {rating > 0 && (
          <View style={{ backgroundColor: colors.surface, borderRadius: radius.lg, padding: spacing.md, ...shadow.card }}>
            <Text style={{ fontSize: 14, fontWeight: "800", color: colors.onSurface }}>
              {rating >= 4 ? "What went well?" : "What could be better?"}
            </Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: spacing.sm, marginTop: spacing.md }}>
              {tagList.map((t) => {
                const on = tags.includes(t);
                return (
                  <Pressable
                    key={t}
                    testID={`tag-${t}`}
                    onPress={() => toggleTag(t)}
                    style={{
                      paddingHorizontal: 12, minHeight: 36, justifyContent: "center", borderRadius: radius.pill,
                      backgroundColor: on ? colors.brandTertiary : colors.surface,
                      borderWidth: 1, borderColor: on ? colors.brandPrimary : colors.border,
                    }}
                  >
                    <Text style={{ fontSize: 12, fontWeight: "700", color: on ? colors.brandPrimary : colors.onSurface }}>{t}</Text>
                  </Pressable>
                );
              })}
            </View>
            <TextInput
              testID="rating-comment"
              placeholder={`Anything else about ${firstName}'s delivery? (optional)`}
              placeholderTextColor={colors.muted}
              multiline
              style={{
                marginTop: spacing.md, minHeight: 80, textAlignVertical: "top",
                borderRadius: radius.md, borderWidth: 1, borderColor: colors.border,
                padding: spacing.md, fontSize: 14, color: colors.onSurface, backgroundColor: colors.surfaceSecondary,
              }}
            />
          </View>
        )}

        {/* Tip */}
        <View style={{ backgroundColor: colors.surface, borderRadius: radius.lg, padding: spacing.md, ...shadow.card }}>
          <Text style={{ fontSize: 14, fontWeight: "800", color: colors.onSurface }}>Tip {firstName}</Text>
          <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>100% of your tip goes to your rider.</Text>
          <View style={{ flexDirection: "row", gap: spacing.sm, marginTop: spacing.md }}>
            {tipOptions.map((t) => {
              const on = tip === t;
              return (
                <Pressable
                  key={t}
                  testID={`tip-${t}`}
                  onPress={() => setTip(t)}
                  style={{
                    flex: 1, minHeight: 44, alignItems: "center", justifyContent: "center", borderRadius: radius.pill,
                    backgroundColor: on ? colors.brandPrimary : colors.surfaceSecondary,
                    borderWidth: 1, borderColor: on ? colors.brandPrimary : colors.border,
                  }}
                >
                  <Text style={{ fontSize: 13, fontWeight: "800", color: on ? "#FFFFFF" : colors.onSurface }}>
                    {t === 0 ? "No tip" : `RM ${t}`}
                  </Text>
                </Pressable>
              );
            })}
          </View>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: spacing.md }}>
            <Ionicons name="wallet-outline" size={14} color={colors.muted} />
            <Text style={{ fontSize: 12, color: colors.muted }}>
              {isCod ? "Hand your tip to the rider in cash" : `Charged to ${payMethod.label}`}
            </Text>
          </View>
        </View>
      </KeyboardAwareScrollView>

      <KeyboardStickyView offset={{ closed: 0, opened: -insets.bottom + 8 }}>
        <View style={{
          paddingHorizontal: spacing.lg, paddingTop: spacing.md,
          paddingBottom: insets.bottom + spacing.md,
          backgroundColor: colors.surface, borderTopWidth: 1, borderTopColor: colors.border,
        }}>
          <Pressable
            testID="submit-rating"
            disabled={rating === 0}
            onPress={() => setSubmitted(true)}
            style={{
              backgroundColor: rating === 0 ? colors.surfaceTertiary : colors.brandPrimary,
              paddingVertical: 15, borderRadius: radius.pill, alignItems: "center",
            }}
          >
            <Text style={{ color: rating === 0 ? colors.muted : "#FFFFFF", fontSize: 15, fontWeight: "800" }}>
              {rating === 0 ? "Tap a star to rate" : tip > 0 ? `Submit & tip RM ${tip.toFixed(2)}` : "Submit rating"}
            </Text>
          </Pressable>
        </View>
      </KeyboardStickyView>
    </View>
  );
}
