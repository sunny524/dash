import { View, ScrollView, Pressable, Modal } from "react-native";
import { Text, TextInput } from "@/src/components/AppText";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Ionicons from "@react-native-vector-icons/ionicons";
import { useMemo, useRef, useState } from "react";

import { useTheme, spacing, radius, shadow, type } from "@/src/theme";
import { restaurants, menuItems } from "@/src/data/mock";
import { MenuItemRow, FloatingCartBar, groupMenu } from "@/src/components/MenuItemRow";
import { useCart, useFavourites } from "@/src/data/cart-store";

const offers = [
  { id: "o1", icon: "pricetag", title: "20% OFF UPTO RM10", sub: "USE EASYEAT20" },
  { id: "o2", icon: "gift", title: "DOUBLE POINTS", sub: "EARN 2X DASHPOINTS" },
  { id: "o3", icon: "bicycle", title: "FREE DELIVERY", sub: "ABOVE RM25" },
];

export default function RestaurantDetail() {
  const { colors } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id: string }>();
  const r = restaurants.find((x) => x.id === id) ?? restaurants[0];

  const { qty: cartQty, add, remove, count: cartCount, total: cartTotal, restaurantId: cartRid, startNewCart } = useCart();
  const sameCart = cartRid === r.id || cartCount === 0;
  const qty = sameCart ? cartQty : {};
  const count = sameCart ? cartCount : 0;
  const total = sameCart ? cartTotal : 0;
  const [pendingItem, setPendingItem] = useState<string | null>(null);
  const cartRestaurant = restaurants.find((x) => x.id === cartRid);
  const onAdd = (id: string) => {
    if (cartCount === 0) return startNewCart(r.id, id);
    if (!sameCart) return setPendingItem(id);
    add(id);
  };
  const { ids: favIds, toggle: toggleFav } = useFavourites();
  const isFav = favIds.includes(r.id);
  const [bestsellerOnly, setBestsellerOnly] = useState(false);
  const [search, setSearch] = useState("");
  const [collapsed, setCollapsed] = useState<string[]>([]);
  const [menuOpen, setMenuOpen] = useState(false);
  const scrollRef = useRef<ScrollView>(null);
  const sectionY = useRef<Record<string, number>>({});

  const sections = useMemo(() => {
    const q = search.trim().toLowerCase();
    const items = menuItems.filter((m) => (!bestsellerOnly || m.popular) && (!q || m.name.toLowerCase().includes(q)));
    return groupMenu(items);
  }, [bestsellerOnly, search]);

  const toggleSection = (t: string) => setCollapsed((c) => (c.includes(t) ? c.filter((x) => x !== t) : [...c, t]));

  return (
    <View style={{ flex: 1, backgroundColor: colors.surface }}>
      {/* Top bar */}
      <View style={{ paddingTop: insets.top, backgroundColor: colors.surfaceSecondary }}>
        <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: spacing.lg, paddingVertical: spacing.sm, gap: spacing.sm }}>
          <Pressable testID="restaurant-back" onPress={() => router.back()} style={roundBtn(colors.surface)}>
            <Ionicons name="arrow-back" size={20} color={colors.onSurface} />
          </Pressable>
          <View style={{ flex: 1 }} />
          <Pressable testID="restaurant-fav" onPress={() => toggleFav(r.id)} style={roundBtn(colors.surface)}><Ionicons name={isFav ? "heart" : "heart-outline"} size={20} color={isFav ? colors.brandPrimary : colors.onSurface} /></Pressable>
          <Pressable testID="restaurant-share" style={roundBtn(colors.surface)}><Ionicons name="share-social-outline" size={20} color={colors.onSurface} /></Pressable>
        </View>
      </View>

      <ScrollView ref={scrollRef} contentContainerStyle={{ paddingBottom: 120 + insets.bottom }} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        {/* Info card */}
        <View style={{ backgroundColor: colors.surfaceSecondary, paddingHorizontal: spacing.lg, paddingBottom: spacing.lg }}>
          <View style={{ backgroundColor: colors.surface, borderRadius: radius.lg, padding: spacing.md, ...shadow.card }}>
            <Text style={{ fontSize: type.subhead.fontSize, fontWeight: "900", color: colors.onSurface, letterSpacing: -0.3 }}>{r.name}</Text>
            <Pressable testID="view-reviews-btn" onPress={() => router.push("/delivery/reviews")} style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 6 }}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 3, backgroundColor: colors.brandPrimary, paddingHorizontal: 6, paddingVertical: 2, borderRadius: radius.sm }}>
                <Ionicons name="star" size={11} color="#FFFFFF" />
                <Text style={{ fontSize: 12, fontWeight: "800", color: "#FFFFFF" }}>{r.rating.toFixed(1)}</Text>
              </View>
              <Text style={{ fontSize: 14, fontWeight: "700", color: colors.onSurface }}>({(r.reviews / 1000).toFixed(1)}K+ ratings) • {r.priceRange === "$" ? "RM15" : r.priceRange === "$$" ? "RM30" : "RM60"} for two</Text>
              <Ionicons name="chevron-forward" size={14} color={colors.muted} />
            </Pressable>
            <Text style={{ fontSize: 13, fontWeight: "700", color: colors.brandPrimary, marginTop: 6 }}>{r.cuisines.join(", ")}</Text>

            <View style={{ flexDirection: "row", gap: spacing.md, marginTop: spacing.md }}>
              <View style={{ alignItems: "center", paddingTop: 4 }}>
                <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: colors.borderStrong }} />
                <View style={{ width: 1, height: 22, backgroundColor: colors.borderStrong }} />
                <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: colors.borderStrong }} />
              </View>
              <View style={{ gap: 12 }}>
                <Text style={{ fontSize: 13, color: colors.onSurface }}><Text style={{ fontWeight: "800" }}>Outlet </Text> {r.address}</Text>
                <Text style={{ fontSize: 13, fontWeight: "800", color: colors.onSurface }}>{r.etaMin}-{r.etaMin + 5} mins</Text>
              </View>
            </View>
            <View style={{ height: 1, backgroundColor: colors.divider, marginVertical: spacing.md }} />
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
              <Ionicons name="bicycle" size={16} color={colors.muted} />
              <Text style={{ fontSize: 12, color: colors.onSurfaceSecondary }}>{r.distanceKm} km • Delivery from RM 7.50 via Delyva couriers</Text>
            </View>
          </View>
        </View>

        {/* Offers strip */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: spacing.lg, gap: spacing.md, paddingTop: spacing.lg }}>
          {offers.map((o) => (
            <View key={o.id} testID={`offer-${o.id}`} style={{ flexDirection: "row", alignItems: "center", gap: spacing.sm, padding: spacing.md, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, borderStyle: "dashed", width: 220 }}>
              <View style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: colors.brandTertiary, alignItems: "center", justifyContent: "center" }}>
                <Ionicons name={o.icon as any} size={18} color={colors.brandPrimary} />
              </View>
              <View>
                <Text style={{ fontSize: 14, fontWeight: "900", color: colors.onSurface }}>{o.title}</Text>
                <Text style={{ fontSize: 11, fontWeight: "700", color: colors.muted, marginTop: 1 }}>{o.sub}</Text>
              </View>
            </View>
          ))}
        </ScrollView>

        {/* MENU divider */}
        <View style={{ flexDirection: "row", alignItems: "center", gap: spacing.sm, paddingHorizontal: spacing.xxl, marginTop: spacing.xl }}>
          <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
          <Text style={{ fontSize: 12, fontWeight: "800", color: colors.muted, letterSpacing: 3 }}>MENU</Text>
          <View style={{ flex: 1, height: 1, backgroundColor: colors.border }} />
        </View>

        {/* Menu search */}
        <View style={{ marginHorizontal: spacing.lg, marginTop: spacing.md, height: 46, borderRadius: radius.md, backgroundColor: colors.surfaceSecondary, flexDirection: "row", alignItems: "center", paddingHorizontal: spacing.md, gap: spacing.sm }}>
          <TextInput
            testID="menu-search"
            value={search}
            onChangeText={setSearch}
            placeholder="Search for dishes"
            placeholderTextColor={colors.muted}
            style={{ flex: 1, fontSize: 14, color: colors.onSurface, padding: 0 }}
          />
          <Ionicons name="search" size={18} color={colors.muted} />
        </View>

        {/* Toggles */}
        <View style={{ flexDirection: "row", gap: spacing.sm, paddingHorizontal: spacing.lg, marginTop: spacing.md }}>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 6, height: 36, paddingHorizontal: 12, borderRadius: radius.pill, borderWidth: 1, borderColor: colors.border }}>
            <Ionicons name="checkmark-circle" size={14} color="#1E8E3E" />
            <Text style={{ fontSize: 13, fontWeight: "700", color: colors.onSurface }}>All Halal</Text>
          </View>
          <Pressable
            testID="toggle-bestseller"
            onPress={() => setBestsellerOnly((v) => !v)}
            style={{ flexDirection: "row", alignItems: "center", gap: 6, height: 36, paddingHorizontal: 12, borderRadius: radius.pill, borderWidth: 1, borderColor: bestsellerOnly ? colors.brandPrimary : colors.border, backgroundColor: bestsellerOnly ? colors.brandTertiary : colors.surface }}
          >
            <Ionicons name="star" size={13} color={colors.warning} />
            <Text style={{ fontSize: 13, fontWeight: "700", color: bestsellerOnly ? colors.brandPrimary : colors.onSurface }}>Bestseller</Text>
            {bestsellerOnly && <Ionicons name="close" size={13} color={colors.brandPrimary} />}
          </Pressable>
        </View>

        {/* Sections */}
        {sections.length === 0 && (
          <Text testID="menu-empty" style={{ textAlign: "center", color: colors.muted, marginTop: spacing.xl }}>No dishes match your search</Text>
        )}
        {sections.map((s) => {
          const isCollapsed = collapsed.includes(s.title);
          return (
            <View key={s.title} onLayout={(e) => { sectionY.current[s.title] = e.nativeEvent.layout.y; }}>
              <View style={{ height: 8, backgroundColor: colors.surfaceSecondary, marginTop: spacing.md }} />
              <Pressable testID={`section-${s.title}`} onPress={() => toggleSection(s.title)} style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: spacing.lg, paddingTop: spacing.lg }}>
                <Text style={{ flex: 1, fontSize: 16, fontWeight: "900", color: colors.onSurface }}>{s.title} ({s.items.length})</Text>
                <Ionicons name={isCollapsed ? "chevron-down" : "chevron-up"} size={20} color={colors.onSurface} />
              </Pressable>
              {!isCollapsed && (
                <View style={{ paddingHorizontal: spacing.lg }}>
                  {s.items.map((m, i) => (
                    <MenuItemRow
                      key={`${s.title}-${m.id}`}
                      item={m}
                      qty={qty[m.id] ?? 0}
                      onAdd={() => onAdd(m.id)}
                      onRemove={() => remove(m.id)}
                      onPress={() => router.push(`/delivery/item?id=${m.id}`)}
                      last={i === s.items.length - 1}
                    />
                  ))}
                </View>
              )}
            </View>
          );
        })}
      </ScrollView>

      {/* Floating MENU button */}
      <Pressable
        testID="menu-fab"
        onPress={() => setMenuOpen(true)}
        style={{
          position: "absolute", right: spacing.lg, bottom: (count > 0 ? 88 : 24) + insets.bottom,
          backgroundColor: colors.onSurface, width: 60, height: 60, borderRadius: 30,
          alignItems: "center", justifyContent: "center", ...shadow.card,
        }}
      >
        <Ionicons name="restaurant" size={20} color="#FFFFFF" />
        <Text style={{ color: "#FFFFFF", fontSize: 11, fontWeight: "900", marginTop: 2 }}>MENU</Text>
      </Pressable>

      <FloatingCartBar count={count} total={total} onPress={() => router.push("/delivery/cart")} bottom={insets.bottom + spacing.md} />

      {/* One-restaurant cart warning */}
      <Modal visible={!!pendingItem} transparent animationType="slide" onRequestClose={() => setPendingItem(null)}>
        <Pressable onPress={() => setPendingItem(null)} style={{ flex: 1, backgroundColor: colors.overlay }} />
        <View testID="replace-cart-sheet" style={{ backgroundColor: colors.surface, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: spacing.lg, paddingBottom: insets.bottom + spacing.lg }}>
          <Text style={{ fontSize: 17, fontWeight: "900", color: colors.onSurface }}>Replace cart items?</Text>
          <Text style={{ fontSize: 13, color: colors.onSurfaceSecondary, marginTop: 6, lineHeight: 19 }}>
            Your cart has dishes from {cartRestaurant?.name ?? "another restaurant"}. Start a new cart with {r.name}? Your current items will be removed.
          </Text>
          <View style={{ flexDirection: "row", gap: spacing.sm, marginTop: spacing.lg }}>
            <Pressable testID="replace-cart-no" onPress={() => setPendingItem(null)} style={{ flex: 1, height: 46, borderRadius: radius.md, borderWidth: 1.5, borderColor: colors.brandPrimary, alignItems: "center", justifyContent: "center" }}>
              <Text style={{ fontSize: 14, fontWeight: "900", color: colors.brandPrimary }}>NO, KEEP</Text>
            </Pressable>
            <Pressable testID="replace-cart-yes" onPress={() => { if (pendingItem) startNewCart(r.id, pendingItem); setPendingItem(null); }} style={{ flex: 1, height: 46, borderRadius: radius.md, backgroundColor: colors.brandPrimary, alignItems: "center", justifyContent: "center" }}>
              <Text style={{ fontSize: 14, fontWeight: "900", color: "#FFFFFF" }}>YES, START FRESH</Text>
            </Pressable>
          </View>
        </View>
      </Modal>

      {/* Menu sections modal */}
      <Modal visible={menuOpen} transparent animationType="fade" onRequestClose={() => setMenuOpen(false)}>
        <Pressable testID="menu-modal-backdrop" onPress={() => setMenuOpen(false)} style={{ flex: 1, backgroundColor: colors.overlay, justifyContent: "flex-end", alignItems: "flex-end", padding: spacing.lg, paddingBottom: 110 + insets.bottom }}>
          <View style={{ backgroundColor: colors.onSurface, borderRadius: radius.lg, padding: spacing.lg, minWidth: 240, gap: spacing.md }}>
            {groupMenu(menuItems).map((s) => (
              <Pressable key={s.title} testID={`menu-jump-${s.title}`} onPress={() => {
                setCollapsed((c) => c.filter((x) => x !== s.title));
                setMenuOpen(false);
                const y = sectionY.current[s.title];
                if (y !== undefined) scrollRef.current?.scrollTo({ y: y - 8, animated: true });
              }} style={{ flexDirection: "row", justifyContent: "space-between", gap: spacing.xl, minHeight: 32, alignItems: "center" }}>
                <Text style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "700" }}>{s.title}</Text>
                <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 15 }}>{s.items.length}</Text>
              </Pressable>
            ))}
          </View>
        </Pressable>
      </Modal>
    </View>
  );
}

const roundBtn = (bg: string) => ({
  width: 40, height: 40, borderRadius: 20, backgroundColor: bg,
  alignItems: "center" as const, justifyContent: "center" as const,
});
