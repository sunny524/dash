import { View, Pressable, ScrollView, Animated } from "react-native";
import { Text } from "@/src/components/AppText";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import { useRouter, useLocalSearchParams } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Ionicons from "@react-native-vector-icons/ionicons";
import { useEffect, useRef, useState } from "react";

import { useTheme, spacing, radius, shadow } from "@/src/theme";
import { KLStreetMap } from "@/src/components/KLStreetMap";
import {
  deliveryTimeline,
  mockCourier,
  courierQuotes,
  savedAddresses,
  type DeliveryStatusKey,
} from "@/src/data/delivery-mock";

export default function Tracking() {
  const { colors } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { quoteId } = useLocalSearchParams<{ quoteId?: string }>();

  // Mock "current" status — one that shows the active step on the map.
  const [currentStatus, setCurrentStatus] = useState<DeliveryStatusKey>("out_for_delivery");
  const [etaMin, setEtaMin] = useState(11);
  const delivered = currentStatus === "delivered";
  // Map starts at 38% of the route; scale remaining distance to an 11 min ETA
  const onRiderProgress = (p: number) => setEtaMin(Math.max(1, Math.ceil(((1 - p) / 0.62) * 11)));
  const currentIdx = deliveryTimeline.findIndex((s) => s.key === currentStatus);
  const quote = courierQuotes.find((q) => q.id === quoteId) ?? courierQuotes[0];
  const address = savedAddresses[0];

  // Cancel is only available before "picked_up"
  const canCancel = currentIdx < deliveryTimeline.findIndex((s) => s.key === "picked_up");

  // Live toast animation (preserved from previous build)
  const [showToast, setShowToast] = useState(true);
  const toastY = useRef(new Animated.Value(-120)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.spring(toastY, { toValue: 0, useNativeDriver: true, damping: 15 }),
      Animated.delay(4000),
      Animated.timing(toastY, { toValue: -140, duration: 260, useNativeDriver: true }),
    ]).start(() => setShowToast(false));
  }, [toastY]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.surfaceSecondary }}>
      {/* Faux map area */}
      <View style={{ height: 380, backgroundColor: colors.surfaceTertiary }}>
        <KLStreetMap height={380} onProgress={onRiderProgress} onArrive={() => setCurrentStatus("delivered")} />
        <LinearGradient
          colors={["rgba(255,255,255,0.4)", "transparent"]}
          style={{ position: "absolute", top: 0, left: 0, right: 0, height: 120 }}
        />

        <Pressable
          testID="tracking-back"
          onPress={() => router.replace("/(tabs)/home")}
          style={{
            position: "absolute", top: insets.top + 8, left: spacing.lg,
            width: 40, height: 40, borderRadius: 20, backgroundColor: "#FFFFFF",
            alignItems: "center", justifyContent: "center", ...shadow.card,
          }}
        >
          <Ionicons name="chevron-back" size={22} color={colors.onSurface} />
        </Pressable>

        <View style={{
          position: "absolute", top: insets.top + 8, right: spacing.lg,
          backgroundColor: "#FFFFFF", paddingHorizontal: spacing.md, paddingVertical: 10,
          borderRadius: radius.pill, flexDirection: "row", alignItems: "center", gap: 6,
          ...shadow.card,
        }}>
          <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: colors.brandPrimary }} />
          <Text testID="tracking-eta" style={{ fontSize: 12, fontWeight: "800", color: colors.onSurface }}>
            {delivered ? "Arrived" : `Arriving in ${etaMin} min`}
          </Text>
        </View>

      </View>

      {/* Bottom sheet */}
      <View style={{
        flex: 1,
        backgroundColor: colors.surface,
        borderTopLeftRadius: 28, borderTopRightRadius: 28,
        marginTop: -28,
        ...shadow.sticky,
      }}>
        <View style={{ alignItems: "center", paddingTop: 10 }}>
          <View style={{ width: 40, height: 5, borderRadius: 3, backgroundColor: colors.border }} />
        </View>
        <ScrollView
          contentContainerStyle={{ padding: spacing.lg, paddingBottom: insets.bottom + spacing.lg, gap: spacing.md }}
          showsVerticalScrollIndicator={false}
        >
          {/* Status headline */}
          <View>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
              <View style={{
                paddingHorizontal: 8, paddingVertical: 3,
                borderRadius: radius.pill,
                backgroundColor: colors.brandTertiary,
                flexDirection: "row", alignItems: "center", gap: 4,
              }}>
                <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: colors.brandPrimary }} />
                <Text style={{ fontSize: 10, fontWeight: "800", color: colors.brandPrimary, letterSpacing: 0.4 }}>
                  LIVE
                </Text>
              </View>
              <Text style={{ fontSize: 11, fontWeight: "700", color: colors.muted }}>
                Order #DASH-24-A1247
              </Text>
            </View>
            <Text testID="tracking-status" style={{ fontSize: 20, fontWeight: "800", color: colors.onSurface, marginTop: 6 }}>
              {deliveryTimeline[currentIdx].title}
            </Text>
            <Text style={{ fontSize: 13, color: colors.muted, marginTop: 2 }}>
              {deliveryTimeline[currentIdx].desc}
            </Text>
          </View>

          {/* Courier card */}
          <View style={{
            backgroundColor: colors.surfaceSecondary,
            borderRadius: radius.lg,
            padding: spacing.md,
            flexDirection: "row",
            alignItems: "center",
            gap: spacing.md,
          }}>
            <Image source={{ uri: mockCourier.photo }} style={{ width: 52, height: 52, borderRadius: 26 }} />
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 15, fontWeight: "800", color: colors.onSurface }}>{mockCourier.name}</Text>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 2 }}>
                <Ionicons name="star" size={12} color={colors.brandPrimary} />
                <Text style={{ fontSize: 12, color: colors.muted }}>
                  {mockCourier.rating} · {mockCourier.deliveries}+ deliveries
                </Text>
              </View>
              <Text style={{ fontSize: 11, color: colors.muted, marginTop: 2 }}>{mockCourier.vehicle}</Text>
            </View>
            <Pressable testID="courier-chat" style={roundBtn(colors.surface)}>
              <Ionicons name="chatbubble" size={18} color={colors.brandPrimary} />
            </Pressable>
            <Pressable testID="courier-call" style={roundBtn(colors.brandPrimary)}>
              <Ionicons name="call" size={18} color="#FFFFFF" />
            </Pressable>
          </View>

          {/* Delivery instructions */}
          {address.instructions && (
            <View style={{
              borderRadius: radius.lg,
              padding: spacing.md,
              borderWidth: 1,
              borderColor: colors.border,
              backgroundColor: colors.surface,
              flexDirection: "row",
              gap: spacing.md,
              alignItems: "flex-start",
            }}>
              <View style={{
                width: 32, height: 32, borderRadius: 10,
                backgroundColor: colors.brandTertiary,
                alignItems: "center", justifyContent: "center",
              }}>
                <Ionicons name="chatbubble-ellipses" size={16} color={colors.brandPrimary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 11, fontWeight: "800", color: colors.muted, letterSpacing: 0.4 }}>
                  DELIVERY INSTRUCTIONS
                </Text>
                <Text style={{ fontSize: 13, color: colors.onSurface, marginTop: 4 }}>
                  {address.instructions}
                </Text>
              </View>
            </View>
          )}

          {/* Status timeline */}
          <View style={{
            backgroundColor: colors.surface,
            borderRadius: radius.lg,
            padding: spacing.md,
            borderWidth: 1, borderColor: colors.border,
          }}>
            <Text style={{ fontSize: 14, fontWeight: "800", color: colors.onSurface, marginBottom: spacing.md }}>
              Order progress
            </Text>
            {deliveryTimeline.map((step, i) => {
              const done = i < currentIdx;
              const active = i === currentIdx;
              const last = i === deliveryTimeline.length - 1;
              return (
                <View key={step.key} style={{ flexDirection: "row", gap: spacing.md }}>
                  {/* Rail */}
                  <View style={{ width: 28, alignItems: "center" }}>
                    <View style={{
                      width: 28, height: 28, borderRadius: 14,
                      backgroundColor: done || active ? colors.brandPrimary : colors.surfaceSecondary,
                      alignItems: "center", justifyContent: "center",
                      borderWidth: active ? 3 : 0,
                      borderColor: active ? colors.brandTertiary : "transparent",
                    }}>
                      <Ionicons
                        name={done ? "checkmark" as any : step.icon as any}
                        size={14}
                        color={done || active ? "#FFFFFF" : colors.muted}
                      />
                    </View>
                    {!last && (
                      <View style={{
                        flex: 1, width: 2, minHeight: 28,
                        backgroundColor: done ? colors.brandPrimary : colors.border,
                        marginVertical: 2,
                      }} />
                    )}
                  </View>
                  {/* Content */}
                  <View style={{ flex: 1, paddingBottom: last ? 0 : spacing.md }}>
                    <Text style={{
                      fontSize: 14,
                      fontWeight: active ? "800" : "700",
                      color: active ? colors.brandPrimary : done ? colors.onSurface : colors.muted,
                    }}>
                      {step.title}
                    </Text>
                    <Text style={{
                      fontSize: 12,
                      color: active ? colors.onSurface : colors.muted,
                      marginTop: 2,
                    }}>
                      {step.desc}
                    </Text>
                  </View>
                </View>
              );
            })}
          </View>

          {/* Address + courier selected summary */}
          <View style={{
            backgroundColor: colors.surface,
            borderRadius: radius.lg,
            padding: spacing.md,
            borderWidth: 1, borderColor: colors.border,
            gap: 10,
          }}>
            <InfoRow icon="location" title="Delivering to" value={`${address.label} · ${address.line1}`} />
            <View style={{ height: 1, backgroundColor: colors.divider }} />
            <InfoRow
              icon="bicycle"
              title="Courier service"
              value={`${quote.name} · RM ${quote.fee.toFixed(2)}`}
            />
          </View>

          {/* Cancel / Support buttons */}
          <View style={{ gap: 8 }}>
            <Pressable
              testID="order-received"
              onPress={() => router.push({ pathname: "/delivery/rate", params: { quoteId: quote.id } })}
              style={{
                borderRadius: radius.pill, paddingVertical: 14,
                backgroundColor: colors.brandPrimary,
                alignItems: "center", flexDirection: "row", justifyContent: "center", gap: 6,
              }}
            >
              <Ionicons name="star" size={16} color="#FFFFFF" />
              <Text style={{ fontSize: 14, fontWeight: "800", color: "#FFFFFF" }}>
                Got your order? Rate {mockCourier.name.split(" ")[0]}
              </Text>
            </Pressable>
            {canCancel ? (
              <Pressable
                testID="cancel-order"
                style={{
                  borderRadius: radius.pill, paddingVertical: 13,
                  borderWidth: 1.5, borderColor: colors.error,
                  alignItems: "center", flexDirection: "row", justifyContent: "center", gap: 6,
                }}
              >
                <Ionicons name="close-circle-outline" size={16} color={colors.error} />
                <Text style={{ fontSize: 13, fontWeight: "800", color: colors.error }}>Cancel order</Text>
              </Pressable>
            ) : (
              <View style={{
                borderRadius: radius.pill, paddingVertical: 13,
                backgroundColor: colors.surfaceTertiary,
                alignItems: "center", flexDirection: "row", justifyContent: "center", gap: 6,
              }}>
                <Ionicons name="lock-closed" size={14} color={colors.muted} />
                <Text style={{ fontSize: 12, fontWeight: "700", color: colors.muted }}>
                  Order can no longer be cancelled
                </Text>
              </View>
            )}

            <Pressable
              testID="contact-support"
              style={{
                borderRadius: radius.pill, paddingVertical: 13,
                backgroundColor: colors.surfaceSecondary,
                alignItems: "center", flexDirection: "row", justifyContent: "center", gap: 6,
              }}
            >
              <Ionicons name="headset" size={16} color={colors.onSurface} />
              <Text style={{ fontSize: 13, fontWeight: "800", color: colors.onSurface }}>Contact support</Text>
            </Pressable>
          </View>
        </ScrollView>
      </View>

      {/* Live toast */}
      {showToast && (
        <Animated.View
          testID="live-toast"
          style={{
            position: "absolute",
            top: insets.top + 8,
            left: spacing.lg, right: spacing.lg,
            transform: [{ translateY: toastY }],
            backgroundColor: colors.onSurface,
            borderRadius: radius.lg,
            padding: spacing.md,
            flexDirection: "row", alignItems: "center", gap: spacing.md,
            ...shadow.sticky,
          }}
        >
          <View style={{
            width: 40, height: 40, borderRadius: 20,
            backgroundColor: colors.brandPrimary,
            alignItems: "center", justifyContent: "center",
          }}>
            <Ionicons name="bicycle" size={20} color="#FFFFFF" />
          </View>
          <View style={{ flex: 1 }}>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
              <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: colors.brandPrimary }} />
              <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 10, fontWeight: "800", letterSpacing: 0.5 }}>LIVE</Text>
            </View>
            <Text style={{ color: "#FFFFFF", fontSize: 14, fontWeight: "800", marginTop: 2 }}>
              {mockCourier.name.split(" ")[0]} is on the way
            </Text>
            <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 11, marginTop: 2 }}>
              Arriving at {address.label} in ~11 min
            </Text>
          </View>
        </Animated.View>
      )}
    </View>
  );
}

function InfoRow({ icon, title, value }: { icon: string; title: string; value: string }) {
  const { colors } = useTheme();
  return (
    <View style={{ flexDirection: "row", alignItems: "center", gap: spacing.md }}>
      <View style={{
        width: 32, height: 32, borderRadius: 10,
        backgroundColor: colors.brandTertiary,
        alignItems: "center", justifyContent: "center",
      }}>
        <Ionicons name={icon as any} size={16} color={colors.brandPrimary} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: 11, fontWeight: "800", color: colors.muted, letterSpacing: 0.4 }}>
          {title.toUpperCase()}
        </Text>
        <Text style={{ fontSize: 13, color: colors.onSurface, marginTop: 2 }} numberOfLines={1}>
          {value}
        </Text>
      </View>
    </View>
  );
}

const roundBtn = (bg: string) => ({
  width: 40, height: 40, borderRadius: 20, backgroundColor: bg,
  alignItems: "center" as const, justifyContent: "center" as const,
});
