import { View, Pressable, ScrollView } from "react-native";
import { Text } from "@/src/components/AppText";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Ionicons from "@react-native-vector-icons/ionicons";
import { useState } from "react";

import { useTheme, spacing, radius, shadow } from "@/src/theme";
import { menuItems } from "@/src/data/mock";
import { MenuItemRow, FloatingCartBar, useMenuQty, groupMenu } from "@/src/components/MenuItemRow";

// Dine-in = QR table ordering. Items already sent to the kitchen are on the running tab.
const TAB_SO_FAR = 62.5;

export default function DineMenu() {
  const { colors } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { qty, add, remove, count, total } = useMenuQty();
  const [waiterCalled, setWaiterCalled] = useState(false);
  const [cat, setCat] = useState<string>("Recommended");
  const sections = groupMenu(menuItems);
  const shown = sections.filter((s) => s.title === cat);

  return (
    <View style={{ flex: 1, backgroundColor: colors.surface }}>
      {/* Header */}
      <View style={{ paddingTop: insets.top, backgroundColor: colors.surface, borderBottomWidth: 1, borderBottomColor: colors.divider }}>
        <View style={{ paddingHorizontal: spacing.lg, paddingVertical: spacing.sm, flexDirection: "row", alignItems: "center", gap: spacing.md }}>
          <Pressable testID="dine-back" onPress={() => router.back()} style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: colors.surfaceSecondary, alignItems: "center", justifyContent: "center" }}>
            <Ionicons name="arrow-back" size={20} color={colors.onSurface} />
          </Pressable>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 17, fontWeight: "900", color: colors.onSurface }}>Nasi Lemak Village</Text>
            <Text style={{ fontSize: 12, color: colors.muted, marginTop: 1 }}>Dine-in • Bukit Bintang</Text>
          </View>
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: colors.brandPrimary, paddingHorizontal: 10, paddingVertical: 6, borderRadius: radius.md }}>
            <Ionicons name="qr-code" size={13} color="#FFFFFF" />
            <Text style={{ fontSize: 12, fontWeight: "900", color: "#FFFFFF" }}>TABLE 5</Text>
          </View>
        </View>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 110 + insets.bottom }} showsVerticalScrollIndicator={false} stickyHeaderIndices={[1]}>
        {/* Seated card + running tab */}
        <View style={{ padding: spacing.lg, gap: spacing.md }}>
          <View style={{ backgroundColor: colors.brandTertiary, borderRadius: radius.lg, padding: spacing.md, flexDirection: "row", alignItems: "center", gap: spacing.md, borderWidth: 1, borderColor: colors.brandSecondary }}>
            <Ionicons name="checkmark-circle" size={24} color={colors.brandPrimary} />
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 14, fontWeight: "800", color: colors.onSurface }}>Scanned Table 5 • 2 guests</Text>
              <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>Orders go straight to the kitchen. Pay when you&apos;re done.</Text>
            </View>
          </View>
          <View style={{ flexDirection: "row", gap: spacing.md }}>
            <Pressable testID="running-tab" onPress={() => router.push("/dine-in/bill")} style={{ flex: 1, backgroundColor: colors.surface, borderRadius: radius.md, padding: spacing.md, borderWidth: 1, borderColor: colors.border, ...shadow.card }}>
              <Text style={{ fontSize: 11, fontWeight: "800", color: colors.muted }}>RUNNING TAB</Text>
              <Text style={{ fontSize: 17, fontWeight: "900", color: colors.onSurface, marginTop: 2 }}>RM {TAB_SO_FAR.toFixed(2)}</Text>
              <Text style={{ fontSize: 11, fontWeight: "700", color: colors.brandPrimary, marginTop: 2 }}>4 items served ›</Text>
            </Pressable>
            <Pressable
              testID="call-waiter"
              onPress={() => setWaiterCalled(true)}
              style={{ flex: 1, backgroundColor: waiterCalled ? colors.surfaceSecondary : colors.onSurface, borderRadius: radius.md, padding: spacing.md, justifyContent: "center", ...shadow.card }}
            >
              <Ionicons name={waiterCalled ? "checkmark-done" : "hand-left"} size={18} color={waiterCalled ? colors.onSurface : "#FFFFFF"} />
              <Text style={{ fontSize: 14, fontWeight: "800", color: waiterCalled ? colors.onSurface : "#FFFFFF", marginTop: 4 }}>
                {waiterCalled ? "Waiter is coming" : "Call waiter"}
              </Text>
            </Pressable>
          </View>
        </View>

        {/* Sticky category tabs */}
        <View style={{ backgroundColor: colors.surface, borderBottomWidth: 1, borderBottomColor: colors.divider }}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: spacing.lg, gap: spacing.lg }}>
            {sections.map((s) => {
              const on = s.title === cat;
              return (
                <Pressable key={s.title} testID={`dine-cat-${s.title}`} onPress={() => setCat(s.title)} style={{ paddingVertical: spacing.md, borderBottomWidth: 3, borderBottomColor: on ? colors.brandPrimary : "transparent" }}>
                  <Text style={{ fontSize: 14, fontWeight: on ? "900" : "600", color: on ? colors.brandPrimary : colors.onSurfaceSecondary }}>{s.title}</Text>
                </Pressable>
              );
            })}
          </ScrollView>
        </View>

        {shown.map((s) => (
          <View key={s.title} style={{ paddingHorizontal: spacing.lg }}>
            <Text style={{ fontSize: 16, fontWeight: "900", color: colors.onSurface, marginTop: spacing.md }}>{s.title} ({s.items.length})</Text>
            {s.items.map((m, i) => (
              <MenuItemRow key={m.id} item={m} qty={qty[m.id] ?? 0} onAdd={() => add(m.id)} onRemove={() => remove(m.id)} last={i === s.items.length - 1} />
            ))}
          </View>
        ))}
      </ScrollView>

      {count > 0 ? (
        <FloatingCartBar count={count} total={total} label="Send to kitchen" testID="send-to-kitchen" onPress={() => router.push("/dine-in/bill")} bottom={insets.bottom + spacing.md} />
      ) : (
        <View style={{ position: "absolute", left: spacing.md, right: spacing.md, bottom: insets.bottom + spacing.md }}>
          <Pressable
            testID="view-tab-cta"
            onPress={() => router.push("/dine-in/bill")}
            style={{ backgroundColor: colors.onSurface, borderRadius: radius.md, height: 56, flexDirection: "row", alignItems: "center", paddingHorizontal: spacing.lg, ...shadow.card }}
          >
            <Ionicons name="receipt" size={18} color="#FFFFFF" />
            <Text style={{ flex: 1, color: "#FFFFFF", fontSize: 15, fontWeight: "800", marginLeft: spacing.sm }}>View tab & pay</Text>
            <Text style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "900" }}>RM {TAB_SO_FAR.toFixed(2)}</Text>
          </Pressable>
        </View>
      )}
    </View>
  );
}
