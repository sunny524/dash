import { View, Pressable, ScrollView } from "react-native";
import { Text } from "@/src/components/AppText";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Ionicons from "@react-native-vector-icons/ionicons";

import { useTheme, spacing, radius } from "@/src/theme";
import { ScreenHeader } from "@/src/components/ScreenHeader";
import { RestaurantCard } from "@/src/components/RestaurantCard";
import { restaurants } from "@/src/data/mock";
import { useFavourites } from "@/src/data/cart-store";

export default function Favourites() {
  const { colors } = useTheme();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const ids = useFavourites((s) => s.ids);
  const list = restaurants.filter((r) => ids.includes(r.id));

  return (
    <View style={{ flex: 1, backgroundColor: colors.surface }}>
      <ScreenHeader title="Favourites" onBack={() => router.back()} />
      {list.length === 0 ? (
        <View testID="favourites-empty" style={{ flex: 1, alignItems: "center", justifyContent: "center", padding: spacing.xl }}>
          <View style={{ width: 88, height: 88, borderRadius: 44, backgroundColor: colors.brandTertiary, alignItems: "center", justifyContent: "center" }}>
            <Ionicons name="heart-outline" size={40} color={colors.brandPrimary} />
          </View>
          <Text style={{ fontSize: 18, fontWeight: "900", color: colors.onSurface, marginTop: spacing.lg }}>No favourites yet</Text>
          <Text style={{ fontSize: 13, color: colors.muted, marginTop: 4, textAlign: "center" }}>Tap the heart on any restaurant to save it here</Text>
          <Pressable testID="favourites-browse" onPress={() => router.push("/(tabs)/home")} style={{ marginTop: spacing.lg, backgroundColor: colors.brandPrimary, paddingHorizontal: spacing.xl, height: 48, borderRadius: radius.pill, justifyContent: "center" }}>
            <Text style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "800" }}>Explore restaurants</Text>
          </Pressable>
        </View>
      ) : (
        <ScrollView contentContainerStyle={{ padding: spacing.lg, paddingBottom: insets.bottom + 24 }}>
          <Text style={{ fontSize: 16, fontWeight: "900", color: colors.onSurface, marginBottom: spacing.md }}>
            {list.length} saved restaurant{list.length === 1 ? "" : "s"}
          </Text>
          {list.map((r) => (
            <RestaurantCard key={r.id} r={r} onPress={() => router.push(`/delivery/restaurant/${r.id}`)} />
          ))}
        </ScrollView>
      )}
    </View>
  );
}
