// Dash typography: Outfit (free Gilroy look-alike) with Swiggy-style leading.
// Drop-in replacements for react-native Text / TextInput.
import { createContext, useContext } from "react";
import { Text as RNText, TextInput as RNTextInput, StyleSheet, type TextProps, type TextInputProps, type TextStyle } from "react-native";

export const FONT_FILES = {
  "Outfit-Regular": require("../../assets/fonts/Outfit-Regular.ttf"),
  "Outfit-Medium": require("../../assets/fonts/Outfit-Medium.ttf"),
  "Outfit-SemiBold": require("../../assets/fonts/Outfit-SemiBold.ttf"),
  "Outfit-Bold": require("../../assets/fonts/Outfit-Bold.ttf"),
  "Outfit-ExtraBold": require("../../assets/fonts/Outfit-ExtraBold.ttf"),
  "Outfit-Black": require("../../assets/fonts/Outfit-Black.ttf"),
};

const FAMILY: Record<string, keyof typeof FONT_FILES> = {
  "100": "Outfit-Regular", "200": "Outfit-Regular", "300": "Outfit-Regular", "400": "Outfit-Regular", normal: "Outfit-Regular",
  "500": "Outfit-Medium", "600": "Outfit-SemiBold", "700": "Outfit-Bold", bold: "Outfit-Bold",
  "800": "Outfit-ExtraBold", "900": "Outfit-Black",
};

// Swiggy masterbrand leading: headline/subhead 1.1× (88/80, 33/30), body 1.4× (21/15)
const leading = (size: number) => Math.round(size * (size >= 18 ? 1.1 : 1.4));

const InText = createContext(false);

function fontStyle(style: TextProps["style"], nested: boolean): TextStyle | null {
  const flat = (StyleSheet.flatten(style) ?? {}) as TextStyle;
  if (flat.fontFamily) return null;
  // Nested text inherits the parent's font unless it sets its own weight
  if (nested && flat.fontWeight === undefined) return null;
  const out: TextStyle = { fontFamily: FAMILY[String(flat.fontWeight ?? "400")] ?? "Outfit-Regular", fontWeight: "normal" };
  if (flat.lineHeight === undefined && (!nested || flat.fontSize !== undefined)) out.lineHeight = leading(flat.fontSize ?? 14);
  return out;
}

export function Text(props: TextProps & { ref?: React.Ref<RNText> }) {
  const nested = useContext(InText);
  const extra = fontStyle(props.style, nested);
  return (
    <InText.Provider value>
      <RNText {...props} style={extra ? [props.style, extra] : props.style} />
    </InText.Provider>
  );
}

export function TextInput(props: TextInputProps & { ref?: React.Ref<RNTextInput> }) {
  const flat = (StyleSheet.flatten(props.style) ?? {}) as TextStyle;
  const family = flat.fontFamily ?? FAMILY[String(flat.fontWeight ?? "400")] ?? "Outfit-Regular";
  return <RNTextInput {...props} style={[props.style, { fontFamily: family, fontWeight: "normal" }]} />;
}
