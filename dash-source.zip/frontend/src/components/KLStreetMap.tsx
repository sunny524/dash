import { View, Platform, Animated, Easing, useWindowDimensions } from "react-native";
import { useEffect, useRef, useState } from "react";
import Svg, { Rect, Line, Polyline, Text as SvgText, G } from "react-native-svg";
import Ionicons from "@react-native-vector-icons/ionicons";

import { useTheme, shadow } from "@/src/theme";

// Stylised Bukit Bintang street map (mock) — restaurant → rider → home.
// Map tints stay the same in any theme, like a real map tile.
const MAP_BG = "#EEF0F3";
const BLOCK = "#E2E5EA";
const PARK = "#DDEBD8";
const ROAD_EDGE = "#D3D7DE";
const LABEL = "#7C828C";
const FONT = Platform.select({ web: "Helvetica, Arial, sans-serif", default: undefined });

const START = 0.38; // rider has already covered part of the route
const DURATION = 30000; // ms for the rest of the trip in the demo

export function KLStreetMap({ height, onProgress, onArrive }: {
  height: number;
  onProgress?: (p: number) => void;
  onArrive?: () => void;
}) {
  const { colors } = useTheme();
  const { width: w } = useWindowDimensions();
  const x = (f: number) => f * w;

  const restaurant = { x: x(0.18), y: 90 };
  const home = { x: x(0.82), y: 290 };
  const pts = [restaurant, { x: x(0.55), y: 90 }, { x: x(0.55), y: 250 }, { x: x(0.82), y: 250 }, home];

  // Cumulative fraction of route length at each point
  const lens = pts.slice(1).map((pt, i) => Math.hypot(pt.x - pts[i].x, pt.y - pts[i].y));
  const totalLen = lens.reduce((a, b) => a + b, 0);
  const cum = [0];
  lens.forEach((l) => cum.push(cum[cum.length - 1] + l / totalLen));
  cum[cum.length - 1] = 1;

  const pointAt = (p: number) => {
    const i = Math.max(0, cum.findIndex((c, k) => k > 0 && p <= c) - 1);
    const t = (p - cum[i]) / (cum[i + 1] - cum[i] || 1);
    return { x: pts[i].x + (pts[i + 1].x - pts[i].x) * t, y: pts[i].y + (pts[i + 1].y - pts[i].y) * t, i };
  };

  const progress = useRef(new Animated.Value(START)).current;
  const [p, setP] = useState(START);
  const cbs = useRef({ onProgress, onArrive });
  cbs.current = { onProgress, onArrive };

  useEffect(() => {
    let last = START;
    const id = progress.addListener(({ value }) => {
      const r = Math.round(value * 100) / 100;
      if (r !== last) {
        last = r;
        setP(r);
        cbs.current.onProgress?.(r);
      }
    });
    Animated.timing(progress, { toValue: 1, duration: DURATION, easing: Easing.linear, useNativeDriver: false })
      .start(({ finished }) => finished && cbs.current.onArrive?.());
    return () => {
      progress.removeListener(id);
      progress.stopAnimation();
    };
  }, [progress]);

  const rider = pointAt(p);
  const done = [...pts.slice(0, rider.i + 1), rider].map((q) => `${q.x},${q.y}`).join(" ");
  const remaining = [rider, ...pts.slice(rider.i + 1)].map((q) => `${q.x},${q.y}`).join(" ");
  const riderX = progress.interpolate({ inputRange: cum, outputRange: pts.map((q) => q.x - 22) });
  const riderY = progress.interpolate({ inputRange: cum, outputRange: pts.map((q) => q.y - 22) });

  const road = (x1: number, y1: number, x2: number, y2: number, main = true, key?: string) => (
    <G key={key}>
      <Line x1={x1} y1={y1} x2={x2} y2={y2} stroke={ROAD_EDGE} strokeWidth={main ? 16 : 9} strokeLinecap="round" />
      <Line x1={x1} y1={y1} x2={x2} y2={y2} stroke="#FFFFFF" strokeWidth={main ? 13 : 6} strokeLinecap="round" />
    </G>
  );

  return (
    <View testID="kl-street-map" style={{ width: w, height }}>
      <Svg width={w} height={height}>
        <Rect x={0} y={0} width={w} height={height} fill={MAP_BG} />

        {/* City blocks */}
        <Rect x={x(0.33)} y={110} width={x(0.18)} height={120} rx={6} fill={BLOCK} />
        <Rect x={x(0.04)} y={110} width={x(0.22)} height={56} rx={6} fill={BLOCK} />
        <Rect x={x(0.04)} y={200} width={x(0.22)} height={36} rx={6} fill={BLOCK} />
        <Rect x={x(0.86)} y={110} width={x(0.12)} height={120} rx={6} fill={BLOCK} />
        <Rect x={x(0.33)} y={270} width={x(0.18)} height={56} rx={6} fill={BLOCK} />
        <Rect x={x(0.59)} y={270} width={x(0.19)} height={56} rx={6} fill={BLOCK} />
        <Rect x={x(0.33)} y={14} width={x(0.62)} height={56} rx={6} fill={BLOCK} />

        {/* Park */}
        <Rect x={x(0.59)} y={110} width={x(0.19)} height={120} rx={8} fill={PARK} />
        <SvgText fontFamily={FONT} x={x(0.685)} y={174} fontSize={10} fontWeight="700" fill="#6E8F66" textAnchor="middle">KLCC Park</SvgText>

        {/* Minor roads */}
        {road(0, 180, x(0.3), 180, false, "m1")}
        {road(x(0.82), 180, w, 160, false, "m2")}
        {road(x(0.3), 250, x(0.3), height, false, "m3")}
        {road(x(0.12), 0, x(0.12), 90, false, "m4")}

        {/* Main roads */}
        {road(0, 90, w, 90, true, "r1")}
        {road(0, 250, w, 250, true, "r2")}
        {road(0, 345, w, 345, true, "r3")}
        {road(x(0.3), 0, x(0.3), 250, true, "r4")}
        {road(x(0.55), 0, x(0.55), height, true, "r5")}
        {road(x(0.82), 0, x(0.82), height, true, "r6")}

        {/* Street names */}
        <SvgText fontFamily={FONT} x={x(0.6)} y={80} fontSize={9} fontWeight="700" fill={LABEL}>Jalan Sultan Ismail</SvgText>
        <SvgText fontFamily={FONT} x={x(0.04)} y={243} fontSize={9} fontWeight="700" fill={LABEL}>Jalan Bukit Bintang</SvgText>
        <SvgText fontFamily={FONT} x={x(0.04)} y={338} fontSize={9} fontWeight="700" fill={LABEL}>Jalan Imbi</SvgText>
        <SvgText fontFamily={FONT} x={x(0.42)} y={50} fontSize={9} fontWeight="700" fill={LABEL}>Pavilion KL</SvgText>
        <SvgText
          fontFamily={FONT}
          x={x(0.55) + 12} y={262} fontSize={9} fontWeight="700" fill={LABEL}
          transform={`rotate(90 ${x(0.55) + 12} 262)`}
        >
          Jalan Raja Chulan
        </SvgText>

        {/* Route: solid = travelled, dotted = still to go */}
        <Polyline points={done} fill="none" stroke={colors.brandPrimary} strokeWidth={5} strokeLinejoin="round" strokeLinecap="round" />
        <Polyline points={remaining} fill="none" stroke={colors.brandPrimary} strokeWidth={4} strokeDasharray="2 8" strokeLinejoin="round" strokeLinecap="round" />
      </Svg>

      <Pin at={restaurant} size={34} bg="#FFFFFF" icon="restaurant" iconColor={colors.brandPrimary} testID="map-restaurant-pin" />
      <Pin at={home} size={36} bg={colors.onSurface} icon="home" iconColor="#FFFFFF" testID="map-home-pin" />

      <Animated.View
        testID="map-rider-pin"
        style={{ position: "absolute", left: 0, top: 0, transform: [{ translateX: riderX }, { translateY: riderY }] }}
      >
        <View style={{ position: "absolute", left: -8, top: -8, width: 60, height: 60, borderRadius: 30, backgroundColor: colors.brandPrimary, opacity: 0.14 }} />
        <View style={{
          width: 44, height: 44, borderRadius: 22, backgroundColor: colors.brandPrimary,
          alignItems: "center", justifyContent: "center", borderWidth: 3, borderColor: "#FFFFFF", ...shadow.card,
        }}>
          <Ionicons name="bicycle" size={20} color="#FFFFFF" />
        </View>
      </Animated.View>
    </View>
  );
}

function Pin({ at, size, bg, icon, iconColor, testID }: {
  at: { x: number; y: number }; size: number; bg: string; icon: string; iconColor: string; testID: string;
}) {
  return (
    <View
      testID={testID}
      style={{
        position: "absolute", left: at.x - size / 2, top: at.y - size / 2,
        width: size, height: size, borderRadius: size / 2, backgroundColor: bg,
        alignItems: "center", justifyContent: "center",
        borderWidth: 3, borderColor: "#FFFFFF", ...shadow.card,
      }}
    >
      <Ionicons name={icon as any} size={size * 0.45} color={iconColor} />
    </View>
  );
}
