import { Pressable, View } from "react-native";
import { Text } from "@/src/components/AppText";
import { Image } from "expo-image";
import Ionicons from "@react-native-vector-icons/ionicons";

import { useState } from "react";

import { useTheme, spacing, radius } from "@/src/theme";
import { menuItems, type MenuItem } from "@/src/data/mock";

export function useMenuQty(initial: Record<string, number> = {}) {
  const [qty, setQty] = useState<Record<string, number>>(initial);
  const add = (id: string) => setQty((q) => ({ ...q, [id]: (q[id] ?? 0) + 1 }));
  const remove = (id: string) => setQty((q) => ({ ...q, [id]: Math.max(0, (q[id] ?? 0) - 1) }));
  const count = Object.values(qty).reduce((a, b) => a + b, 0);
  const total = menuItems.reduce((s, m) => s + (qty[m.id] ?? 0) * m.price, 0);
  return { qty, add, remove, count, total };
}

export function groupMenu(items: MenuItem[]) {
  const sections: { title: string; items: MenuItem[] }[] = [{ title: "Recommended", items: items.filter((m) => m.popular) }];
  Array.from(new Set(items.map((m) => m.category))).forEach((c) => sections.push({ title: c, items: items.filter((m) => m.category === c) }));
  return sections.filter((s) => s.items.length > 0);
}

// Swiggy-style menu row: text left, square image right, ADD / stepper overlapping the image's bottom edge.
export function MenuItemRow({ item, qty, onAdd, onRemove, onPress, last }: {
  item: MenuItem; qty: number; onAdd: () => void; onRemove: () => void; onPress?: () => void; last?: boolean;
}) {
  const { colors } = useTheme();
  return (
    <Pressable
      testID={`menu-item-${item.id}`}
      onPress={onPress}
      style={{
        flexDirection: "row", gap: spacing.md, paddingVertical: spacing.md,
        borderBottomWidth: last ? 0 : 1, borderBottomColor: colors.divider, borderStyle: "dashed",
      }}
    >
      <View style={{ flex: 1 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
          <HalalMark />
          {item.popular && (
            <View style={{ flexDirection: "row", alignItems: "center", gap: 3 }}>
              <Ionicons name="star" size={11} color={colors.warning} />
              <Text style={{ fontSize: 11, fontWeight: "800", color: colors.warning }}>Bestseller</Text>
            </View>
          )}
        </View>
        <Text style={{ fontSize: 15, fontWeight: "700", color: colors.onSurface, marginTop: 4 }}>{item.name}</Text>
        <Text style={{ fontSize: 14, fontWeight: "700", color: colors.onSurface, marginTop: 2 }}>RM {item.price.toFixed(2)}</Text>
        {item.popular && (
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 6 }}>
            <Ionicons name="star" size={11} color={colors.brandPrimary} />
            <Text style={{ fontSize: 12, fontWeight: "700", color: colors.brandPrimary }}>4.6</Text>
            <Text style={{ fontSize: 12, color: colors.muted }}>(212)</Text>
          </View>
        )}
        <Text style={{ fontSize: 12, color: colors.muted, marginTop: 4, lineHeight: 17 }} numberOfLines={2}>{item.description}</Text>
      </View>

      <View style={{ width: 116, alignItems: "center" }}>
        <Image source={{ uri: item.image }} style={{ width: 116, height: 108, borderRadius: radius.md }} contentFit="cover" />
        <View style={{ marginTop: -22 }}>
          <AddButton qty={qty} onAdd={onAdd} onRemove={onRemove} testID={`add-${item.id}`} />
        </View>
        <Text style={{ fontSize: 10, color: colors.muted, marginTop: 4 }}>Customisable</Text>
      </View>
    </Pressable>
  );
}

export function AddButton({ qty, onAdd, onRemove, testID }: { qty: number; onAdd: () => void; onRemove: () => void; testID?: string }) {
  const { colors } = useTheme();
  const box = {
    width: 96, height: 36, borderRadius: radius.md, backgroundColor: colors.surface,
    borderWidth: 1, borderColor: colors.border,
    shadowColor: "#0F172A", shadowOpacity: 0.12, shadowRadius: 8, shadowOffset: { width: 0, height: 3 }, elevation: 3,
  };
  if (qty === 0) {
    return (
      <Pressable testID={testID} onPress={onAdd} style={{ ...box, alignItems: "center", justifyContent: "center" }}>
        <Text style={{ fontSize: 16, fontWeight: "900", color: colors.brandPrimary }}>ADD</Text>
        <Text style={{ position: "absolute", top: 2, right: 8, fontSize: 14, fontWeight: "700", color: colors.brandPrimary }}>+</Text>
      </Pressable>
    );
  }
  return (
    <View testID={`${testID}-stepper`} style={{ ...box, flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
      <Pressable testID={`${testID}-minus`} onPress={onRemove} hitSlop={6} style={{ width: 36, height: 40, alignItems: "center", justifyContent: "center" }}>
        <Ionicons name="remove" size={18} color={colors.brandPrimary} />
      </Pressable>
      <Text style={{ fontSize: 16, fontWeight: "900", color: colors.brandPrimary }}>{qty}</Text>
      <Pressable testID={`${testID}-plus`} onPress={onAdd} hitSlop={6} style={{ width: 36, height: 40, alignItems: "center", justifyContent: "center" }}>
        <Ionicons name="add" size={18} color={colors.brandPrimary} />
      </Pressable>
    </View>
  );
}

// Small halal marker (stands in for Swiggy's veg dot in the Malaysian market). Green is the universal halal cue.
export function HalalMark() {
  return (
    <View style={{ width: 16, height: 16, borderRadius: 3, borderWidth: 1.5, borderColor: "#1E8E3E", alignItems: "center", justifyContent: "center" }}>
      <View style={{ width: 7, height: 7, borderRadius: 4, backgroundColor: "#1E8E3E" }} />
    </View>
  );
}

// Floating "N items added · View Cart" bar
export function FloatingCartBar({ count, total, label = "View Cart", onPress, bottom, testID = "view-cart-cta" }: {
  count: number; total: number; label?: string; onPress: () => void; bottom: number; testID?: string;
}) {
  const { colors } = useTheme();
  if (count === 0) return null;
  return (
    <View style={{ position: "absolute", left: spacing.md, right: spacing.md, bottom }}>
      <Pressable
        testID={testID}
        onPress={onPress}
        style={{
          backgroundColor: colors.brandPrimary, borderRadius: radius.md, height: 52,
          flexDirection: "row", alignItems: "center", paddingHorizontal: spacing.lg,
          shadowColor: "#0F172A", shadowOpacity: 0.2, shadowRadius: 14, shadowOffset: { width: 0, height: 6 }, elevation: 8,
        }}
      >
        <View style={{ flex: 1 }}>
          <Text style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "800" }}>{count} item{count > 1 ? "s" : ""} added</Text>
          <Text style={{ color: "rgba(255,255,255,0.85)", fontSize: 11, fontWeight: "600", marginTop: 1 }}>RM {total.toFixed(2)} plus taxes</Text>
        </View>
        <Text style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "800" }}>{label}</Text>
        <Ionicons name="caret-forward" size={14} color="#FFFFFF" style={{ marginLeft: 6 }} />
      </Pressable>
    </View>
  );
}
