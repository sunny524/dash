import { Pressable, View } from "react-native";
import { Text } from "@/src/components/AppText";
import { Image } from "expo-image";
import { LinearGradient } from "expo-linear-gradient";
import Ionicons from "@react-native-vector-icons/ionicons";
import { useFavourites } from "@/src/data/cart-store";

import { makeStyles, useTheme, spacing, radius, shadow } from "@/src/theme";
import type { Restaurant } from "@/src/data/mock";

const useStyles = makeStyles((c) => ({
  name: { fontSize: 15, fontWeight: "700", color: c.onSurface, marginBottom: 2 },
  metaRow: { flexDirection: "row", alignItems: "center", flexWrap: "wrap", gap: 6 },
  metaChip: { flexDirection: "row", alignItems: "center", gap: 3 },
  metaText: { fontSize: 12, color: c.onSurfaceSecondary, fontWeight: "500" },
  dot: { fontSize: 12, color: c.muted },
  cuisines: { fontSize: 12, color: c.muted, marginTop: 2 },
  ratingBadge: {
    flexDirection: "row", alignItems: "center", gap: 3,
    backgroundColor: c.brandTertiary, paddingHorizontal: 7, paddingVertical: 2, borderRadius: radius.pill,
  },
  ratingText: { fontSize: 11, fontWeight: "700", color: c.onBrandTertiary },
  row: {
    flexDirection: "row", backgroundColor: c.surface, borderRadius: radius.lg, padding: spacing.sm,
    marginBottom: spacing.sm, gap: spacing.md, alignItems: "center", ...shadow.card,
  },
  rowImg: { width: 76, height: 76, borderRadius: radius.md, backgroundColor: c.surfaceTertiary },
}));

const offerText = (promo?: string) =>
  !promo ? "" : promo.includes("%") ? `${promo} UPTO RM10` : promo.toUpperCase();

// "7:30 PM" → three bookable slots 30 min apart (value in 24h for the booking form)
const nextSlots = (first: string) => {
  const [hm, ap] = first.split(" ");
  const [h, m] = hm.split(":").map(Number);
  const start = ((h % 12) + (ap === "PM" ? 12 : 0)) * 60 + m;
  return [0, 30, 60].map((d) => {
    const t = start + d, hh = Math.floor(t / 60), mm = t % 60;
    const pad = (n: number) => String(n).padStart(2, "0");
    return { value: `${pad(hh)}:${pad(mm)}`, label: `${((hh + 11) % 12) + 1}:${pad(mm)} ${hh >= 12 ? "PM" : "AM"}` };
  });
};

export function RestaurantCard({ r, onPress, compact = false, booking = false, onSlot }: { r: Restaurant; onPress?: () => void; compact?: boolean; booking?: boolean; onSlot?: (time: string) => void }) {
  const styles = useStyles();
  const { colors } = useTheme();
  const fav = useFavourites((s) => s.ids.includes(r.id));
  const toggleFav = useFavourites((s) => s.toggle);

  if (compact) {
    return (
      <Pressable onPress={onPress} testID={`restaurant-card-${r.id}`} style={styles.row}>
        <Image source={{ uri: r.image }} style={styles.rowImg} contentFit="cover" />
        <View style={{ flex: 1 }}>
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
            <Text style={styles.name} numberOfLines={1}>{r.name}</Text>
            <View style={styles.ratingBadge}>
              <Ionicons name="star" size={11} color={colors.brandPrimary} />
              <Text style={styles.ratingText}>{r.rating.toFixed(1)}</Text>
            </View>
          </View>
          <Text style={styles.cuisines} numberOfLines={1}>{r.cuisines.join(" • ")} • {r.priceRange}</Text>
          <View style={[styles.metaRow, { marginTop: 6 }]}>
            <View style={styles.metaChip}>
              <Ionicons name="time-outline" size={12} color={colors.onSurfaceSecondary} />
              <Text style={styles.metaText}>{r.etaMin}min</Text>
            </View>
            <Text style={styles.dot}>•</Text>
            <View style={styles.metaChip}>
              <Ionicons name="location-outline" size={12} color={colors.onSurfaceSecondary} />
              <Text style={styles.metaText}>{r.distanceKm}km</Text>
            </View>
            {r.promo ? (
              <>
                <Text style={styles.dot}>•</Text>
                <Text style={[styles.metaText, { color: colors.brandPrimary, fontWeight: "700" }]}>{r.promo}</Text>
              </>
            ) : null}
          </View>
        </View>
      </Pressable>
    );
  }

  // Swiggy-style feed card: big photo with dark scrim + offer text, details underneath
  return (
    <Pressable onPress={onPress} testID={`restaurant-card-${r.id}`} style={{ marginBottom: spacing.lg }}>
      <View style={{ height: 160, borderRadius: radius.lg, overflow: "hidden", backgroundColor: colors.surfaceTertiary }}>
        <Image source={{ uri: r.image }} style={{ width: "100%", height: "100%" }} contentFit="cover" />
        <LinearGradient
          colors={["transparent", "rgba(0,0,0,0.85)"]}
          style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 90 }}
        />
        <Pressable
          testID={`fav-${r.id}`}
          onPress={() => toggleFav(r.id)}
          hitSlop={6}
          style={{
            position: "absolute", top: spacing.sm, right: spacing.sm, width: 36, height: 36, borderRadius: 18,
            backgroundColor: "rgba(0,0,0,0.25)", alignItems: "center", justifyContent: "center",
          }}
        >
          <Ionicons name={fav ? "heart" : "heart-outline"} size={18} color={fav ? colors.brandPrimary : "#FFFFFF"} />
        </Pressable>
        {booking && r.booking ? (
          <>
            <View style={{ position: "absolute", top: spacing.sm, left: spacing.sm, backgroundColor: "rgba(255,255,255,0.95)", paddingHorizontal: 8, paddingVertical: 3, borderRadius: radius.sm, flexDirection: "row", alignItems: "center", gap: 4 }}>
              <View style={{ width: 6, height: 6, borderRadius: 3, backgroundColor: r.booking.tablesLeft <= 2 ? colors.warning : colors.brandPrimary }} />
              <Text style={{ fontSize: 10, fontWeight: "800", color: colors.onSurface }}>
                {r.booking.tablesLeft <= 2 ? `ONLY ${r.booking.tablesLeft} TABLES LEFT` : `${r.booking.tablesLeft} TABLES TONIGHT`}
              </Text>
            </View>
            <Text style={{ position: "absolute", left: spacing.md, bottom: spacing.sm, color: "#FFFFFF", fontSize: 17, fontWeight: "900", letterSpacing: -0.3 }}>
              NEXT TABLE {r.booking.nextSlot}
            </Text>
          </>
        ) : (
          <>
            {r.pickupAvailable && (
              <View style={{ position: "absolute", top: spacing.sm, left: spacing.sm, backgroundColor: "rgba(255,255,255,0.95)", paddingHorizontal: 8, paddingVertical: 3, borderRadius: radius.sm }}>
                <Text style={{ fontSize: 10, fontWeight: "800", color: colors.onSurface }}>PICKUP • DINE-IN</Text>
              </View>
            )}
            {!!r.promo && (
              <Text style={{ position: "absolute", left: spacing.md, bottom: spacing.sm, color: "#FFFFFF", fontSize: 17, fontWeight: "900", letterSpacing: -0.3 }}>
                {offerText(r.promo)}
              </Text>
            )}
          </>
        )}
      </View>
      <View style={{ paddingHorizontal: spacing.xs, paddingTop: spacing.sm }}>
        <Text style={{ fontSize: 16, fontWeight: "800", color: colors.onSurface }} numberOfLines={1}>{r.name}</Text>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 3 }}>
          <View style={{ width: 18, height: 18, borderRadius: 9, backgroundColor: colors.brandPrimary, alignItems: "center", justifyContent: "center" }}>
            <Ionicons name="star" size={10} color="#FFFFFF" />
          </View>
          <Text style={{ fontSize: 14, fontWeight: "700", color: colors.onSurface }}>
            {r.rating.toFixed(1)} ({(r.reviews / 1000).toFixed(1)}K+) • {booking ? `${r.distanceKm} km away` : `${r.etaMin}-${r.etaMin + 5} mins`}
          </Text>
        </View>
        <Text style={{ fontSize: 13, color: colors.muted, marginTop: 3 }} numberOfLines={1}>{r.cuisines.join(", ")}</Text>
        {booking && r.booking ? (
          <>
            <View testID={`booking-info-${r.id}`} style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 6 }}>
              <Ionicons name="people" size={14} color={colors.brandPrimary} />
              <Text style={{ fontSize: 13, fontWeight: "700", color: colors.onSurface }}>Tables for {r.booking.party} guests</Text>
              <Text style={{ fontSize: 13, color: colors.muted }}>• Free cancellation</Text>
            </View>
            <View style={{ flexDirection: "row", gap: spacing.sm, marginTop: spacing.sm }}>
              {nextSlots(r.booking.nextSlot).map((s) => (
                <Pressable
                  key={s.value}
                  testID={`slot-${r.id}-${s.value}`}
                  onPress={() => onSlot?.(s.value)}
                  style={{ flex: 1, height: 36, borderRadius: radius.sm, borderWidth: 1, borderColor: colors.brandPrimary, alignItems: "center", justifyContent: "center", backgroundColor: colors.brandTertiary }}
                >
                  <Text style={{ fontSize: 13, fontWeight: "800", color: colors.brandPrimary }}>{s.label}</Text>
                </Pressable>
              ))}
            </View>
          </>
        ) : (
          <Text style={{ fontSize: 13, color: colors.muted, marginTop: 1 }} numberOfLines={1}>{r.address} • {r.distanceKm} km</Text>
        )}
      </View>
    </Pressable>
  );
}
