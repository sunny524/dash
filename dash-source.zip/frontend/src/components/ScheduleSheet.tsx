import { View, Pressable, Modal, ScrollView } from "react-native";
import { Text } from "@/src/components/AppText";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Ionicons from "@react-native-vector-icons/ionicons";
import { useState } from "react";

import { useTheme, spacing, radius } from "@/src/theme";
import { scheduleDays, slotsByDay, useSchedule, type Slot } from "@/src/data/schedule-mock";

export function ScheduleSheet({ visible, onClose }: { visible: boolean; onClose: () => void }) {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const { slot, setSlot } = useSchedule();
  const [day, setDay] = useState(scheduleDays[0].key);
  const [picked, setPicked] = useState<Slot | null>(slot);

  const confirm = (s: Slot | null) => {
    setSlot(s);
    onClose();
  };

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <Pressable testID="schedule-backdrop" onPress={onClose} style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.4)" }} />
      <View style={{
        backgroundColor: colors.surface, borderTopLeftRadius: 28, borderTopRightRadius: 28,
        paddingBottom: insets.bottom + spacing.md, maxHeight: "80%",
      }}>
        <View style={{ alignItems: "center", paddingTop: 10 }}>
          <View style={{ width: 40, height: 5, borderRadius: 3, backgroundColor: colors.border }} />
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: spacing.lg, paddingTop: spacing.md }}>
          <Text style={{ flex: 1, fontSize: 18, fontWeight: "800", color: colors.onSurface }}>When should we deliver?</Text>
          <Pressable testID="schedule-close" onPress={onClose} hitSlop={8} style={{ width: 36, height: 36, borderRadius: 18, backgroundColor: colors.surfaceSecondary, alignItems: "center", justifyContent: "center" }}>
            <Ionicons name="close" size={18} color={colors.onSurface} />
          </Pressable>
        </View>

        {/* ASAP */}
        <Pressable
          testID="schedule-asap"
          onPress={() => setPicked(null)}
          style={{
            marginHorizontal: spacing.lg, marginTop: spacing.md, padding: spacing.md, borderRadius: radius.lg,
            flexDirection: "row", alignItems: "center", gap: spacing.md, borderWidth: 1.5,
            borderColor: picked === null ? colors.brandPrimary : colors.border,
            backgroundColor: picked === null ? colors.brandTertiary : colors.surface,
          }}
        >
          <Ionicons name="flash" size={20} color={colors.brandPrimary} />
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 14, fontWeight: "800", color: colors.onSurface }}>As soon as possible</Text>
            <Text style={{ fontSize: 12, color: colors.muted, marginTop: 2 }}>Arriving in 20–30 min</Text>
          </View>
          {picked === null && <Ionicons name="checkmark-circle" size={22} color={colors.brandPrimary} />}
        </Pressable>

        {/* Days */}
        <Text style={{ fontSize: 12, fontWeight: "800", color: colors.muted, letterSpacing: 0.5, marginTop: spacing.lg, marginHorizontal: spacing.lg }}>
          SCHEDULE FOR LATER
        </Text>
        <View style={{ flexDirection: "row", gap: spacing.sm, paddingHorizontal: spacing.lg, marginTop: spacing.sm }}>
          {scheduleDays.map((d) => {
            const on = day === d.key;
            return (
              <Pressable
                key={d.key}
                testID={`schedule-day-${d.key}`}
                onPress={() => setDay(d.key)}
                style={{
                  flex: 1, paddingVertical: 10, borderRadius: radius.md, alignItems: "center",
                  backgroundColor: on ? colors.onSurface : colors.surfaceSecondary,
                }}
              >
                <Text style={{ fontSize: 13, fontWeight: "800", color: on ? colors.surface : colors.onSurface }}>{d.label}</Text>
                <Text style={{ fontSize: 11, color: on ? colors.surface : colors.muted, marginTop: 2 }}>{d.date}</Text>
              </Pressable>
            );
          })}
        </View>

        {/* Slots */}
        <ScrollView contentContainerStyle={{ padding: spacing.lg, flexDirection: "row", flexWrap: "wrap", gap: spacing.sm }} style={{ flexGrow: 0 }}>
          {slotsByDay[day].map((s) => {
            const on = picked?.id === s.id;
            return (
              <Pressable
                key={s.id}
                testID={`slot-${s.id}`}
                disabled={s.full}
                onPress={() => setPicked(s)}
                style={{
                  width: "48.5%", minHeight: 44, borderRadius: radius.pill, alignItems: "center", justifyContent: "center",
                  borderWidth: 1.5, opacity: s.full ? 0.45 : 1,
                  borderColor: on ? colors.brandPrimary : colors.border,
                  backgroundColor: on ? colors.brandTertiary : colors.surface,
                }}
              >
                <Text style={{ fontSize: 13, fontWeight: "700", color: on ? colors.brandPrimary : colors.onSurface }}>{s.time}</Text>
                {s.full && <Text style={{ fontSize: 10, color: colors.muted }}>Fully booked</Text>}
              </Pressable>
            );
          })}
        </ScrollView>

        <View style={{ paddingHorizontal: spacing.lg }}>
          <Pressable
            testID="schedule-confirm"
            onPress={() => confirm(picked)}
            style={{ backgroundColor: colors.brandPrimary, paddingVertical: 15, borderRadius: radius.pill, alignItems: "center" }}
          >
            <Text style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "800" }}>
              {picked ? `Schedule for ${picked.day}, ${picked.time}` : "Deliver ASAP"}
            </Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}
