// Shared delivery cart + favourites (mock, in-memory). Menu ADD buttons and Checkout read the same store.
import { create } from "zustand";
import { menuItems, restaurants } from "@/src/data/mock";

const addons: Record<string, string> = {
  m1: "Fried Egg, Medium Spice",
  m2: "Extra Sambal",
  m3: "With Dhal & Curry",
  m4: "Ice",
  m5: "Peanut Sauce, Ketupat",
  m6: "Medium Spice",
};

type CartState = {
  qty: Record<string, number>;
  restaurantId: string;
  add: (id: string) => void;
  remove: (id: string) => void;
  startNewCart: (restaurantId: string, firstItemId: string) => void;
};

export const useCartStore = create<CartState>((set) => ({
  qty: { m1: 1, m3: 2, m4: 2 },
  restaurantId: "r1",
  add: (id) => set((s) => ({ qty: { ...s.qty, [id]: (s.qty[id] ?? 0) + 1 } })),
  remove: (id) => set((s) => ({ qty: { ...s.qty, [id]: Math.max(0, (s.qty[id] ?? 0) - 1) } })),
  startNewCart: (restaurantId, firstItemId) => set({ restaurantId, qty: { [firstItemId]: 1 } }),
}));

export const cartLines = (qty = useCartStore.getState().qty) =>
  menuItems
    .filter((m) => (qty[m.id] ?? 0) > 0)
    .map((m) => ({ ...m, qty: qty[m.id], addons: addons[m.id] ?? "Regular" }));

export const cartSubtotal = (qty = useCartStore.getState().qty) =>
  cartLines(qty).reduce((s, l) => s + l.price * l.qty, 0);

export const cartItemCount = (qty = useCartStore.getState().qty) =>
  Object.values(qty).reduce((a, b) => a + b, 0);

export const cartRestaurant = () =>
  restaurants.find((r) => r.id === useCartStore.getState().restaurantId) ?? restaurants[0];

// Reactive hook used by the restaurant menu + Checkout
export function useCart() {
  const { qty, add, remove, restaurantId, startNewCart } = useCartStore();
  return { qty, add, remove, restaurantId, startNewCart, count: cartItemCount(qty), total: cartSubtotal(qty), lines: cartLines(qty) };
}

// Loyalty: 1 DashPoint per RM1 spent (rounded down)
export const pointsFor = (amount: number) => Math.floor(Math.max(0, amount));

type FavState = { ids: string[]; toggle: (id: string) => void };
export const useFavourites = create<FavState>((set) => ({
  ids: ["r3", "r4"],
  toggle: (id) => set((s) => ({ ids: s.ids.includes(id) ? s.ids.filter((x) => x !== id) : [...s.ids, id] })),
}));
