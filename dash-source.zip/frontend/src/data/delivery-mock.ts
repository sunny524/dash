// Mock data for the Delyva-integrated delivery flow.
// Frontend-only — no real API calls.

export type DeliveryAddress = {
  id: string;
  label: string;
  tag: "Home" | "Office" | "Other";
  line1: string;
  line2: string;
  distanceKm: number;
  instructions?: string;
};

export const savedAddresses: DeliveryAddress[] = [
  {
    id: "addr_home",
    label: "Home",
    tag: "Home",
    line1: "12A, Jalan Bukit Bintang",
    line2: "55100 Kuala Lumpur, Malaysia",
    distanceKm: 0.8,
    instructions: "Leave at the doorstep. Ring bell twice.",
  },
  {
    id: "addr_office",
    label: "Office",
    tag: "Office",
    line1: "Level 22, Menara Maxis, KLCC",
    line2: "50088 Kuala Lumpur, Malaysia",
    distanceKm: 2.3,
    instructions: "Reception on Ground Floor — ask for Sunny.",
  },
  {
    id: "addr_mom",
    label: "Mom's place",
    tag: "Other",
    line1: "Block B-12-3, Pangsapuri Mutiara",
    line2: "Wangsa Maju, 53300 KL",
    distanceKm: 6.1,
  },
];

// Shared cart lives in cart-store.ts so menu ADD buttons and Checkout stay in sync.
import { cartSubtotal } from "@/src/data/cart-store";
export { cartItemCount } from "@/src/data/cart-store";

// Promo applies on orders of RM25 and above
export const promo = { code: "EASYEAT20", amount: 6, minSpend: 25 };

export function orderTotals(deliveryFee: number, rewardsOff = 0) {
  const subtotal = cartSubtotal();
  const discount = subtotal >= promo.minSpend ? promo.amount : 0;
  return {
    subtotal,
    discount,
    deliveryFee,
    rewardsOff,
    total: Math.max(0, subtotal - discount + deliveryFee - rewardsOff),
  };
}

export type CourierQuote = {
  id: string;
  name: string;           // Courier service name
  logoChar: string;       // Single letter / short code for the badge
  logoColor: string;      // Background tint for the logo badge
  etaLabel: string;       // e.g. "25–35 min"
  etaMinutes: number;     // Lower bound for sorting
  fee: number;            // RM
  description: string;    // short one-liner
  tag?: "Fastest" | "Cheapest" | "Recommended";
  type: "bike" | "car";
};

export const courierQuotes: CourierQuote[] = [
  {
    id: "grab-instant",
    name: "GrabExpress Instant",
    logoChar: "G",
    logoColor: "#E23744",
    etaLabel: "25–35 min",
    etaMinutes: 25,
    fee: 10.9,
    description: "Fastest motorcycle courier, direct drop-off.",
    tag: "Fastest",
    type: "bike",
  },
  {
    id: "lalamove-moto",
    name: "Lalamove Motorcycle",
    logoChar: "L",
    logoColor: "#B32734",
    etaLabel: "40–55 min",
    etaMinutes: 40,
    fee: 7.5,
    description: "Budget-friendly, slightly longer wait.",
    tag: "Cheapest",
    type: "bike",
  },
  {
    id: "pandago",
    name: "pandago Instant",
    logoChar: "P",
    logoColor: "#8B1A24",
    etaLabel: "30–45 min",
    etaMinutes: 30,
    fee: 9.0,
    description: "Reliable rider network, balanced choice.",
    tag: "Recommended",
    type: "bike",
  },
];

// Delyva order lifecycle (mapped from PRD statusCode → user-friendly label)
export type DeliveryStatusKey =
  | "placed"
  | "preparing"
  | "courier_assigned"
  | "picked_up"
  | "out_for_delivery"
  | "delivered";

export const deliveryTimeline: {
  key: DeliveryStatusKey;
  code: number;
  title: string;
  desc: string;
  icon: string;
}[] = [
  { key: "placed", code: 100, title: "Order placed", desc: "We've received your order.", icon: "receipt" },
  { key: "preparing", code: 150, title: "Restaurant preparing", desc: "Nasi Lemak Village is cooking your food.", icon: "restaurant" },
  { key: "courier_assigned", code: 200, title: "Courier assigned", desc: "Aiman is heading to the restaurant.", icon: "bicycle" },
  { key: "picked_up", code: 210, title: "Order picked up", desc: "Your food is with the rider.", icon: "bag-check" },
  { key: "out_for_delivery", code: 320, title: "Out for delivery", desc: "Aiman is on the way to you.", icon: "navigate-circle" },
  { key: "delivered", code: 400, title: "Delivered", desc: "Enjoy your meal!", icon: "checkmark-done-circle" },
];

export const mockCourier = {
  name: "Aiman Bin Hassan",
  phone: "+60 12 345 6789",
  rating: 4.9,
  deliveries: 1240,
  vehicle: "Honda EX5 · VBM 1234",
  photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80",
};
