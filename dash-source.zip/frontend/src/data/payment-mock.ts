// Mock payment options (Swiggy-style grouped list). Frontend-only — no money moves.
import { create } from "zustand";

export type PaymentMethod = {
  id: string;
  group: "dash" | "ewallet" | "card" | "fpx" | "cod";
  label: string;
  sub?: string;
  icon: string;
  badge: string; // short text for the logo tile
  tint: string;  // logo tile colour (brand colour of the provider)
  offer?: string;
};

export const paymentMethods: PaymentMethod[] = [

  { id: "tng", group: "ewallet", label: "Touch 'n Go eWallet", sub: "Balance: RM 245.80", icon: "wallet", badge: "TnG", tint: "#1F4FA3" },
  { id: "grabpay", group: "ewallet", label: "GrabPay", sub: "Link account", icon: "wallet", badge: "G", tint: "#00A859", offer: "RM 3 off above RM 25" },
  { id: "boost", group: "ewallet", label: "Boost", sub: "Link account", icon: "wallet", badge: "B", tint: "#E4002B" },
  { id: "shopeepay", group: "ewallet", label: "ShopeePay", sub: "Link account", icon: "wallet", badge: "S", tint: "#EE4D2D" },

  { id: "visa", group: "card", label: "Visa •••• 4242", sub: "Expires 08/28", icon: "card", badge: "VISA", tint: "#1A1F71" },
  { id: "master", group: "card", label: "Mastercard •••• 8888", sub: "Expires 01/27", icon: "card", badge: "MC", tint: "#EB001B" },

  { id: "maybank", group: "fpx", label: "Maybank2u", icon: "business", badge: "MB", tint: "#F5B800" },
  { id: "cimb", group: "fpx", label: "CIMB Clicks", icon: "business", badge: "CIMB", tint: "#7A0019" },
  { id: "pbe", group: "fpx", label: "Public Bank", icon: "business", badge: "PB", tint: "#C8102E" },
  { id: "rhb", group: "fpx", label: "RHB Now", icon: "business", badge: "RHB", tint: "#005BAA" },
  { id: "hlb", group: "fpx", label: "Hong Leong Connect", icon: "business", badge: "HL", tint: "#00205B" },
  { id: "ambank", group: "fpx", label: "AmOnline", icon: "business", badge: "Am", tint: "#D71920" },

  { id: "cod", group: "cod", label: "Cash on delivery", sub: "Please keep exact change ready", icon: "cash", badge: "RM", tint: "#2E7D32" },
];

export const paymentGroups: { key: PaymentMethod["group"]; title: string }[] = [
  { key: "dash", title: "Loyalty rewards" },
  { key: "ewallet", title: "E-wallets" },
  { key: "card", title: "Credit & debit cards" },
  { key: "fpx", title: "Online banking (FPX)" },
  { key: "cod", title: "Pay on delivery" },
];

// Dash rewards: 500 pts = RM 5 off
export const rewards = { points: 1250, redeemPoints: 500, value: 5 };

export const getPaymentMethod = (id: string) => {
  const all = usePayment.getState().methods;
  return all.find((m) => m.id === id) ?? all[1];
};

export const cardBrand = (digits: string) =>
  digits.startsWith("4") ? { name: "Visa", badge: "VISA", tint: "#1A1F71" }
  : digits.startsWith("5") || digits.startsWith("2") ? { name: "Mastercard", badge: "MC", tint: "#EB001B" }
  : digits.startsWith("3") ? { name: "Amex", badge: "AMEX", tint: "#2E77BC" }
  : { name: "Card", badge: "CARD", tint: "#4A4A4A" };

type PaymentState = {
  methodId: string;
  useRewards: boolean;
  methods: PaymentMethod[];
  setMethod: (id: string) => void;
  setUseRewards: (v: boolean) => void;
  addCard: (card: { digits: string; expiry: string }) => string;
};

export const usePayment = create<PaymentState>((set, get) => ({
  methodId: "tng",
  useRewards: false,
  methods: paymentMethods,
  setMethod: (methodId) => set({ methodId }),
  setUseRewards: (useRewards) => set({ useRewards }),
  addCard: ({ digits, expiry }) => {
    const brand = cardBrand(digits);
    const id = `card-${Date.now()}`;
    const card: PaymentMethod = {
      id, group: "card", label: `${brand.name} •••• ${digits.slice(-4)}`, sub: `Expires ${expiry}`,
      icon: "card", badge: brand.badge, tint: brand.tint,
    };
    const methods = [...get().methods];
    const lastCard = methods.map((m) => m.group).lastIndexOf("card");
    methods.splice(lastCard + 1, 0, card);
    set({ methods, methodId: id });
    return id;
  },
}));
