// Mock delivery time slots (scheduled delivery). Frontend-only.
import { create } from "zustand";

export type Slot = { id: string; day: string; time: string; full?: boolean };

export const scheduleDays = [
  { key: "today", label: "Today", date: "Wed, 10 Jun" },
  { key: "tomorrow", label: "Tomorrow", date: "Thu, 11 Jun" },
  { key: "fri", label: "Friday", date: "Fri, 12 Jun" },
];

const times = (from: number, to: number) => {
  const out: string[] = [];
  for (let m = from * 60; m < to * 60; m += 30) {
    const fmt = (t: number) => {
      const h = Math.floor(t / 60), mm = t % 60;
      return `${((h + 11) % 12) + 1}:${mm === 0 ? "00" : mm}`;
    };
    const ampm = (t: number) => (Math.floor(t / 60) >= 12 ? "PM" : "AM");
    out.push(`${fmt(m)} – ${fmt(m + 30)} ${ampm(m + 30)}`);
  }
  return out;
};

export const slotsByDay: Record<string, Slot[]> = {
  today: times(13.5, 22).map((time, i) => ({ id: `today-${i}`, day: "Today", time, full: i === 1 || i === 6 })),
  tomorrow: times(10, 22).map((time, i) => ({ id: `tomorrow-${i}`, day: "Tomorrow", time, full: i === 5 })),
  fri: times(10, 22).map((time, i) => ({ id: `fri-${i}`, day: "Fri, 12 Jun", time })),
};

type ScheduleState = { slot: Slot | null; setSlot: (s: Slot | null) => void };

export const useSchedule = create<ScheduleState>((set) => ({
  slot: null,
  setSlot: (slot) => set({ slot }),
}));

export const slotLabel = (s: Slot) => `${s.day}, ${s.time}`;
