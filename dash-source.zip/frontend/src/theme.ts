// Design tokens for Dash. Light theme only.
// Rebrand: EasyEat → Dash, brand color green → red.

import { useMemo } from "react";
import { Appearance, StyleSheet, useColorScheme } from "react-native";

export type ColorScheme = "light" | "dark";

const light = {
  // Surfaces — Salt (#FFEDE3) behind sections, white for cards
  surface: "#FFFFFF",
  onSurface: "#1A1A1A",
  surfaceSecondary: "#FFEDE3",
  onSurfaceSecondary: "#3A3A3C",
  surfaceTertiary: "#FADFD0",
  onSurfaceTertiary: "#48484A",
  surfaceInverse: "#1A1A1A",
  onSurfaceInverse: "#FFFFFF",
  muted: "#8E8E93",

  // Brand — Dash red
  brand: "#E23744",
  onBrand: "#FFFFFF",
  brandPrimary: "#E23744",
  onBrandPrimary: "#FFFFFF",
  brandSecondary: "#FDE7E9",
  onBrandSecondary: "#B32734",
  brandTertiary: "#FFF5F6",
  onBrandTertiary: "#E23744",

  // Status
  success: "#34C759",
  onSuccess: "#FFFFFF",
  warning: "#FF9500",
  onWarning: "#FFFFFF",
  error: "#FF3B30",
  onError: "#FFFFFF",
  info: "#0A84FF",
  onInfo: "#FFFFFF",

  // Lines
  border: "#F2E2D8",
  borderStrong: "#D9C3B6",
  divider: "#F7EAE2",

  // Extras
  star: "#E23744",
  overlay: "rgba(0,0,0,0.45)",
};

export type ThemeColors = typeof light;

export const defaultScheme = "light" satisfies ColorScheme;
export const themes: { light: ThemeColors; dark?: ThemeColors } = { light };

export function setColorScheme(scheme: ColorScheme | null) {
  Appearance.setColorScheme?.(scheme);
}
setColorScheme?.(themes.dark ? null : defaultScheme);

export function useTheme(): { scheme: ColorScheme; colors: ThemeColors } {
  const system = useColorScheme();
  const scheme: ColorScheme = system && themes[system] ? system : defaultScheme;
  return { scheme, colors: themes[scheme] ?? themes.light };
}

export function makeStyles<T extends StyleSheet.NamedStyles<T> | StyleSheet.NamedStyles<any>>(
  factory: (colors: ThemeColors) => T & StyleSheet.NamedStyles<any>,
): () => T {
  return function useStyles(): T {
    const { colors } = useTheme();
    return useMemo(() => StyleSheet.create(factory(colors)), [colors]);
  };
}

// Design tokens
export const spacing = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32, xxxl: 48 };

// Typography — Swiggy masterbrand ratios (80/88, 30/33, 15/21) scaled for phones. Font: Outfit (Gilroy look-alike).
export const type = {
  headline: { fontSize: 28, lineHeight: 31 },
  subhead: { fontSize: 20, lineHeight: 22 },
  body: { fontSize: 15, lineHeight: 21 },
};

export const radius = { sm: 6, md: 12, lg: 20, pill: 999 };
export const shadow = {
  card: {
    shadowColor: "#0F172A",
    shadowOpacity: 0.06,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 2,
  },
  sticky: {
    shadowColor: "#0F172A",
    shadowOpacity: 0.12,
    shadowRadius: 20,
    shadowOffset: { width: 0, height: -4 },
    elevation: 8,
  },
};
