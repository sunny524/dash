# Dash — Product Requirements

## Overview
**Dash** is a mobile food-ordering + delivery prototype for the Malaysian market, covering both the customer experience (delivery, dine-in QR, pickup, table booking, rewards) and the rider (driver) experience. Rebranded from EasyEat to a red-and-white identity.

## Brand
- Name: **Dash**
- Primary: `#E23744` (Dash red)
- Surface: `#FFFFFF`
- Full design system spec: `/app/DESIGN_SYSTEM.md` (Figma-ready)

## Delivered Screens (35+)

### Customer app (light, `#E23744` accent)
- **/** Splash + phone OTP
- **/location** Location permission + saved addresses
- **/(tabs)/home** — Search, service tiles, promo carousel, cuisine chips, restaurants
- **/(tabs)/orders** — Tabbed history + live order banner
- **/(tabs)/bookings** — Upcoming/Past reservations
- **/(tabs)/account** — Profile, DashPoints banner, Sign in as Rider entry, settings
- **/delivery/restaurants** — Filter chips + live search + empty state
- **/delivery/restaurant/[id]** — Parallax hero + menu
- **/delivery/reviews** — 4.8★ hero, breakdown, tag cloud, filters
- **/delivery/item** — Customization + qty + KeyboardStickyView CTA
- **/delivery/cart** — Address, delivery time, promo, payment, summary
- **/delivery/tracking** — Map + rider card + stepper
- **/dine-in/scanner** — QR viewfinder
- **/dine-in/menu** — Table-aware menu + Call Waiter FAB
- **/dine-in/bill** — Split bill + payment methods
- **/pickup/restaurants** — Pickup list
- **/pickup/status** — Big order number card + stepper
- **/booking/restaurants**, **/booking/book**, **/booking/confirmation**
- **/rewards** — DashPoints hub with Rewards / History tabs

### Rider app (dark, `#E23744` accent)
- **/rider** Login
- **/rider/(tabs)/home** — Online/Offline hero, incentives, hot zones, incoming order request sheet with 15s timer, accept/decline
- **/rider/active** — Map + turn-by-turn banner + 4-step delivery stepper (Head to restaurant → Pickup → Head to customer → Deliver) + Chat/Call/Navigate + customer note
- **/rider/summary** — Delivery complete + earnings breakdown + rate customer + trip details + continue riding CTA
- **/rider/(tabs)/jobs** — Job history with filter tabs
- **/rider/(tabs)/earnings** — Day/Week/Month segmented control + weekly bar chart + breakdown + acceptance/completion metrics + cash out
- **/rider/(tabs)/account** — Rider profile + vehicle + metrics + switch back to customer + settings

## Customer → Rider handoff (as requested)
- Customer places order at `/delivery/cart` → tracks at `/delivery/tracking` and immediately sees a dark **Live toast**: "Farhan accepted your order — he'll be at Nasi Lemak Village in 4 min" (LIVE badge, auto-dismisses after 4s)
- Rider sees the SAME order (Nasi Lemak Village, RM 34.40, 3 items) as an incoming request card on `/rider/(tabs)/home` with 15-second timer
- Rider taps **Accept Delivery** → `/rider/active` with full delivery flow · **Chat** button opens `/rider/chat`

## Rider Chat
- Dark chat screen at `/rider/chat` with system message, red "me" bubbles + white "them" bubbles, message grouping, seen indicator, order pill at top
- **Quick reply chips row** ("I'm on the way", "I've arrived at the restaurant", "Picking up your order now", "I'm 5 min away", "I'm at your door", "Can you come down please?") — tap to send instantly
- Keyboard-aware composer with camera + send buttons, disabled state when empty
- Call icon in header

## Merchant Portal
- `/merchant` login (email + password) with red hero and "Switch to Customer" chip
- `/merchant/(tabs)/orders` — Kitchen order queue with left-border status colour, KPI strip (New / Preparing / Ready / Today), filter chips, and progressive CTAs: **Accept & start preparing → Mark as Ready → Hand off**. Customer notes (e.g. "Extra sambal, no peanuts") highlighted in amber. Auto-accept toggle in header.
- `/merchant/(tabs)/revenue` — Red hero with Day/Week/Month, hourly bar chart with peak marker, top items with progress bars, pending payout card
- `/merchant/(tabs)/menu` — Search + in-stock/low/out-of-stock toggle per item + per-item sold count + Edit/Photo/Discount actions
- `/merchant/(tabs)/account` — Restaurant profile, Open/Closed toggle, metrics, switch back to Customer, settings (Opening hours, Payout, Promotions, Printer/POS, etc.)

## Voucher Wallet
- `/vouchers` — ticket-style cards (perforated cut-out edges + coloured gradient top), Active / Used tabs with counts, tap to expand → QR code + centered code + Copy code + **Use now** CTA (deep-links to cart)
- Empty state redirects to `/rewards`

## Design deliverables
- Live theme tokens in `/app/frontend/src/theme.ts`
- Figma-ready design system: `/app/DESIGN_SYSTEM.md`
- Colours mirrored in `/app/design_guidelines.json`

## Interactions (working prototype)
- Live search on Home + Delivery list (name / cuisine / address)
- Filter chips with real filtering (Top Rated, Under 25 min, Promo, $, Halal, cuisines)
- Redeemable rewards with claimed state
- OTP auto-advance with backspace-back
- KeyboardAware forms + sticky CTAs above keyboard
- Rider online toggle triggers a mock incoming order after 800 ms with a 15-second countdown, red urgency at 5s
- 4-step active delivery advances stage-by-stage
- Rate customer 1-5 stars on summary
- Weekly earnings bar chart with today highlight

## Update (Jun 2026) – Delivery flow polish
- Prices now shared via `orderTotals()` in `src/data/delivery-mock.ts` (subtotal RM 31.90, promo EASYEAT20 −RM 6.00, courier fee). Cart shows "Total before delivery"; quotes/confirmation add the chosen courier fee.
- Tracking map replaced with a drawn Kuala Lumpur street map (`src/components/KLStreetMap.tsx`, react-native-svg) with restaurant, rider, home pins and route.
- Courier options can be sorted: Recommended / Cheapest / Fastest.
- New `/delivery/rate` screen (stars, quick tags, comment, tip RM 0/2/5/10, thank-you state), opened from tracking "Got your order? Rate Aiman".

## Update (Jun 2026) – Payment, moving rider, reorder
- New `/delivery/payment` (Swiggy-style grouped options): Dash Wallet + reward points toggle (500 pts = RM 5), e-wallets (TnG, GrabPay, Boost, ShopeePay), saved cards + add card, FPX bank grid, Cash on delivery. Shared selection via zustand store in `src/data/payment-mock.ts`.
- Opened from Checkout "Change" (mode=select, returns) and from Courier "Proceed to pay" (pays → confirmation). Confirmation/rate show chosen method; COD wording handled.
- Tracking: rider pin animates along route (~30s demo), ETA counts down, status flips to Delivered on arrival.
- Thank-you screen: "Reorder in one tap" → back to Checkout.

## Update (Jun 2026) – Add card, bank login, scheduled delivery
- `/delivery/add-card`: live card preview, number/name/expiry/CVV validation, save toggle; new card added to payment list via zustand `addCard` and auto-selected.
- `/delivery/bank-login`: mock FPX flow (username → security phrase + password → approve) branded per bank; opens when paying with an FPX bank, then replaces to confirmation.
- Scheduled delivery: `src/components/ScheduleSheet.tsx` + `src/data/schedule-mock.ts` (ASAP or Today/Tomorrow/Friday 30-min slots, some fully booked). Opened from Checkout "Schedule"; shown on Courier options banner/pill and Order confirmed.

## Update (Jun 2026) – Swiggy-style redesign (Dash red/white kept)
- Home: location header, sticky search, 4-service switcher (Delivery/Dine-in QR/Pickup/Book table), offer carousel with dots, "What's on your mind?" circular categories (filter feed), top picks row, sticky filter/sort chips, Swiggy feed cards (RestaurantCard).
- Restaurant menu: info card, dashed offer strip, MENU divider, dish search, Bestseller toggle, collapsible sections, ADD/stepper overlapping image (src/components/MenuItemRow.tsx), floating MENU button + modal, floating cart bar.
- Dine-in QR menu: table header, running tab + call waiter, sticky category tabs, Send to kitchen bar.
- Orders: underline tabs, live status strip, items text, REORDER / RATE ORDER. Account: grouped Swiggy-style sections. Checkout: savings banner + Bill Details. Pickup/Booking lists use new cards.

## Update (Jun 2026) – Favourites, booking cards, live cart, no wallet
- `src/data/cart-store.ts` (zustand): shared delivery cart (menu ADD ↔ Checkout steppers, empty cart state; promo RM6 applies at RM25+) and favourites (hearts on cards/restaurant page).
- `/favourites` screen from Account → Favourites (empty state included).
- Book a Table cards (`RestaurantCard booking`): tables left tonight, next table time, party size, free cancellation; no delivery offers.
- Dash Wallet removed everywhere (payment option, Account row, menu offer). Loyalty (DashPoints / reward points toggle) kept; payment group renamed "Loyalty rewards".
- Note: cart/favourites are in-memory; a full page reload resets them.

## Update (Jun 2026) – Points preview, booking slots, one-restaurant cart, compact UI
- Loyalty: 1 DashPoint per RM1 (`pointsFor` in cart-store) shown on Checkout, Courier options, Order confirmed.
- Book a Table cards: 3 tappable time-slot chips → /booking/book?id=&time= (form pre-selects restaurant + time).
- Cart store tracks restaurantId; adding from another restaurant opens "Replace cart items?" sheet (keep / start fresh). Checkout/confirmation show cart restaurant name.
- Compact pass: smaller feed cards (160px), menu rows, section titles (16), banners, categories, headers.

## Update (Jun 2026) – Typography
- Font: Outfit (free Gilroy look-alike, OFL) in 6 weights, assets/fonts/Outfit-*.ttf, loaded in app/_layout.tsx via expo-font.
- `src/components/AppText.tsx` exports drop-in Text/TextInput mapping fontWeight → Outfit file and applying Swiggy leading (≥18px: 1.1×, body: 1.4×). All screens import Text/TextInput from it (codemod).
- `type` tokens in theme.ts: headline 28/31, subhead 20/22, body 15/21 (Swiggy 80/88, 30/33, 15/21 scaled for phones).

## Update (Jun 2026) – Salt palette
- Kept Dash red (#E23744) for CTAs/accents. surfaceSecondary → Salt #FFEDE3 (section backgrounds), surfaceTertiary #FADFD0, warm borders/dividers; cards stay white.
- Rider & Merchant screens already use Outfit via AppText codemod.
